# Lumina OS 更新日志

## v0.42.0（M50——桌面可用性跃迁轮：EACCES exec 记账 + xdg_shell 电气闭环 + 文本渲染 + IOPB 硬件面 + musl 动态全链真执行）

- M50 用户点名六域**五落账一挂账**（七笔：笔75/76/77/78-79/80/81/82 + 收尾笔83）：**开工批四笔**——**笔75 M50-EEXEC65** EACCES exec 记账域（**ABI v0.25→v0.26** ERR_ACCES(16) 单码追加——Linux setpgid(2) EACCES 语义面 + Task execed 位 + setpgid_check 判据④ + conduit 双臂——t157 活体三相位）+ **笔76 M50-XDGSHELL66** xdg_shell wire 面（XdgWmBase/XdgSurface/XdgToplevel 三接口 + xdg-shell.xml 官方声明序 opcode + SIG 11 目 + 编组器 10 面——宿主 58→59）+ **笔78/79 M50-TEXT68/69** 文本渲染面（glyph::text FONT8X16 8x16 双域同源〔gen_font8x16.py 单事实源 1520 B 直对账〕+ render_text 透明合成栅格化 + waycomp 标题栏带——glyph 宿主 11→15；**揭雷② title_bar_px 2M 像素回归竞窗 O(1) 化收口**）+ **笔80 M50-MUSL70** musl 动态全链真件谱（artifacts/musl 双真件入库〔Alpine musl 1.2.4 ld-musl-x86_64.so.1 645 KB + busybox 1.36.1 动态 PIE 808 KB〕+ harbor musl_chain_face 五域宿主 89→90；**揭雷① dl_new_hash 异或→官方加法口径修正——真件首撞即断，四生成器同源重产**）。
- **续作批双笔**——**笔77 M50-XDGSHELL67** xdg_shell 电气闭环（comp 会话域 xdg 角色态 + commit 前置闸 XdgUnacked fail-visible + send_ping/request_close 双车道 + waycomp GLOBALS 4→5 目〔124B→156B〕+ 标题带动态域 + close 车道 MPMC 环——t159 真车道全生命周期活体 + prism 宿主 59→60）+ **笔81 M50-IOPB71** IOPB 挂 TSS 硬件面（ostd::hw TssWithIopb〔iopb_offset=112 + 8192 B 位图 deny-by-default〕+ 位图 API 组 + PIO_GEN 授权纪元 + SPAWN_HOLD 跨核竞逐窗封死〔**揭雷② spawn 竞逐实录**〕——t160 活体：**ring3 端口电气探针直呼 in/out GP 零显形 EXIT(0x5F)**；揭雷族五例如实落账〔SDM 逐字节判读/TCG 读值车道差真机挂账等〕）。
- **续作批二**——**笔82 M50-MUSLRUN72** musl 动态全链真件 ring3 真执行（bedrock::elf 双型口径演化〔ET_DYN 接纳 + PT_INTERP 出域 + AuxSys base 域——AT_BASE 对动态域发射静态链字节面零扰动〕+ kernel::user build_user_space_elf_dynamic〔**解释器 PD6[2] 槽域 0x1_8040_0000**——PD[3+] 内核堆恒等镜像借根禁区避让 + 双真件页域装载 198+161 页 + AT_PHDR/AT_BASE/AT_ENTRY 全谱 + 入口 musl _dlstart〕+ vfs 三件媒体通道〔/bin/busybox-dyn + /lib/ld-musl-x86_64.so.1——PT_INTERP 串原样路径〕+ boot 三模块 staging + t161 活体：**真实 musl ldso 机器码 ring3 电气执行**〔_dlstart 自重定位 → DT_NEEDED=libc.musl-x86_64.so.1 与自身 SONAME 自解 → 程序 378 GLOB_DAT+7 COPY+1 JUMP_SLOT 重定位 → echo applet → exit_group(0) → waitpid 收割〕+ 双 NEG fail-visible〔静态 blob 动车道拒收 + 解释器损件拒收〕；**揭雷① T161-OK 标记发射收口**——bedrock 宿主 43→46）。
- 三面同步：SELFTEST 156→**161**（t157-t161 五新号）+ 双面板 245→**265** + ABI v0.25→**v0.26** + bedrock 宿主 43→**46** + prism 宿主 58→**60** + glyph 宿主 11→**15** + harbor 宿主 89→**90** + xtask S8 required 213→**218**/longrun 221→**226**。
- docs 对账：ROADMAP §三 M50 行 ✅ 关账 + §四 七行 + METRICS H/PR 行 + MATURITY **v12 = 7.1/10**（等权合成公式复归 + v10/v11 总评行勘误注——历史分值不回改）+ README 事实位终同步〔自检 161/ABI v0.26/双面板 265/t1-t161〕+ workspace 升版 0.41.0→**0.42.0**（Cargo.lock 随行）+ releases/RELEASE_NOTES-v0.42.0.md 入库 + tag v0.42.0 双推 + 双 tar + SHA256SUMS（GitHub Release 四资产随行）。
- 门禁 CI-OK 11 阶段全绿（七笔各自冒烟实录随行——撞窗族冷却复跑口径续度实证：t118 input-isr-arm + net-backpressure-icmp 两轮实录复绿）。
- 挂账随行：真机三实测回填（REALHW-WINDOW R1/R2/R3）+ 环境 B 绝对门禁 + PR-P04 Vulkan + musl SYS_EXEC 动态族纵深（sys_exec 动态分流）+ S8 required 数组 v0.40.0 起欠账揭雷记档（t150-t158 断言未回填——笔82 起新号随行入列）。

## v0.41.0（M49——五候选全开工轮：harbor 收口 + 基准族 + 进程组/会话 + TCP 补全 + 残余窗口族定性）

- M49 五候选（A–E）全落账：**候选 A harbor 收口轮三笔**——**笔67 M49-DLCLOSE58** dlclose 真消费链执行域（dl_close_chain_ledger 装载序逆行卸载〔依赖先卸 + Kept 幂等零台账〕+ fini_site_addr 兑现面〔读回/直取双域〕+ DlCloseInvalid 域——t153 宿主面活体 CLOSE/FINI/NEG 三相位）+ **笔68 M49-FINI59** .fini_array 终局执行域（exit_fini_ledger 全局终局序〔装载序全逆 = init_order 精确逆行〕+ DlState::exit_clear 终局清算〔引用耗尽 + 空册幂等〕——t154 EXIT/CLEAR/NEG 三相位）+ **笔69 M49-TLS60** TLS 执行域真做（tls_reloc_apply 四模型写面〔TPOFF64/GOTTPOFF/TLSGD/TLSLD〕+ Dtv 扩展真做〔扩容世代记账 + DTV_CAP=64〕+ tls_get_addr/tls_addr_of 语义核——t155 WRITE/DTV/NEG 三相位；揭雷两域：GD/LD 槽位重叠 + get_addr 金值笔误）——**harbor 六族全谱闭环**。**候选 B 基准族**——**笔70 M49-BENCH61** H-P02/H-P03/H-P05 三基准挂账摘牌（宿主微基线 M-P01 同谱：H-P02 load+reloc mean 3987 ns/op / p99 9331 ns + open+close pair 10766 ns；H-P03 四段 (1,1,1,1) tenths 零超支；H-P05 bump 52 ns / freelist 92 ns-pair——环境 B 绝对门禁挂账不变）。**候选 C 多用户纵深三批余项**——**笔71 M49-PGRP62** 进程组/会话域（**ABI v0.24→v0.25**：SYS_SETPGID(48)/SYS_GETPGID(49)/SYS_GETPGRP(50)/SYS_SETSID(51) 四新号 + ERR_SRCH(14)/ERR_PERM(15) 双码 + Task pgid/sid 双字段 fork 全量继承 + setpgid_check/setsid_check 语义核 + 四真车道——t156 MATRIX/LIVE/NEG 三相位；EACCES exec 禁令 v0 域清单外如实记账）。**候选 D TCP 重传面补全**——**笔72 M49-TCP63**（RFC 5681 快速重传/快速恢复 FastRtx + CcState 三拍 + RFC 2018 SACK wire 面 + ReasmBuf::sack_runs 派生 + RFC 7323 TSopt/TsTracker RTTM 单槽 Karn 窄化——揭雷四域收口）。**候选 E 残余窗口族定性**——**笔73 M49-T73DEV64**（docs/RESIDUAL-WINDOWS-M49.md 四族一显形域族谱〔193 撞窗/网络族/输入族/基准漂移/真缺陷显形——本会话七轮 193 冷却实证〕+ scripts/residual-window-triage.sh 分诊器——撞窗不改码纪律体系化）。
- 三面同步：SELFTEST 155→**156**（t153/t154/t155/t156 四新号；基准/窗口族两笔零内核增量先例 M39-HBI/M40-PRP04 同谱）+ 双面板 229→**245**（T153/T154/T155/T156 各四件）+ ABI v0.24→**v0.25**（笔71 四新号双码）+ harbor 宿主 84→**89**（close/exit/tls 三面 + H-P02/H-P03 双基准）+ pulse 宿主 44→**48** + ostd 宿主 +2（H-P05 双基准）+ bedrock 宿主 43 + conduit 宿主 20。
- docs 对账：ROADMAP §三 M49 行 ✅ 关账 + §四 七行 + METRICS H/PU 行 + MATURITY v11 + README 事实位终同步 + RESIDUAL-WINDOWS-M49.md 底稿入库。
- 门禁 CI-OK 11 阶段全绿（七笔各自冒烟实录随行——193 撞窗族冷却复跑口径既录七度实证）。
- 实录（收尾定版树复跑）：LUMINA-T156-MATRIX self=1 join=1 srch=1 nself=1 xsession=1 join-miss=1 inval=1 leader-setsid=1 ok-setsid=1 / LUMINA-T156-LIVE pid=0 getpgrp=0 setpgid(0,0)=0 getpgid(0)=0 / LUMINA-T156-NEG srch=2 perm=1 / LUMINA-T156-OK / LUMINA-SELFTEST-PASS 156/156 / LUMINA-CENSUS n156 p156 f0 ff0。

## v0.40.0（M48——PLT/GOT 惰性绑定电气执行 + dlsym 跨模块查找电气面 + init_array 执行域 + 真机窗口三实测开工）

- M48 四域全落：**笔63 M48-PLTGOT55** PLT/GOT 惰性绑定电气执行（harbor 第④族桩→真——LazyGot 两态机 + lazy_wire 接线判读〔守恒律 wired+bound=JUMP_SLOT 族计数〕+ ldlumina-pltgot-probe.elf ring3 resolver 电水解活体〔首调兑现/次调直达零重入/负例电气 EXIT(91)〕——揭雷三域：FF 组 RIP 相对雷域 + REX 双雷 + je rel8 跨距雷）+ **笔64 M48-DLSYM56** dlsym 跨模块查找电气面（dl_sym_chain 三段决议〔root 域先见 + 依赖域 BFS 段位 + 全链缺席零虚构〕+ DlState::dlsym_chain error 槽 + ring3 哈希电算对账〔h=0xdeed9c69 真值——负例电气 EXIT(92)〕——揭雷五域如实落账：bloom 64 位加载/数据段截断/jcc 极性/取证域反噬/moffs64 半宽）+ **笔65 M48-INIT57** init_array 执行域（init_faces_of 直收 + init_exec_ledger 执行台账〔兑现序=依赖先序〕+ liblumina-init.so 交付件——揭雷两域：偏移溢出/DT_FINI 标签）+ **笔66 真机窗口三实测开工**（docs/REALHW-WINDOW-M48.md 模板 + scripts/realhw_window_tri.sh 脚手架——本环境模板先行零虚构，数值留真机回填）。
- 三面同步：SELFTEST 149→**152**（t150/t151/t152 三新号）+ 双面板 213→**229**（T150 六件 + T151 六件 + T152 四件）+ ABI v0.24 维持零增量 + harbor 宿主 82→**84**。
- docs 对账：ROADMAP §三 M48 行 ✅ 关账 + §四 四行 + README 事实位终同步 + MATURITY 随行注。
- 门禁 CI-OK 11 阶段全绿（三笔各自冒烟 150/151/152 全绿实录随行）。
- 实录：LUMINA-T150-PLT wired=1 bound=0 jump_slot=1 stub=0x40001010 resolve=1 idem=1 neg=(1,1) / LUMINA-T150-LIVE pid=10 st=4 exit=0x5b / LUMINA-T151-SYM order=(0,1) boot=(1,0x30001000) fn=(1,0x30011000) ghost=1 err_once=1 neg=(1,1) / LUMINA-T151-LIVE exit=0x5c / LUMINA-T152-LEDGER acts=3 addrs=(0x30021000,0x30021010) / LUMINA-T152-OK / LUMINA-SELFTEST-PASS 152/152 / LUMINA-CENSUS n152 p152 f0 ff0。

版本语义：工作区里程碑版（0.x.y，x=里程碑，y=里程碑内迭代）。
本文档记录源码树的对外可见变更；指标与规格变更见《指标与规范手册》修订记录。

## 早期版本沿革（回溯补记）

> 云盘 src 包自 v0.9.0 起逐版本存档；v0.3.0–v0.8.0 段因沙箱重置未落盘（源码包
> 佚失，内容仅存 devlog 记载），版本号按磁盘实况与 devlog 续排。以下为回溯概览，
> 逐版详条目自 v0.16.0 起。

- **v0.2.0（M2，回溯过程记录版）**：multiboot1 裸机启动 → x86_64 长模式；
  VGA/串口双通道早期控制台；内核堆（Harbor）启动期绑定；七项自检全绿；
  QEMU 退出码 33 自动验收（定版 devlog S7）。
- **v0.3.0–v0.8.0（M3–M8，源码包佚失）**：内存/中断/任务基座；抢占/TSC/ring3
  用户态/系统调用/双机联测；SMP（AP 启动/TLB 击落/IPC 快速路径/按需分页）；
  per-CPU 统一调度/IPC 能力化/TLB 批量击落；per-CPU TSS/用户任务跨核/swap
  换页 I/O；swapgs 纪律定版 + 页表级 swap 回收全链 + 优先级调度面与定向门铃。
- **v0.9.0（M9）**：进程模型（SYS_CAP_GRANT/REVOKE/GET_PID 任务句柄表）+
  换页异步化（swapd 分页任务 + 零 I/O 快路径）+ 优先级老化与饥饿防护。
- **v0.10.0（M10）**：per-CPU tick 账户（时间面迁 PIT 全上下文）+ 任务阻塞态
  与调度点切换 + waitpid 语义雏形（SYS_WAIT_PID + Zombie 收割）；宿主测试
  88 → 89 用例；裸机自检 33 → 36 项。
- **v0.10.1（hotfix）**：kernel.bin/elf 直发版。
- **v0.11.0–v0.12.0（真链早期定版）**：云盘包（打包时刻 2026-10-09）。
- **v0.13.0（M13）**：VFS 骨架移植入真链。
- **v0.14.0–v0.15.0（真链定版）**：云盘包（打包时刻 2026-10-10）。

## v0.39.0（2026-11-18）—— M47 三笔闭账：装载计划消费面 + ld-lumina.so 本体交付批 + dlopen 真消费面

> M47 两实施笔（笔60~61）+ M47-收尾关账（笔62）三谱闭账（workspace 升版 0.38.0 → 0.39.0）。裸机自检 148 → **149** 项（t149 续编）；syscall ABI **v0.24**（笔60 双新号 SYS_MMAP(46)/SYS_MPROTECT(47)——笔61 全批零增量）；五维成熟度 v8 7.0 → **v9 7.1**（docs/MATURITY.md 复评链——功能维用户态链接面三件套成形〔语义核 + 电气域 + 真消费链〕+ 工程治理维两笔全闸带揭雷收口）。

- **装载计划消费面 + ld-lumina.so 本体交付批（M47-LDCONS53 笔60，t148 新号自检——ABI v0.23→v0.24 双新号）**：bedrock ABI v0.24 双电气域（SYS_MMAP(46) native 匿名映射面〔fd = MMAP_ANON_FD 匿名哨兵 / PROT 位族 W⇒R、X⇒R / MMAP_ANON_BASE 0x2_0000_0000 256 MiB 窗 / 游标或定点 / 页立映射〕+ SYS_MPROTECT(47) 页保护改旗面〔登记行域内单行覆盖 + 逐叶 RW 位改写 + invlpg + 行分裂真值保持〕——parse 结构闸 + 宿主负例矩阵 +1 例 bedrock 42→43）+ kernel::mmap 承接面（MapRow 行登记〔同任务重叠拒收 + 定容 64 行〕+ map_user_page_us **中间层逐层补 US**〔M33-T1 纪律重铸——t148 首割揭雷 pf-walk pdpte/pde=0x23 缺 US 实锤〕）+ harbor::ld::exec 消费面（prot_of 旗翻译 + MapAction 三变体确定性电水单 + **exec_plan 三段式消费序**——先全量映射 R|W 分级窗→逐区交集拷贝→逐区终旗，Linux 装载器共享页序同谱——宿主 +1 例 harbor 80→81）+ **ld-lumina.so 本体 ELF 交付件**（artifacts/ 入库 12,288 B 真 ET_DYN——SONAME + dynstr/dynsym 四目 + GNU 哈希 u32 阵列〔×33 异或权威变体〕+ RELA 四类 + PT_DYNAMIC 十目 + PT_TLS + BSS 尾 + gen_m47_ldlumina.py 生成器单一事实源）+ t148 活体四相位〔SO——本体真件机械链 + exec_plan 五动作金值 + GNU 哈希决议 ldlumina_boot→sym1 + 真件 RELA 四类写面 + 真件 TLS 布点 tp=-16 → LIVE——ring3 消费活体〔mmap 两区定点回显 + 写样/读回 + mprotect RW→RX + 映射页内代码 call（0x5A5A5A5A）+ 负例三目 → EXIT(88)〕→ REG——登记面双行断言 → OK〕——揭雷收口三域如实落账（探针 REX 编码两雷 + GNU 哈希三雷〔buckets/chains u64→u32 gABI + dl_new_hash 加法→异或权威变体〕+ 内核 US 位域雷）。
- **dlopen 真消费面（M47-DLOPEN54 笔61，t149 新号自检——ABI v0.24 维持零增量）**：harbor::ld::exec **真消费面四域**（ChainRegistry 链式装载注册表〔SONAME→ET_DYN 映像字节——定容 8 + 重名/越界拒收〕+ **dl_adjacency 依赖闭包邻接派生**〔DT_NEEDED 声明域走查〔DynImage::needed 名走查→注册表名查边——缺件 NeededMissing fail-visible〕∪ UNDEF 决议闭包 as-needed 派生〔RELA r_sym 名→本模块 GNU 哈希缺席判 UNDEF→注册表定义者名查边〕〕+ **dl_chain_order DT_NEEDED 装载序**〔crate::ld::needs_cycle 三色环判读 + needed_load_order BFS 层序语义核机械消费——root 居首〕+ **dl_open_chain 真消费链**〔根名查册→装载序→按序 DlState::dlopen 群组插序〔RTLD_GLOBAL 全链同旗〕→ modid 序；根名缺件 error 槽 CANNOT_OPEN 一次性消费〕——LdExecError 增列 NeededMissing/NeededCycle/RegistryRange 三目）+ **liblumina-core.so 依赖库 ELF 交付件**（artifacts/ 入库 12,288 B 真 ET_DYN——SONAME + core_fn/lextern_dat 双定义符号 + GNU 哈希双链 + RELA RELATIVE×2——ld-lumina.so UNDEF 族〔ldep_fn/lextern_dat〕真决议供给方 + gen_m47b_dlopen.py 生成器〔ld-lumina.so 与 m47 生成器逐位同源单一事实源锚〕）+ **ldlumina-dlopen-probe.elf ring3 自装载链探针**（36,864 B 原生 ABI ET_EXEC——数据段内嵌 ld-lumina.so + liblumina-core.so 双真件）+ t149 活体三相位〔CHAIN——DT_NEEDED 装载序真消费链（双真件登记→闭包派生〔声明域走查 needed=(0,0) 如实记档 ∪ UNDEF 闭包 lextern_dat 名匹配 core 定义者实边〕→dl_chain_order [0,1]→装载序逐模块 exec_plan 动作金值 5+5→跨模块重定位〔lextern_dat 真名决议 + ldep_fn 绑定登记域→core_fn 名决议 + COPY 源搬运 "CORE" 落槽——四类金值 (1,1,1,0,1) + core RELATIVE×2〕→dl_open_chain modid 序 [1,2] + 幂等域 + 根名缺件负例 + TLS 链布点 tp=-16）→ LIVE——ring3 自装载链活体（SYS_MMAP(46) 四窗 R|W 分级定点回显 + rep movsb 分级拷贝 + ring3 重定位写面〔跨模块决议值烘焙〕+ SYS_MPROTECT(47) RX 终旗×2 + **call ldlumina_boot**（0x5A5A5A5A——装载执行域电气证明）+ **GOT[2] 间呼 core_fn**（0xC0DEC0DE——JUMP_SLOT 跨模块电气证明）+ COPY 槽读回 + BSS 尾零读回 + 负例二目 → EXIT(89)）→ REG——登记面四行断言（双 RX 终旗 prot=5 真值保持 + L1 RW 双页 + calls=(6,3) 全局累计）→ OK〕——宿主 +1 例 harbor 81→**82**（dl_chain_consumer_face 八域全谱）+ **揭雷收口两域如实落账**（〔一〕kernel::mmap 登记面 GC 域 rows_gc——pid 槽复用 × 登记行持久化：t148 探针 pid10 已殁行仍在册→t149 探针复用 pid10 首 mmap 同任务重叠拒收 bail 90——行属主存殁判读收割收口，活体行持久/殁者行域零泄漏；〔二〕探针 rbx 基址雷——gen_m47b rbx=DATA_VA+SO_DATA_OFF 双重计入→四条拷贝源全偏 +0x1000→第四条读出数据段末页外 #PF RIP=0x400156——rbx=DATA_VA 段基直算收口）。
- 真机三项挂账远线维持（真机窗 bit24=1 四段实测回填 / DPMS 真机背光实测 / 24h/72h 长稳正式记录——执行面在环 ≠ 数据在环零虚构）+ PR-P04 硬件 Vulkan 队列 + IOPB/IOPL 硬件面转化既录续挂。
- docs 对账：ROADMAP §三 M47 行 ✅ 关账 + §四 三行（笔60/笔61/收尾）+ METRICS H-P01 随行注 + MATURITY v9 复评注 + README 事实位终同步 + CHANGELOG 本条目 + workspace 升版 0.38.0→0.39.0（Cargo.lock 随行）+ releases/RELEASE_NOTES-v0.39.0.md 入库 + tag v0.39.0 双推 + 双 tar + SHA256SUMS + ls-remote 回环（GitHub Release 四资产随行）。门禁 CI-OK 11 阶段全绿（定版树复跑——冒烟 149/149；t145 撞窗族冷却复跑口径既录随行）。实录（定版树复跑）：LUMINA-T149-CHAIN adj=(1,0) order=(0,1) acts=(5,5) hits=(fn=1,dat=2) rel=(1,1,1,0,1)(2,0,0,0,0) modids=(1,2) err_once=1 tp=-16 needed=(0,0) / LUMINA-T149-PROBE / LUMINA-T149-ELEC / LUMINA-T149-LIVE pid=10 st=4 exit=0x59 deadline-hit=false native-abi=true gc=2 / LUMINA-T149-REG rows=4 rx_prot=5 c_rx_prot=5 pages_rw=2 total=4 calls=(6,3) / LUMINA-T149-OK / LUMINA-SELFTEST-PASS 149/149 / LUMINA-BOOT-OK / LUMINA-CENSUS n149 p149 f0 ff0。

## v0.38.0（2026-11-18）—— M46 四笔：harbor 机械执行面 ld-lumina.so 交付批 + 真机窗口实测回填执行面 + DPMS 背光语义面 + 长稳正式记录底稿

> M46 四笔（笔55~58）+ M46-收尾关账（笔59）五谱闭账（workspace 升版 0.37.0 → 0.38.0）。裸机自检 146 → **147** 项（t147 续编）；syscall ABI v0.23 维持（M46 全部批次零 syscall 增量）；五维成熟度 v7 7.0 → **v8 7.0**（docs/MATURITY.md 复评链——功能/治理双维内动零合成位移如实记分）。

- **harbor 机械执行面 ld-lumina.so 交付批（M46-LDEXEC49 笔55，t147 新号自检）**：`harbor::ld::exec` 新模块（细则 §2.3 + H-P03 权威条款——M45-HARBOR48 笔53 语义核挂账兑现；crate 级 `forbid(unsafe_code)` 不破）：**ET_DYN 结构判读**（bedrock::elf 静态口径同款防线序 + 页槽互斥 + 动态表定容收取）+ **装载映射计划面**（页对齐并权合并——Linux 共享页 mprotect 并权语义）+ **分级缓冲**（filesz 拷贝 + memsz 尾零 BSS 语义 + 16 MiB 预算闸）+ **GNU 式符号哈希桶链机械面**（DT_GNU_HASH 头 + gABI bloom 双位布局 + 桶链走查链尾旗 + strtab 名比对——dl_new_hash 同源）+ **重定位四类写面**（RELATIVE 直写 / GLOB_DAT·JUMP_SLOT 决议直写 / JUMP_SLOT × !bind_now 惰性跳过记账——PLT/GOT 延迟绑定 / COPY 源镜像字节搬运——越界/未决议 fail-visible 13 错误显形集）+ **TLS Variant II 布点**（模块 1 tp 前域 + surplus 上域累进 + DTV 扩容判读同源）+ **init/fini 互逆序**（依赖先序 init / 精确逆序 fini）+ **dlopen/dlsym/dlclose/dlerror 族外壳**（refcount 注册表 + RTLD_GLOBAL 插入序 + scope_lookup 三段复用 + dlerror 一次性消费）+ **H-P03 四段打点**（ns → 0.1 ms 定点上取整 + 预算判读同源）+ **auxv 入口契约五目探针**。宿主单元测试全谱 12 例（ET_DYN 金值/拒收矩阵/装载并权/分级缓冲 BSS/重定位四类/惰性绑定/GNU 桶链/TLS 金值/init-fini 互逆/dlopen 状态机/auxv 契约/四段打点）——**harbor 69→80 例全绿**。**揭雷收口一域如实落账**：rustc 1.99 把 no_mangle 划入 unsafe_code lint 域（裸写与 unsafe() 包装形同罚）——harbor forbid 与 abi.rs 内核目标 C 导出面 12 目全量冲突揭雷；收口 = 导出面降级 cabi 特性门控（默认关——t147 零导出需求；启用窗 deny+allow 收口挂账——forbid 主不变量不破）。装载计划消费面（ring3 mmap/mprotect 电气域）与 ld-lumina.so 本体 ELF 交付件挂账如实登记。
- **t147 活体（新号 t147）五相位**：〔(a) MAP〕→〔(b) RELOC——GNU 哈希决议 libstart→sym1→绝对化 + 四类写面全谱（GOT[0]=base+0x40 / GOT[1] 决议写 / GOT[2] 惰性 0xEE 原貌 / GOT[3] COPY 源搬运）〕→〔(c) TLS——三模块布点 -32/+16/+24 金值 + DTV 扩容〕→〔(d) INIT——init/fini 各 4 调用点 + dlopen 族 error 一次性消费〕→〔(e) BUDGET——**语义锚判据**（预算判读面确定性金值对账 + 上取整定点锚）+ TCG 实测打点降记录面不设闸（TCG 数值只作回归基线——H-P03 绝对值判读随真机窗回填，recon_backfill 窗态纪律同源）〕→〔OK 收口〕。三面同步：SELFTEST 146→147 + 双面板 195→201（T147-MAP/RELOC/TLS/INIT/BUDGET/OK 六件入 required/longrun 双面）+ ABI v0.23 维持。
- **真机窗口实测数据回填执行面（M46-RECON50 笔56）**：ostd ReconRecord + recon_backfill 回填核**双纪律闸**（① 窗态纪律——仅 RealMachine 真机窗可回填，Recorded 记录式锚窗拒收 None——锚窗零执行零宣称；② 计划面纪律——四段全谱装载非 Void 才可回填）+ RECON_BUDGET_TENTHS 四段预算同源复制（harbor::ld 同谱——依赖方向单向口径）+ recon_backfill_write 证据行（LUMINA-RECON-BACKFILL 单行取证格式）。宿主 +1 例全绿（ostd 51→52）。**实测数据回填挂账远线不变**（执行面在环 ≠ 数据在环——零虚构）。
- **DPMS 背光语义面（M46-DPMS51 笔57）**：power::display 背光域扩容（PanelPower 四态 VESA DPMS 语义映射——kernel::fb DpmsLevel 电气域同谱 / backlight_pct 百分比契约〔On=100/Blank=0/Dim=登记值〕/ BACKLIGHT_RAMP 斜坡计划〔步粒度 10 定容 16 步——升降对称含目标钳制〕/ **Dim 不切供电语义锚定**）。宿主 +1 例全绿（power 9→10）。真机背光实测回填挂账远线不变。
- **长稳正式记录底稿（M46-LONGRUN52 笔58）**：docs/LONGRUN-RECORD-TEMPLATE.md 入库（RUNBOOK §三 报告模板底稿化——字段域 9 目/判据域三闸/裁决域 + 入账纪律沿用 §四；真机窗逐字段回填即正式记录）。**底稿在环 ≠ 记录在环**——24h/72h 正式记录挂账真机窗口不变；S10 短窗 Panel A 三度 PASS 实录（cycles=2 avg 114-121 s）+ Panel B 撞窗族轮换实录五度（t112/t118/t145/t105+T109——2 vCPU 高载沙箱 TCG 窗族，冷却复跑口径不改判——M45 既录族同带；S8 同判据三度 147/147 全绿为机械面绿证主锚）。
- docs 对账：ROADMAP §三 M46 行 ✅ 关账 + §四 五行 + METRICS 三行 + PDF-RECON H-P03 行 + MATURITY v8 复评注 + README 事实位终同步 + CHANGELOG 本条目 + workspace 升版 0.38.0（Cargo.lock 随行）+ releases/RELEASE_NOTES-v0.38.0.md 入库 + tag v0.38.0 双推 + 双 tar + SHA256SUMS + GitHub Release 四资产随行。门禁 CI-OK 11 阶段全绿（定版树复跑——冒烟 147/147）。实录（定版树复跑）：LUMINA-T147-MAP loads=2 regions=2 staged=0x3000 / LUMINA-T147-RELOC rel=1 dat=1 jump=0 lazy=1 copy=1 hash=libstart->1 / LUMINA-T147-TLS tpo1=-32 tpo2=16 tpo3=24 dtv3=1 / LUMINA-T147-INIT init=4 fini=4 dl=3 err_once=1 / LUMINA-T147-BUDGET anchor=ok / LUMINA-T147-OK / LUMINA-SELFTEST-PASS 147/147 / LUMINA-CENSUS n147 p147 f0 ff0。

## v0.37.0（2026-11-17）—— M43/M44/M45 三里程碑关账 + harbor 动态链接族开工

> M43 六批（笔㊱~㊻）+ M44 三批（笔㊼~㊾）+ M45 四笔（笔㊿~53，含**笔52 沙箱回收事故复刻批次**）+ M45-收尾关账（笔54）四谱闭账（workspace 升版 0.36.0 → 0.37.0）。裸机自检 134 → **146** 项（t135…t146 续编）；syscall ABI v0.23 维持（M43/M44/M45 全部批次零 syscall 增量）；五维成熟度 v6 6.9 → **v7 7.0**（docs/MATURITY.md 复评链）。

- **真机窗口 bit24=1 实测对账全谱**：SDM Vol.2 Table 3-8 权威位义表 32 目 + 逐位判读语义核（t144）+ ReconWindow 二态判定核（RealMachine 真机窗 / Recorded 记录式锚窗三源一致成像）+ RECON_SEGMENTS 四段计划面（t146）+ TSC deadline 交付后 LVT mask 解除武装（写 0 口径退役——三域 exact-one 收敛，t143）+ MSR 0x6E0 路由复证；真机窗口实测数据回填挂账远线。
- **输入域零锁化**：ostd::sync::mpmc::MpmcRing（Vyukov 有界 MPMC——宿主 4 例含 4 产者 × 2500 × 4 消费者 exactly-once 10000 交付）+ waycomp KEY_Q/PTR_Q/AXIS_Q 三环换装 + IN_MU 退役 + ISR 臂退避域退役（t145）。
- **harbor 动态链接族开工**：harbor::ld 语义核判读族 v0（H-P03 四段预算分解 ≤1.2/1.0/0.5/0.3 ms 合计 ≤3 ms + GNU 式符号哈希 + bloom 双位面板 + 装载率告警 + DT_NEEDED 装载序/环检测 + 查找序三段 + 重定位四类/惰性绑定 + TLS 四模型/DTV 扩展——宿主 12 例全绿 harbor 57→69）；机械执行面挂账随 ld-lumina.so 交付批次落域。
- **随行揭雷收口**：退出码通知域早现中间态（v0 exit_current 先存后切——t95 零锁轮询撞窗七连实录）收口：通知随 Zombie+SWITCHING 锁窗同窗落账，观察面单点收敛无中间态；**复刻批次定界如实**（笔52 提交随沙箱回收丢失——依关账报文忠实复刻 + 门禁全谱复跑，实录与丢失批账面逐字对齐）。
- **Wayland 输入链收口（M43/M44）**：axis_value120 离散步进 + 键重复生产域 + 产者优先级 + Explorer 族谱（水平滚轮 dw）+ 窗亡直迁 + map 域直迁 + boot wheel/explorer 接线切换（t135…t142 十二批）。

## v0.36.0（2026-11-15）—— M42 用户态桌面链三阶段 35 笔收官

> M42「用户态桌面进程/Wayland 合成器」全谱落账（v0.27.0 后连发三阶段 35 笔 +
> 本收尾对账批；workspace 升版 0.27.0 → 0.36.0）。裸机自检 96 → **134** 项
> （t101…t134 续编）；syscall ABI v0.20 → **v0.23**（SYS_DEV_PIO/SYS_FB_SURFACE/
> SYS_UNIXSOCK/SYS_SHM/SYS_AUX_READ/SYS_PTR_INJECT 收录）；五维成熟度 v5 6.8 →
> **v6 6.9**（docs/MATURITY.md 复评链）。

- **阶段一（fb 驱动进程）**：SYS_DEV_PIO 端口裁量代执车道 + fbdev 映像移交链
  （SYS_MMAP_ANON LFB 映射）+ 常驻 fbdev 服务化（t101/t108）。
- **阶段二（unix socket 域）**：SYS_UNIXSOCK(42) 多路复用 op 面（AF_UNIX
  socketpair/bind/connect/accept/流 I/O + 阻塞 accept/EOF 终结）+ Wayland wire
  解析壳（签名驱动解析 + 官方 opcode 事实源对账）+ SCM_RIGHTS fd 传递
  （SEND_FD/RECV_FD）+ SYS_SHM(43) wl_shm 池域（t103/t105/t106）。
- **阶段三（合成器进程面）**：常驻 waycomp 合成器 ring3 化迁移（WAYCOMP_SVC_ELF
  编译进程链九形 + boot 换防 + 重启面 bounded-retry）+ prism::wayland::comp 会话
  语义面全谱（surface 生命周期/damage-commit 发布/帧回调 delete_id 复用/display.
  sync 多注册/几何 UPDATE 演进）+ 输入链全谱（evdev 键码/keymap 内容面/modifiers
  态机/axis 族 frame/多产者队列/ring3 守护/ISR 转接臂五臂/毫秒时间源）+ PS/2 双源
  （IRQ1 键盘 + IRQ12 aux 三字节包态机）+ ring3 aux 驱动进程（AUX_SVC_ELF 第九形
  驱动形 + SYS_AUX_READ 阻塞读 + SYS_PTR_INJECT 生产闸）+ Enter/Leave 域联动
  （焦点切换光标格直标）+ 损伤联合域（SYNC 矩形/合并上限细化/16px 粗粒度联动/
  光标 sprite 渲染面）+ rdtsc lfence 序列化读（t101-t131）。
- **四笔收官**：IntelliMouse 击键命令链 + wl_pointer axis 电气源（ACK 预算过滤
  ——电气源首实证）+ click-to-focus 焦点迁移联动面（按钮域 hit-test + 键盘焦点
  迁移取证戳）+ wl_keyboard.repeat_info 键重复公告面（keymap 后随行官方序 + v0
  关闭声明口径）+ 本收尾对账批（挂账九项复核翻账 M43 候选池——t132/t133/t134）。

## v0.27.0（2026-11-08）—— M32–M40 九里程碑连发：SDK/权限中心 + busybox 全链 + 服务化纵深 + 多用户 + 桌面电气化 + 网络收口

> 九里程碑（M32 七笔 / M33 九笔 / M34 七笔 / M35 八笔 / M36 八笔 / M37 五笔 /
> M38 三笔 / M39 八笔 / M40 六笔，各含收尾对账）+ M41-DEV 装置适配笔连续落账；
> 本版为 workspace 升版定版（v0.26.0 → v0.27.0），裸机自检 80 → **96** 项
> （t81…t97 续编；t95 号位随 ash 撤闸跳号如实登记）。五维成熟度 v1 6.0 →
> **v4 6.7**（docs/MATURITY.md 复评链）。

### M32（Aurora SDK/权限中心）
- **A1 权限中心首割**：aurora 转 no_std+alloc + perm 四相面（声明 schema 闸 →
  承接授予〔vanguard 桥，本体零改动〕→ 检查显形 → 撤销显形）。
- **S1 SDK 最小服务面**：声明式注册折叠 + 生命周期框架面（AF-P06 唯一入口 +
  终态权限收口）+ 意图路由骨架。
- **B1 AF-P01 基准口径**：宿主冷启动基准桩 0.18 ms（满载 16 应用 × 48 能力，
  预算余量 663 倍 + 回归哨兵闸）；端到端口径随用户态进程基础设施挂账。
- **t81 aurora 活体**（三面内核态收口，80/80）。

### M33（P1 末 DoD 收口：busybox Linux 兼容全链）
- **bedrock::elf** ELF64 静态加载器（十三目解析防线 fail-visible）+ Linux
  初始栈（AT_ 哨兵集）；**conduit::translate** Linux 号域映射面首批
  （M33-L1）；**fork**（COW 地址空间复制 + 子代全量快照定点恢复，M33-P1）；
  multiboot1 module 制备通道（M33-F1）。
- **t82 busybox 活体**：Alpine 官方静态 busybox 裸机真跑全链（ELF 直载 →
  musl 初始化 arch_prctl/brk/mmap → fork 族 → applet 分发 → write(1) 取证 →
  exit_group → waitpid 收割）——Linux 兼容路径从纸面绑定面兑现为执行面。
- **M33-R1** 长稳 harness（S10-longrun 双面板 + RUNBOOK 前置）；**M33-X1**
  五维成熟度首评 v1 = 6.0/10。

### M34（服务化首割 + 旁路缩编二批 + 电源语义面）
- **kernel::svc** 服务注册表定容面（SVC_MAX=8 + 五驱动 boot 注册 + LUMINA-SVC-INIT
  证据行）+ bedrock svc 契约单一事实源（M34-D1）。
- **quill 新 crate**：console/tty 纯函数面 crate 化外移（旁路缩编批次二——
  串口日志翻译核 + tty 行分类核，宿主 golden 21 目）（M34-D2）。
- **power 电源协同显示语义面**（M34-P4）：DisplayState 三态 + Directive 协同
  指令集 + DIM_STEPS 亮度档位契约 + can_transition 迁移表（AF-P06 同构）。
- **t83 applet 扩容**（true/false/printf/wc）+ **BUSYBOX.md 覆盖度成像表**落库 +
  M34-R1 RUNBOOK 执行手册（真机窗口机制面收口）。

### M35（H-P01 闸 50→150 + busybox 批次二）
- **harbor 四批扩容 57→158 符号**（H1a time 14 / H1b search 15 / H1c unistd 7 +
  string/stdlib 28 / H1d wctype/wchar 37）——**H-P01 ≥150 细则 DoD 硬锚兑现**
  （forbid unsafe 全 crate 纪律保持）。
- **M35-BBa** fork fd 继承 + pipe2(293) 执行面；**M35-BBb** sh 流水线首割
  t85（`yes | head -n 3` 两段真流串联——`|` 解析 + fork 锁窗铸槽 dup2 等价 +
  stdio 重定向分流面）。

### M36（xxh3-128 + TCP 电气 + 阻塞管道 + 布局根治）
- **crystal xxh3-128 全量口径**（M36-C1a/C1b——CR-P10 转正：双算法并存互拒 +
  40 长度点规范向量 × python 参考实现 + 单位翻转雪崩 + 条带边界扫描）。
- **kernel::vnet TCP 电气接线** t86（M36-N1——TCP_PORT_CAP 16 端口表 + 回环
  交接 + 外部 TX）+ **prism alpha 混合纯函数面**（M36-A1a Argb8888）。
- **M36-L1 布局敏感缺陷根治**：boot 页表移出栈下行火线（.boot.bss 重排 +
  boot 栈 64→256 KiB + L3 涂鸦哨兵显形——缩栈证伪实验双形态在案）。
- **M36-BB3a/b 阻塞式管道 I/O**：等待队列内核面（O_NONBLOCK 收录 +
  WaitWhat::PipeRead/PipeWrite + 死亡唤醒双链）+ t87 四相位电化学 +
  **stat 车道根治**（fd_stat_mode_size lseek-END 权威——SYS_STAT 16 位尺寸
  三代潜伏溢出）。

### M37（fb 合成电气化 + TCP 重传面）
- **M37-⓪ 环境复原批**：跨核 FSBASE 上下文接管根治（跨核迁移 musl errno 域
  #PF 3/3 确定性根治）+ t69 收讫对账。
- **M37-A1b 合成电气化**：prism::SurfaceTable→Stack::blend（SYS_FB_SURFACE(40)
  三操作 ABI v0.18 + t88 alpha 双锚 VRAM 读回 + 空表回退逐位同构）。
- **M37-N1 重传面 v0**：pulse::tcp 协议机纵深（RtoTimer TSC 纳秒重传臂 +
  SendWindow 滑窗 + ReasmBuf 字节粒度重组窗，t89 六相位——M27-T1 偏差转正）。

### M38（质量轮：竞态根治 + TCP 服务化）
- **M38-SP1 slots_pair 空槽切换竞态根治**：block/halt 双臂 M11-D 握手旗闸
  （M22-③ 双核同槽鬼影根治——旗清前拾取面拒绝 + 停机臂 woken/probe 自救援）
  + t90 风暴活体（blk+=318/wake+=318 严格配对零丢失唤醒）。
- **M38-TCP1 服务化五面**：WinScale RFC 7323 选项面 + RttEst RFC 6298 整数式
  Karn 窄化 + CcState RFC 5681 简化域三态 + PersistTimer 零窗探测 +
  ConnTable 定容 8 槽四元组查表——t91 六相位 + 宿主 27→44 例。

### M39（六候选全落账）
- **BBLS**：busybox ls 深链 t92（乱序制备→排序输出内容级断言首例 +
  **stdio 保留域三代隐匿根治**〔「先开后写」stdout 互踩——open 槽搜索自 3 起〕
  + readlink(89) 号域勘误 90→89）。
- **MU 多用户纵深 v0**：任务凭据四元（spawn/fork 全量继承）+ 身份六号真面
  （105/106=setuid/setgid 勘误）+ setuid 根域收口 + VFS 权限门禁覆盖表 +
  t93 busybox id 端到端。
- **DPMS 电气面**：stdvga SR01 消隐位 + Misc Output 同步极性域四态读回闭环
  t94 + M34-P4 登记面电气挂接 + PR-P04 引用偏差勘误。
- **HBI**：ostd::capi 指针基元层 + harbor::abi 12 符号 extern "C" 导出面
  （H-P01 158→170 双面在环）。
- **PDF 对账**：docs/PDF-RECON.md 落盘——22 份指南原件 15 族 108 项三态对账
  （细则 PDF 介质失联五代挂账摘牌）。
- **MATURITY v4 = 6.7/10**（功能 6.8→7.0 / 安全 6→7.0 双升档）。

### M40（四候选全落账）
- **ASH2 ash 启动链滞点标本流程**（置首）：三步全落——定根因（-d int 标本：
  lumina_syscall_entry CPL0 用户栈 push #PF e=2 不走 stack_grow → 致命 #DF，
  M22-③ 族 ISR 抢占窗高能击发）→ 互斥（PERCPU_IS_USER 三闸 + 换入向闸——ring3
  回归事件驱动调度，S8 24s→9s 提速实录）→ 回归（t34/t40 装置事件驱动化适配 +
  t95 备置撤闸 + 号域勘误 109=setpgid/110=getppid 真面/111=getpgrp）。
- **CRYSTAL 盘上属主域**：Lfs InodeRec v2（FORMAT_VERSION 2 bump——uid/gid/mode
  三域 64B 定容重排）+ chown(92)/chmod(90) 号域收录 + 门禁回源双车道 +
  stat 属主真面 + t96 六相位（**M17-① ATA PIO 块层字节域缺陷标本随行揭雷**：
  @1..7 域值域相关 <<4 错位——组位域判定与 grp mode 裸机读回如实降级随块层
  批次清账）。
- **CAT cat applet 实证**：t97 内容级断言（sendfile 车道实测 + 负例域）——
  applet 覆盖度第 10 目，M36-BB3b/M39-收尾 双挂账摘牌。
- **PRP04 Vulkan 计算域语义面 v0**：prism::compute（SPIR-V 1.3 解析壳
  fail-visible 防线 + 计算管线登记面定容 8 槽 + 标量求算核 GLSLstd450 子集
  逐位确定性感）+ 旧误引标签收口（硬件 Vulkan 队列挂账不变——真机窗口）。

### M41 起步（装置适配笔）
- **M41-DEV 门禁装置适配批**（沙箱重建介质复原后基线复绿）：T90F t90 收割
  计数锚全局化（idle-reap 桥竞态——ORPHAN_REAPS 窗口增量）+ T87F t87 同步锚
  PIT 墙钟预算（5 s deadline，M40-ASH2 t95 装置同款）+ T40F t40 coop 存在性
  锚降级（事件驱动化后 yield 计数归属随主机时序漂移——证据面保留）+
  S4F harbor 测试面串行（errno 进程级全局模型对齐）。**w 长度域跨 reap 调用
  值漂移一次实录随行登记（M22-③ ctx 切换窗族观察样本）**。

### 工程与门禁面
- 裸机自检 80 → **96**（t81 aurora / t82 busybox / t83 applet / t85 流水线 /
  t86-t91 网络 / t92 ls / t93 多用户 / t94 DPMS / t96 属主 / t97 cat——双端
  计数同步；t95 号位随 ash 撤闸跳号如实登记）。
- 宿主测试 ~470 例 / 40 套件（crystal 112 / harbor 57 / pulse 44 / ostd 42 /
  bedrock 39 / meridian 35 / loom 24 / conduit 21 / weave 21 / aurora 19 /
  prism 19…）。
- 文档体系：ADR 八篇维持 + docs/PDF-RECON.md 新落 + docs/BUSYBOX.md 成像表 +
  docs/RUNBOOK.md 执行手册 + METRICS 全表扩记 + MATURITY v1→v4 复评链。
- 全部提交 xtask ci 十一阶段门禁全绿；窗族（t73 残余 / t15 转投竞速）冷却
  重试口径如实登记。

### 既有偏差与挂账（随版延续）
- ash 全量启动面（栈 grow 缺陷族 × syscall entry 致命域——M22-③ 同族量级，
  M41 近线置首）；M17-① ATA PIO 块层字节域缺陷族（InodeRec v2 首用显形）。
- ash 交互面（阻塞式 tty read）+ 多用户纵深二批（saved-set/补充组）+
  重传面域外余项（快速重传/快速恢复、SACK、时间戳选项）。
- t73 残余窗族 + t15 转投竞速窗族；24h/72h 长稳正式记录 + DPMS 背光调光 +
  PR-P04 硬件 Vulkan 队列 + 环境 B 绝对基准全谱（真机窗口）。
- [B] rip=-1 蹲守挂账延续（哨兵面不动）。

## v0.26.0（2026-10-25）—— M29–M31 三季连发：Harbor libc + Weave 对象库 + 桌面骨架 + 自举预备

> 三里程碑（M29 五笔 / M30 七笔 / M31 六笔）+ M32 计划笔连续落账；本版为
> workspace 升版定版（v0.25.0 → v0.26.0），裸机自检 78 → **80** 项
> （t79 desktop-skel / t80 bootprep 续编）。

### M29（Harbor libc 首版 + Weave 对象库）
- **ADR-0003 执行步**：kernel 内嵌堆分配器迁 ostd::heap（Bump + free-list，
  冒烟 heap 行实录）+ harbor 重铸 libc 符号面身份——**H-P01 首批 57 符号**
  （errno/string/ctype/stdlib，`forbid(unsafe_code)`）+ allowlist 政策边
  销账三项（19→17）。
- **Weave store 内容寻址对象库**：ObjectId = FNV-1a 64（经典向量锚定）+
  put 去重同内容同身份 + 定容槽存满拒收 fail-visible + verify 重哈希校验
  （位翻转检出 VerifyError）。
- **WE-P02 断电注入框架**（journal）：GenRoot 双代际根槽轮换 + 提交点 =
  活跃指针翻转 + PowerFault 四相注入矩阵（AfterPrepare/MidRootWrite 撕裂
  残槽/BeforeFlip/AfterFlip）+ CRC32 IEEE 802.3 向量锚定 + 崩溃重试代龄
  严格递增。
- **恢复语义裁决**：Recovery 报库态不报事务命运（AfterPrepare 掉电后库态
  与正常态不可区分——RolledBack 伪变体删除，事务命运归策略面）。

### M30（桌面骨架：Loom Elm + Cascade shell + Glyph 渲染）
- **Loom Elm 架构**（LO-P01 口径挂接）：App 消息折叠环（同序列确定性折叠
  可重放）+ ViewBuf 定容零堆平面元素树（三索引链结构性防环 + 全闸
  fail-visible）+ 约束求解布局（8px 网格闸 OffGrid/Overflow 溢出闸/Fill
  余数归首子确定性）+ 虚拟化列表可见窗纯函数；布局产出 mirror::Rect
  几何单一事实源延伸。
- **Cascade shell 语义四面**（CA-P05 结构面）：四态机非法迁移拒收 +
  Workspaces 定容工作区表（窗口全局唯一归属 AlreadyOpen）+ master-stack
  平铺计划（保留域消费 loom 骨架常量，产出 mirror::Rect 供 prism 直接
  消费）+ Dock 定容登记面（glyph 档位闸）；no_std+alloc 转换。
- **Glyph 渲染库本体**：IconDef 静态注册表（24 源网格几何基元声明式图标）
  + 同源缩放光栅化器（map_point 唯一合法路径——ADR-0007 勘误后合规模型
  兑现）+ 描边随倍率 + 有界写入越界裁剪。
- **t79 desktop-skel 活体**：六闸（shell 面/平铺 golden/Elm 布局同源对账
  〔两套面同一几何〕/图标像素/prism 仲裁/fb 交盒哨兵）；自检 78 → 79。
- 搭车件 M30-X1：pcap 滤波升级取证（t73 设备级 RX 选择性死亡第三形态
  登记——netdev 75 帧 vs guest 10 帧，结构闸完好形态）。

### M31（自举预备：驱动用户态化起步 + Weave 自举）
- **驱动旁路台账首版成像**：kernel 内驱动面五清点（vnet 1,743/fb 953/
  kbd 250/console 212/block 134）+ 策略面两区分（tty/shell）+ 电气面/
  纯函数面/策略面三分缩编分级——每里程碑核销，缩编进度入 METRICS。
- **morse 首割外移**：kbd scancode 集 1 翻译面 crate 化（translate/
  shift_event/is_release 纯函数，零依赖 forbid unsafe）+ 宿主 7 例 +
  match 体机械对账零漂移 + kernel::kbd 消费面切换；政策面 24→25。
- **V-P05 首批注入矩阵**：vanguard 四相×不变式（越权派生/撤销后使用/
  未安装槽两级语义/重复撤销）+ derive 链传播语义全枚举（宿主 3→5 例，
  库本体零改动实现零缺陷显形）。
- **Weave 自举装载面**：boot::bootstrap 幂等库态序列封装（gen1 基线恢复
  + 三不变式四相复演 + store 根装载同源对账）+ BootReport 结构化报告 +
  kernel 启动序列挂接 fail-visible + LUMINA-WEAVE-BOOT 证据行（xtask S8
  必检行 5→6 机器可验）；宿主 18→21 例。
- **t80 bootprep 活体**：三面贯通（V 注入矩阵结论 + Weave 自举装载证据 +
  morse 外移面对账）；自检 79 → 80。

### M32 起步（Aurora SDK/权限中心计划）
- **ROADMAP 落盘**：§四 M32 七笔任务级分解（v0.26.0 定版前置 + 权限中心
  四相面 + SDK 最小服务面 + AF-P01 基准口径 + t81 活体）+ §三 M32 行
  🚧 + §1.1 P4 行刷新 + 远线行更新（M32 计划笔随开工裁决）。

## v0.25.0（2026-10-25）—— M25–M27 三季连发：兼容路径 + Crystal 文件系统 + 网络栈收口

> 三里程碑（M25 六笔 / M26 十笔 / M28 七笔 + M27 七笔）连续落账；本版为
> workspace 升版定版（v0.24.0 → v0.25.0），裸机自检 74 → **78** 项
> （t75 conduit / t76 crystal / t77 stage 合成 / t78 UDP 回环续编）。

### M25（Conduit 兼容路径）
- conduit::defs 20 结构 Linux 5.15 x86_64 UAPI 布局面（repr(C) no_std 纯布局）+
  conduit::layout 双闸（编译期 const 断言矩阵 + SNAPSHOT 行表，**C-P04=0**，
  SockAddrIn align 偏差当场拒收实证）。
- conduit::convert errno 事实源 36 值域 + LXE1 ERR_* ↔ errno 双向映射 +
  open 模式域 flags 双向 + **BINDINGS 25 调用全绑定**（C-P01 首批 ≥20）。
- t75 conduit-compat 活体（布局快照裸机锚定 + errno 正向全表/反向往返）。
- 搭车件 M25-C1-a：t73 迟到回声电气加固（发后收讫闸 + 拍钟窗），残留 ~10%
  挂率挂账 M27。

### M26（Crystal 文件系统首割）
- 格式 v1 规格书（crystal/docs/format.md F-01..F-14 ↔ layout.rs 对号）+ XXH64
  校验和规范向量锚定 + codec 解析防线四道。
- WAL 写前日志（环形回绕语义 + 回放逐节点重验 + RecoveryStats）。
- COW B-tree 首割（整路径复制 + upper_bound 选臂 + 分裂冒泡，2000 键对账）。
- 快照/子卷 O(1)（根指针 + 代际登记，跨规模分配等值实证 = CR-P05 结构面）。
- crash-fs 断电注入 ≥1000（全量逐扇区扫 ~1500 样本 + 撕裂 ≥100 + 位翻转 96 点
  全检出 + wal_discard 重验拒收专测）。
- ADR-0002 迁移步（bedrock::vfs 八文件清零 → crystal::vfs/meridian::vfs +
  bedrock 零依赖收口 V1-c + 政策边七立）。
- t76 crystal-compat 活体（ATA 真实介质 format v1 → 事务写读 → 回放采纳 → 快照）。

### M28（显示栈闭环）
- prism crate 骨架（z 序仲裁 + 交盒裁剪 + 逐像素裁决，胜者单写 overdraw 恒 0）。
- mirror drain_plan 合成消费面（读出复位一体 + 三态计划）。
- kernel::fb 组合器服务化（SYS_FB_STAGE(39) abi v0.17 + stage 页帧表散帧 +
  fb_compose_tick 交盒局部上屏；ADR-0004 双轨共存）。
- 1080p 模式切换（dispi 1920×1080@32，LFB_BYTES 8294400）。
- t77 compose-spec 活体（交盒内五点等值 + 交盒外哨兵零触碰 + 二拍空账直返）。

### M27（网络栈收口）
- **ADR-0005 执行步**：pulse::SpscRing 退役（环单一事实源归 ostd::sync::spsc）+
  pulse 纯协议面化 + `forbid(unsafe_code)` 全 crate + allowlist 白名单销账。
- **t73 丢帧类收口**：rx_service 排水限流（drain 批量受环余量前置约束——交接面
  PULSE_MISS 结构性归零，丢帧变延迟 fail-preserve）+ 残帧显形 RX_SHORT + pcap
  全账取证（slirp 反射恒达 + 设备级双面死亡登记环境时序面，版本对照铁证）。
- UDP 数据面首割（pulse::udp：UdpHdr 双闸编解码 + RFC 768 伪头校验和 + 手工
  向量双例 + PortTable 定容绑定表三闸）。
- vnet UDP 接线 + t78 回环活体（六闸：绑定域/回环三发载荷三态边界/校验和翻位
  拒收/未绑定拒投/解绑复绑；交接环共享段与真实 RX 通路同构）+
  **PU-P03 回环延迟口径挂接**（TSC 纳秒打点，TCG 基线 rtt 10μs–0.84ms 实录）。
- TCP 首割（pulse::tcp：TcpHdr 三闸 + 校验和伪头 proto 6 参数化共用折叠核心 +
  八态状态机骨架 + 握手序号推进面主/被动全序与非法迁移全枚举；vnet 电气接线
  挂账）。
- lint 台账政策边 +1（lumina-kernel→pulse）；METRICS PU 行扩记。

## v0.24.0（2026-10-22）—— M23：交互与电气面季（键盘/TTY/shell 交互闭环 + 显示三面服务化 + virtio-net 三段接线）

### M23-①② 交互基座（键盘 + TTY + init shell）
- **PS/2 键盘驱动 + TTY 行规程**（M23-①）：Irq1 桩 + i8042 自测 +
  scancode 集 1 翻译 + 行规程（回显/退格/行缓冲）；自检 63 → 64。
- **SYS_TTY_GETCH + init（PID 1 ring3 shell）**（M23-②③）：getch 面
  （lines/drop 取证字段）+ init 任务常驻 shell（interactive 特性面）。

### M23-A shell 深化
- **A2**：help/ver 直答 + echo 参数面（首双字分派三臂扩展）。
- **A3 搭车件**：shell clear 命令（ANSI 2J+H 经 SYS_LOG）+ help 清单扩容。

### M23-B/S 显示面三步（首帧 → 服务化 → 文本渲染）
- **首帧**（B）：stdvga dispi LFB 内核态直画 + mirror 损伤合成三帧面
  （t66/t67；LUMINA-FIRST-FRAME + LUMINA-MIRROR-OK 取证行）。
- **服务化**（S1）：Surface 表 + SYS_FB_MAP/SYS_FB_SYNC（首请求者 CAS
  独占）+ 任务根 LFB 映射——shell 直画 framebuffer 通路成形。
- **文本渲染**（S2）：SYS_FB_TEXT(37) 内核侧 8x16 字体直画（t70 +
  shell text 命令；gen_font8x16.py 字库生成）。

### M23-C virtio-net 三段接线（探测 → 数据面 → pulse 交接）
- **C1 带网首段**：virtio 1.0 modern 探测/bring-up + t68 电气活体
  （MAC/queue 数/isr 状态全命中）。
- **C2 数据面**：vring RX/TX + ARP 广播应答电气活体（t69：slirp
  spa=10.0.2.2 回包五条命中闸）+ PCI bus master 使能定案（四层取证
  根因链：bus master 关闭时设备侧地址空间恒 unassigned）。
- **C3 pulse 环交接**：RX 排水面喂 SPSC 环（FrameSlot×8 深度）+
  t71 可持续预填活体（pushed/popped/miss 三计数 fail-visible）。

### M24 起步（计划 + 对账）
- **ROADMAP 落盘**：指南对齐差距成像 + ADR 议程八项（0001-0008）+
  M24→M31 里程碑总规划 + M24 任务级分解（docs/ROADMAP.md）。
- **ci 冒烟面对账**：S8 补 virtio-net-pci 参数 + 自检计数 69 → 71
  （M23-C3 欠账清）；rustfmt 锁定工具链对账（4 文件纯格式）。

### 变更
- 自检 63 → 71（t66 mirror 首帧 / t67 损伤合成 / t68 virtio bring-up /
  t69 ARP 往返 / t70 FB_TEXT / t71 pulse 环交接）。
- ABI 面：SYS_FB_MAP/SYNC（Surface 服务化）、SYS_FB_TEXT(37)、
  SYS_TTY_GETCH 新增；x86_64-unknown-none + rustflags 承载不变。
- 宿主测试全绿；clippy 双段 -D warnings；ci 九阶段门禁全绿
  （S8 冒烟 71/71 + 退出码 33 自动验收）。

## v0.23.0（2026-10-17）—— M22：稳定性收口季（六族根因收口 + [B] 猎场 v2.2 取证网常态化）

### M22-① census 败点名内化 + pf-hunt 大批次守候
- **census 无锁原子计数面**：SEQ/PASS_N/FAIL_N/首败签名（ff_vec/ff_rip）
  单行短格式（≤64B），三发射点（每 8 项进度 / fault 首发 / 退出终局）
  ——串口丢线盲区闭环（遗言面：QEMU 退出前保底一行定位项号/vector/rip）。
- **pf-hunt 大批次守候**：批模式台账（BATCH.log 逐轮即时 append）+
  断点续跑（PASS 轮跳过）+ 时间预算优雅收批（540s 预算 45s 刹车）——
  环境清理杀批不再失忆，数百轮级回归常态化。

### M22-② #GP@kmain 族根因根治（双闸 fail-closed）
- **根因定案（addr2line 三步法）**：t37 spawn 面.arm 窗口超时 child_root==0
  逃逸 → translate(0) 读物理 0（IVT 残留 0xF000FF56F000FF53）→ Walker
  第一级 load（PML4e→PDPTe，rip=0x135c6c）帧字段非规范 → #GP err=0。
- **双闸修复**：闸1 kernel t37（child_root==0 → ccode=None 早退）；闸2
  ostd Walker::translate（根帧合法面 + 中间层 canonical，全 fail-closed）。
- 回归 71 轮：#GP 硬崩 0/71 归零、零挂死。

### M22-③ t37 spawn 面时序收口（三族三修）
- **FIX-A r14 注入竞态**（585/664 定案）：子代 ctx.r14 创建时点焊接
  （parent pid 锁窗直取）+ trampoline_user 入口窗同窗双读 + 桥面免读
  （current_parent_pid/task_user_root 退役）。
- **FIX-B arm 捕获窗**（739/755/758/761/771 定案）：SPAWN_CHILD_ROOT
  内核侧原子戳（x86 TSO 存序保序）替代事后重读 + 窗 600→3000ms +
  spawn 行取证拆分（child_root/ccode 独立落证）。
- **FIX-C workers 收敛**（727 定案）：all_workers_finished 检查时刻竞态
  → 收敛预算 5000ms + stuck_workers() 点名直读（非 Zombie 任务逐槽
  报（pid, name, state）——814 首功取证）。

### [B+] waitpid 阻塞唤醒面收口（gated 补钉去 Timer 依赖）
- **814 标本定案**：M21-① gated 补钉挂 1ms Timer × tickd 派生点晚于
  t36 × S31 ISR 纪律下 TIMER_PENDING 无人消费——唤醒机制结构性缺位。
- **修复**：gated 分支 nanosleep → 单次 yield_now + 重扫（保存窗死者侧
  切换机无条件闭合，Timer 依赖移除）+ WAITPID_GATED 计数 + t36 行
  gated= 取证字段。回归 99 轮：814 形态 0/99（对照 1/70）。

### [B] 猎场扩网 v2.2（rip=-1 第二写者：恢复面帧哨兵 + 引导栈锚）
- **667/705/951/1005 四标本定案**：毒化帧 RIP@R0-0x28（fault_hook aux
  语义破译），毒化值 = -1 本体；nm 对号毒化帧址落 boot_stack
  [0xa03000,0xa13000) = 主任务引导栈保存帧盲区。
- **v2.2 布防**：ctx 白名单哨兵 + 恢复面保存帧逐字节毒化扫描（帧哨兵）
  + boot.rs 导出栈界符号双源化栈锚；DR1 动态栈蹲守撤案（TCG 热地址
  数据监视点 BQL 重入铁律，971/972 双轮实证）。在岗 52 轮零误伤零穿透。

### [C] 隐形断言族三面收口（ff24 环对分向 + ff46/ff52 唤醒误分类）
- **ff24（ipc-syscall-caps）**：FastPath 单向 SPSC 环被 channel 0 双向
  共用 → client 首个 RECV 弹到自发请求帧（自弹自收假成功）——FIX-I1
  环对分向（Channel.resp + echo_channel_pair + 应答落环定向唤醒）。
- **ff46/ff52（timer/tsc-nanosleep）**：block_current_impl halt 停机分支
  真实阻塞被重入探针按「探针命中」降格 → 唤醒计数被吞——FIX-T1 halt
  停机经历旗 + FIX-T1b sys_nanosleep 入口窗全时长流逝唤醒分类 +
  FIX-T2 MONO_FLOOR 全局单调地板（rdtsc 跨核契约外加固）。
- 回归双批 76+121 轮：**[C] 三面 0/121 结构性归零**（对照 ~2-6%/轮）。

### [X] 终局出口互斥（EXIT_GATE CAS 闸）
- **865 标本定案**：BSP 成功 0x10 与 AP 故障 0x60 双核并发写
  isa-debug-exit，后写者改码 → exit193 假败（63/63 全过 + census f0
  与 AP 窄窗不矛盾）。
- **修复**：kernel_exit 出口权 CAS（唯一赢家落 LUMINA-EXIT code= 取证行
  + census + 写口，输家原地停机）+ fail_exit 保底显形行
  （LUMINA-FAIL-EXIT vec=）+ 出口路径中断先关。冒烟 8/8 EXIT 行落证。

### 工程面
- 裸机自检 63 项保持全绿（QEMU 退出码 33 自动验收）；宿主测试套件
  全绿；clippy 双段（宿主 workspace / kernel 裸机 boot 面）-D warnings。
- pf-hunt 累计批次：m22p3-regress 71 / m22p3s2 70 / bplus-wake 99 /
  bnet-v2 100 / cclose 76 / cclose2 121——六族（#GP/r14/B1/[B+]/[C]/[X]）
  全部结构性归零；[B] rip=-1 毒化率 ~2%/轮带网发布（v2.2 哨兵在岗蹲守）。

## v0.22.0（2026-10-15）—— M21：钉扎拾取缺陷根因收口 + cont 哨兵在网 + Harbor free-list

### M21-① 钉扎拾取缺陷（首席：Type A/B 簇败族根因结构性封死）
- **根因定案**：S72 次级窗口正式转正——终结路径 `finish_and_switch_away`
  经 `slots_pair` 切换，不置 SWITCHING 旗不带 handoff（yield/block 两族
  均有旗护，唯终结裸奔）；Zombie 登记至锁外七槽保存完成之间，三收割面
  （wait_scan/reap_orphans/reap_zombies）可并行释放槽位 → alloc_slot
  复用 → **死者鬼影保存写入复用槽 ctx** → 新任务被拾取时运行死者续点
  （Type A 全签名：子任务连负探针都未执行 f1=0/sok=0/rw=0/父 p-state=3）。
- **修复（护槽三件 + 联动一件）**：①finish 路径 Zombie 登记即置旗 +
  双分支 with_handoff（切任务/切 idle 均经切换机器清旗）②三收割面一律
  `SWITCHING==0` 门③alloc_slot 入槽清旗（陈旗纵深防御）④wait_scan 增
  gated 出参，gated 时 sys_wait_pid 改挂 1ms Timer 重扫（防 Child 等待
  永失唤醒；探针不加门防 livelock）。

### M21-② cont 写者追捕（哨兵在网）
- `pickup_sentinel` 于四拾取点校验切换目标 ctx：cont ∈ [ktext_start,
  ktext_end)（linker.ld 新 PROVIDE 符号）+ rsp ∈ [stack_base, stack_top]
  自有栈界；违例 SCHED-BUG 全现场转储 + panic（活体标本 > 静默继续）。
- 冒烟 63/63 全程 SCHED-BUG 零命中 = 哨兵零误报；round-432 鬼影族
  （rip=-1 / 跨槽污染）今后由前置静态网直接指认写者。

### M21-③ Harbor free-list（开工即落地）
- `HarborFreeList`：first-fit + 地址序合并 + bump 晋升 + 载荷前垫对齐 +
  ZST 悬挂指针 + 头部完整性防线 + free_stamps 取证面；内核
  `#[global_allocator]` 由不回收 bump 升级切换（4 MiB .kernel_heap
  rebind 惯用法不变）。
- 宿主 5 测试（同址复用/三邻合并/对齐族/耗尽后回收/ZST+模式完整性）；
  内核自检 t63 heap-freelist-reuse（62→63）：a/b 同址 0x632130
  （∈ .kernel_heap）+ reuse=3——堆复用环上实证。

### 排障记档
- 宿主测试 SIGSEGV：无内部可变性 static 落 .rodata，free-list 写块头
  即写只读内存（bump 从不写 arena 故旧测试从未暴露）→ UnsafeCell 包裹。
- dealloc 记账两处（后邻合并块数下溢 / free_bytes 双重加账）由
  模式完整性测试直接逼出并修复。
- 环境复原：第十二链次（rustup 官源卡死 → 断点续传 + USTC 镜像）。

## v0.21.0（2026-10-14）—— M20：#PF 间歇性家族根因闭环（取证 → 标本 → ELF 对号 → 切换机器契约修复）

### M20-① 挂死根因闭环（round-417 铁证）
- pf-hunt 大批次 113 轮（round-305..417）复跑即捕：静默挂死 ×1（exit=124
  timeout 击杀）——LOCK-STALL ×200 连发 addr=0x1811e8 sched=1 **h-line=1660**。
- **根因（M19 idle_pick 同族第 4/5 裸拿点）**：`trampoline()` /
  `trampoline_user()` 双跳板在 `intr::enable()`（IF=1）后裸拿 SCHED 锁
  ——本核 LAPIC tick 命中持锁瞬间 → timer_hook（ISR IF=0 语境）等同锁
  → 同核互等死锁。42 个 `sched_lock!()` 调用点逐一比对，唯二无
  IntWindow 点即双跳板。
- **修复（b8e8abb）**：双跳板临界区包 IntWindow（M19 同款纪律，drop
  逆序保证解锁后才恢复 IF）。回归 30 轮挂死 0，LOCK-STALL 未再现。

### M20-②/③ #PF rip=-1 根因闭环（round-432 活体标本 → 五证归一）
- **活体标本捕获（round-432，回归第 15 轮）**：`vector=14 rip=-1
  cr2=-1 err=0`，iretq 帧 cs=0x8 rflags=0x10446 rsp=0xa12430；挂位 =
  ipc-fastpath-bench PASS 后（与 round-295 同位）。
- **取证面判读修正**：fault_hook 按 5 元读法打印的 rsp/ss 两字实为栈上
  旧值——ring0 #PF 硬件只压 RIP/CS/RFLAGS 三元；S69 记档「readdir 帧
  0x10446 嫌疑」正式撤销（rflags 残值误读）。
- **ELF 符号对号**：boot stack = [0xA03000, 0xA13000)（linker 符号
  boot_stack_bottom/top），标本 rsp=0xa12420/30/38 全落 boot stack——
  idle 语境实锤（任务栈为 Vec 堆分配，不可能落此区间）；IDLE_CTX
  @0xa14eb8、堆段 @0x600000 4 MiB。
- **根因定案：run_idle 违反 switch_deferred 的「切换期间 IF=0」SAFETY
  契约**（5 个调用点中唯一违约者）——idle_pick 内部 IntWindow 在函数
  返回时已恢复 IF=1，context_switch asm 中段被本核 LAPIC tick 打断 →
  timer_hook/resched 在「旧现场未保存完/新现场已部分加载」窗口重入 →
  target.ctx 被写成中段现场（rsp=boot stack 指针）→ 跨任务栈污染 →
  栈上 -1 残值（vfs RESULT 哨兵族）被 ret 消费 → 取指 #PF @u64::MAX。
- **全指纹互证**：rsp ∈ boot stack ✓；rip=cr2=-1 取指 err=0 ✓；
  ipc-fastpath（高频切换面）后命中 ✓；布局敏感（M17 机制同源）✓；
  批1/批2 簇败漂移同源 ✓。
- **修复（721f3a2）**：run_idle 的 IntWindow 覆盖 idle_pick +
  switch_deferred 全程（内部窗口 IF=0 下 no-op；continue 出作用域
  w.drop 恢复 IF=1 与循环头 enable() 衔接）。
- **回归（round-448..497，50 轮）**：#PF 0/50 + LOCK-STALL 挂死 0/50
  （修复前母轮率 1/113）+ 簇败 7 轮全为既有独立族（ipc-bind-runtime
  ×4 / exec-image-surface ×3 伴生 / waitpid-zombie-reap ×1 /
  ipc-syscall-caps ×1 / tsc-nanosleep ×1——S68 定型的发侧门禁拒绝与
  星化族，与切换契约不同源，记档结转）。

### 次级窗口记档（观察项）
- finish_and_switch_away 切换在锁外执行（Zombie 永不返回，guard 不可
  持锁切换）：drop(s) → switch 间 Zombie 槽可被另一核 reap + 复用 +
  boot_new 交错——保存写出值仍为合法 .text 返回地址（非 -1 源），
  概率极低；回归复现再收。

## v0.20.0（2026-10-12）—— M19-①：间歇性家族根因定位与修复（复跑即捕 → 铁证 → 三根因收口）

### 定位（取证面五级升级，306 轮复跑证据池）
- **一级（fp: 阶段戳）**：fastpath_bench 五点戳（enter/req0/kicked/
  waiting×8/exit，全带 TICKS 值）+ AP 侧首次服务戳（免分配串口直写）
  ——挂死轮指认 t19 完整跑通（served=1000），排除 FastPath 本体。
- **二级（LOCK-STALL 锁等待看门狗）**：`ostd::sync::SpinLock` 自旋
  2^22 次（PAUSE 计）阈值回调钩子（位与节流，正常路径零成本）；
  kernel 侧注册 `lock_stall_report`（锁地址 / SCHED 哨兵比对 / ticks /
  核号 / IF 旗）——round-038/046/049 铁证：双核同时自旋等 SCHED 锁
  （addr=0x17f1e8 sched=1）、双核 iff=0（ISR 语境）、ticks 冻结。
- **三级（HOLDER 行号遥测）**：`sched_lock!()` 宏 43 点替换
  （`sched_lock_at(line!())` 登记拿锁核 + 行号）——LOCK-STALL 戳
  直读最后持锁点。
- **四/五级（t41 族全套 + ENFILE 现场快照）**：父任务终态 / 退出码 /
  RECV 阻塞唤醒计数 / SEND 成败与四门禁分立计数；ENFILE 返回点
  锁内采样（seq/used/caps_alive）。
- **五形态画像（306 轮）**：静默挂死 ×6（8.1%，与 v0.19 NOTES 1/8
  吻合）+ 193 簇败 ×11（t29/t32/t41/t45/t52 漂移——失败项随布局
  漂移，M17「布局漂移放大」机制同源复证）+ #PF ×2（rip=-1 跳野 +
  堆恒等洞形态各一）。

### 根因与修复
- **根因一（挂死族，铁证闭环）**：`idle_pick` 在 idle 循环（IF=1）
  裸拿 SCHED 锁——持锁者被本核 LAPIC tick 打断，`timer_hook` ISR 等
  同锁互等死锁（同核永不推进）；对侧核 tick ISR 等全局被持锁亦冻结
  ——双核 iff=0、ticks 冻结、LOCK-STALL 交替刷屏。修复：
  `idle_pick` / `canary_audit_all` / `task::init` 三处 IntWindow
  包裹（Drop 逆序保证解锁后才恢复 IF）。回归：修复后 59 轮挂死 0
  （修复前 8.1%；统计显著）。
- **根因二（t45 ENFILE 族）**：注册表贴线泄漏——轮内 open 面任务
  终结 reap 时机竞态残留幽灵文件对象（round-239 指纹：used=32 /
  caps_alive=2，30 枚无能力引用占槽）。修复：open_impl ENFILE 分支
  就地 `reap_orphaned_files` + 重试一次（幽灵自愈）。
- **根因三（#PF 堆恒等洞，round-243 实锤）**：内核堆物理页撞用户根
  恒等镜像洞——用户根 PD[2]（0x400000..0x600000）展开为 PT 且
  PT[0]/PT[2] 留空给用户 code/stack（程序基址 0x400000 硬编码），
  堆物理 0x400000..0x401000 在借根窗口（任务终结 reap / swap 读回）
  恒等槽缺失 → not-present #PF（cr2=0x4004e1 = FILES Vec 缓冲 ∈
  PT[0] 洞；源码 442 行「PD[2] 恒等镜像不可拆位」注释为同坑开发期
  预警）。修复：`KERNEL_HEAP` 显式段放置 @0x600000（linker.ld 新增
  `.kernel_heap` 段 + `#[link_section]`；PD[3] 大页恒等区借根可见性
  恒成立），kern_end 随之抬升、帧池自新界起。
- **断言校准（t45）**：st=4（Zombie 在槽）或 st=0（槽位已收割）均
  合法终态——round-257 exit=90 + 槽位 None 实录（M17 加固 settle 窗
  兜不住收割竞态属采样过严，非内核行为缺陷）。

### 验收
- 九阶段 CI 全绿三连（CI-OK 8/8）。
- pf-hunt 回归 59 轮：挂死 0（修复前 8.1%）+ t45 全过；总失败率
  15% → 3.4%。
- **残余族（M20 候补，诚实记档）**：①#PF rip=-1 ×1/59（栈含
  driftsort readdir 帧，嫌疑 readdir 排序面；取证面全就位）
  ②t32 served=0 星化 ×1/59（echo=PING 帧实际送达但 served 计数 0，
  计数/实例错配面）。

## v0.19.0（2026-10-11）—— M18-①：#PF 专项取证面 + M18-②：fsck-lite 崩溃一致性 + M18-③：候补三条转正

### 新增
- **#PF 伪影链根治（M18-①）**：v0.18.0 观察记档的「iretq 帧实模式
  IVT 形态」实为取证面自身伪影——可恢复 #PF 桩致命分支从未设置
  rdx，钩子拿到的 aux = 主体返回后寄存器残渣，指向恒等映射低区时
  转储出的正是 IVT 内容，指向野值时 `read_u64(aux)` 自身二次 #PF
  （cr2=-0x28 同源）。本版 #PF 致命桩与可恢复→致命分支均传入真实
  帧指针（与 #GP 同款契约）；fault_hook 增 aux 合法性门
  （0x1000..0x1000_0000 且 8 字节对齐，拒读野值——宁可少读，不再
  制造二次 #PF）。
- **per-CPU 栈 canary 面（M18-①）**：栈底魔数 "LUMINACN"
  （0x4C55_4D49_4E41_434E）——`Task::new` 盖章（Kernel/User 同源）+
  AP 引导栈同源盖章（smp）；校验点 = `prepare_dispatch` 派发咽喉
  （五条派发路径唯一收口，锁内零分配）+ t59 全表审计；破坏即串口
  直写 `LUMINA-CANARY-FAIL` + 计数（自检断言零违反）。GS 哨兵方案
  作废（M8-A 定版：内核不使用 GS per-CPU 面，如实记档）。
- **slots_pair 自切换取证点（M18-①）**：a == b（自切换）= 调度面
  竞态实锤——v0.18 观察期即有本点 panic（len/idx 同值成对 2/2 与
  0/0）；本版升级为全现场转储（`LUMINA-SCHED-BUG`：双方状态 + 就绪
  队列在位性 + SWITCHING 旗 + 全队列内容）后再触达不可达断言。
- **fsck-lite 崩溃一致性（M18-②）**：LFS1 超级块脏旗（偏移 68）+
  `with_dirty` 包装四变更操作（create/unlink/truncate/write_at；
  失败路径有意留脏——保守方向：多余一次无害 fsck 优于漏一次）+
  挂载时一致性修复：根目录不可信 → 重格式化；BFS 可达集对账 →
  孤儿/幽灵 inode 回收；链越界防御回收；数据位图全量重建（泄漏
  清除 + 未标记活块补置）；目录 next_cookie 抬升（max+1）。修复
  报告四计数（`FsckReport`）+ `Lfs::fsck` 独立入口 +
  `last_fsck` 查询。**议案修正记档**：v0.18 议案推演的「cookie 回退
  窗口」实不存在（size/next_cookie 同一次 inode 写落地），修复面
  为纯防御 + 手工腐坏修复通道。
- **宿主故障注入族（M18-②）**：`FaultyBlock` 断电模拟盘（第 k 次
  写后静默丢弃——介质冻结在截断点）+ create/mkdir/unlink/write/
  truncate 全截断点扫描（幂等收敛断言：修复后再挂零修复）+ 手工
  腐坏四件（孤儿回收/泄漏清除/丢标记补置/cookie 回退修复）+ 根
  腐坏重格式化 + 脏旗生命周期。bedrock 宿主 87 → 99。
- **O_EXCL 排他创建（M18-③，abi v0.11 → v0.12）**：SYS_OPEN 模式
  bit4——O_CREAT|O_EXCL 且目标已存在 → `EEXIST(17)` 原子拒开
  （fs create 检查在 fs 锁内，无插队窗口；lockfile 语义基座）；
  无 O_CREAT 时无效应（POSIX 未定义域收敛记档）。
- **F_DUP2FD 精确槽位（M18-③）**：SYS_FCNTL 命令 3——dup2 面：
  精确槽落位 / 同槽位无操作 / 越界 EINVAL（对齐本内核 F_DUPFD
  语义；POSIX EBADF 偏差记档）/ 已开目标先关（OFD 引用计数递减
  ——EBUSY 卸载占用面联动）。
- **SYS_IMAGE_ENUM(33) 查询面（M18-③）**：EXEC_IMAGES ring3 枚举
  ——NUL 结尾路径拷入，返回 `(1<<32)|(总数<<16)|字节数`；越界
  ERR_IMAGE / 过短 EFAULT（零拷贝路径：长度校验先行）；ring3 自此
  免硬编码映像表。
- **pf-hunt 复跑统计面（M18-①）**：`scripts/pf-hunt.sh`——S8 同款
  QEMU 冒烟自动复跑（TLV 注帧定型：进程替换方案，FIFO 方案实测
  死锁记档），退出码 + 全量串口逐轮留存（lumina-build/pf-evidence/），
  失败轮自动保全证据。

### 自检
- 裸机 59 → 62：t59 canary-audit（全表审计 + AP 栈 + 零违反）、
  t60 o-excl-atomic-create、t61 dup2-exact-slot、t62 image-enum-face。
- 宿主 bedrock 87 → 99（fsck 故障注入族 +12）。

### 观察记档（M19 候补——诚实记档）
- **间歇性不稳定家族（v0.17 时代同源，v0.18 记档 #PF 的扩展画像）**：
  B3 基线 23 轮 pf-hunt 统计 = 19 过 / 3 静默挂死 / 1 自检簇败
  （58/62，t29–t32 IPC/调度簇）；挂死点漂移（demand-paging 后 /
  cap-grant 后），无 FAULT 无 CANARY 前兆——指向阻塞/唤醒/跨核
  派发织物的时序窗（slots_pair a==b panic 与 t24 served=0 同族）。
  取证面已就位（canary + SCHED-BUG 转储 + #PF 真帧 + 复跑统计），
  根因定位 = M19 首块。
- **布局敏感实证**：同源码几字节位移（slots_pair 取证分支 + fmt）
  即令 B2 六连 193 → B3 全绿——竞争窗口随代码布局成败（M17「布局
  漂移放大」机制同源复证）。

## v0.18.0（2026-10-11）—— M17-①：持久化存储面 + M17-②：readdir 稳定 cookie + M17-③：mount 占用检查

### 新增
- **块设备契约层（bedrock::block，M17-①）**：`BlockDevice` 特征
  （512 B 定长块读写 + 容量查询；实现方内部自持同步原语，与
  `FileSystem` 同款并发纪律）+ `MemBlock` 内存盘（宿主测试基座）。
  块大小与 ATA 扇区同宽（512 B），硬件适配零转换。
- **LFS1 盘上文件系统（bedrock::vfs::lfs，M17-①）**：RamFs 之外第二
  文件系统实装——超级块（magic "LFS1"）+ 位图 + 定长 inode 表 +
  数据块的盘上布局，跨卸载重挂（介质存续即数据存续）保持数据与
  **目录项稳定 cookie 的持久性**（per-dir next_cookie 随项落盘）。
  文件容量 = (10 直接 + 128 间接) 块 = 70 656 B；目录记录区变长紧排
  （删除为墓碑）；`format_or_open`（magic 无效即格式化——v0「挂载
  即接管」语义记档）。全操作粗粒度互斥（v0 确定性优先）；无日志
  （崩溃一致性 v0 不设防，如实记档）。
- **ATA 数据盘接入（kernel::block，M17-①）**：`AtaDisk` 扩展盘位
  选择（drive 位，新增 PRIMARY_SLAVE/SECONDARY_SLAVE 常量）——数据盘
  挂主通道从盘（QEMU index=1），与启动盘（index=0）同通道异盘、
  与 swap 盘（从通道 index=2）物理并行零通道竞争；`DataBlock` 零
  尺寸适配器（避免 impl 污染共享 AtaDisk 类型）；IDENTIFY 容量固化
  + LBA28 域防御。**惰性探测**置于唯一消费方（t56）之前——启动期
  探测的自旋窗口会拉开 t24 竞争（记档）。
- **SYS_MOUNT fs_type 扩容（abi v0.10 → v0.11，M17-①）**：parse 域
  0..=1——0 = RamFs（v0 语义不变）、1 = LFS1 盘上 fs（块设备未就绪
  EINVAL；挂载点校验同 M15-① 面）。裸机 t56 持久化闭环直证：首挂
  （格式化）→ O_CREAT 写 → 卸载 → 重挂（原样打开）→ 数据存续读回。
- **readdir 稳定 cookie（M17-②，v0.17 候补转正）**：`FileSystem::
  readdir_from(dir, after_cookie)` 新契约（默认实现 = 位置 cookie
  兼容语义；RamFs 覆写为插入序稳定 cookie——DirSlot 双表：name 字
  典序面不变 + cookie→(父目录, 名字) 序表；Lfs 覆写为盘上持久
  cookie 序）。SYS_READDIR 游标从项序号升级为**最后交付项 cookie**
  （OFD pos 域专用）——枚举中途增删不漂移（getdents64 同款语义域）。
  RamFs/Lfs 宿主漂移测试族 + 裸机 t57（首读后中途新建+删除已交付
  项 → 续读恰见新项）直证。
- **mount 占用检查（M17-③，v0.17 候补转正）**：`FsError::Busy`
  （EBUSY 16）+ `FsError::NoSpace`（ENOSPC 28）错误域扩展 +
  `Namespace::unmount_if_idle(path, busy)`（检查与摘表同挂载表锁
  原子）；SYS_UMOUNT 以文件注册表扫描复核（Arc 同源判定）——挂载
  fs 上有存活打开句柄（含 dup 副本，OFD 引用计数语义）时 EBUSY 拒卸，
  关闭后放行。裸机 t56（盘上 fs 面）/ t58（RamFs 面 + dup 深化）直证；
  t50 的 M15 旧语义断言（带句柄卸载放行）同步升级为 EBUSY 正向断言。

### 修复
- **install_echo_caps 派生落点漂移（t24 根治）**：原实现断言
  `derive(parent) == Ok(child_slot)`——而 `CapabilityTable::derive`
  返回**动态首空闲槽号**，「恰好 == 2」是与前置自检槽占用状态耦合
  的临界条件（v0.17 归档四轮两轮 193 即此漂移；M17 冒烟六连红为
  布局漂移放大实证）。改为同权子能力**显式 install**（语义等价、
  落点确定）；配套 SYS_SEND/RECV 诊断取证面（DIAG_* 计数 + 失败点
  分立）落 t24 日志行。
- **t45 zombie 采样竞速**：deadline 超时与 client 完成竞速时，
  exit 落定与 zombie 登记间存在跨核采样窗口（exit=90 + state=0
  翻转红实录）——补 300 tick 收敛窗。
- **t50 fs_type 保留域探针**：fs_type=1 转正后，越域探针同步改用
  fs_type=2（EINVAL 语义保持）。

### 自检
- 裸机 55 → **58**（t56 lfs-persist / t57 dir-cookie-stable /
  t58 umount-busy）；xtask S8 增挂 LFS1 数据盘（1 MiB index=1，
  每轮全零重建 = 格式化路径确定性覆盖）。
- 宿主用例 146 → **168**（block 5 + Lfs 10 + RamFs cookie 5 +
  unmount_if_idle 2）；abi parse 域测试同步扩容。

### 观察记档（非本版缺陷，M18 候补）
- **偶发 #PF（≈1/8 轮）**：t19→t20 间隙内核跳转 rip=-1 → fault_hook
  链式故障（iretq 帧呈实模式 IVT 内容形态）。v0.17 时代已存在
  （归档轮次即有非零退出），M17 未触碰该路径；M18 候补专项。

## v0.17.0（2026-10-11）—— M16-①：文件创建面 + M16-②：Weave 包源映像 + M16-③：栈增长动态扩容

### 新增
- **文件创建面（abi v0.9 → v0.10，M16-①）**：SYS_OPEN 模式域扩展
  O_CREAT（bit2）与 O_TRUNC（bit3）（`OPEN_MODE_MASK` 单一事实源）。
  O_CREAT：目标缺失时经父走查新建常规文件（POSIX 同款——父必须已
  存在且为目录，中间缺失 ENOENT(2)；已存在直接打开，v0 无 O_EXCL，
  如实记档）；O_TRUNC：以可写方式打开成功后将节点截零（只读不截、
  目录 EISDIR(21)——v0 简化语义记档）。文件面从「只读播种」走向
  ring3 自主创建。
- **FileSystem::truncate（bedrock::vfs）**：O_TRUNC 支撑面——默认
  NotSupported，RamFs 实现（仅常规文件；目录 IsDirectory、缺失
  NotFound）。宿主测试 1 项（截零/EOF/重写/负探针）。
- **Weave 包容器格式 LWP1（weave::pkg，M16-②）**：32B 头（magic
  "LWP1"/fmt 版本/semver 三段/name_len/payload_len）+ 名字区 + 载荷
  紧排；`encode`/`parse` 纯函数对（结构归 weave 宿主测试钉死，载荷
  的 LXE1 合法性归内核装载器——LXE1 同款职责分层）。weave crate 转
  `no_std + alloc`（内核 EXEC 装载链可依赖；宿主测试不受影响）。
- **EXEC Weave 包源映像（M16-②，EXEC 第 2+ 消费者，v0.15 候补转正）**：
  sys_exec 取段 blob 非 LXE1 魔数时（`bedrock::exec::parse_probe`
  分流面）尝试 LWP1 解包取载荷进入同一 LXE1 装载链（载荷合法性仍由
  装载器 parse 承担，单一事实源）；EXEC_IMAGES 表 3 → 5（追加
  prog.lwp / deep.lxe）；vfs::init 播种 prog.lwp（LWP1 包装
  org.lumina.prog v1.0.0，载荷 = prog.lxe）。
- **栈增长动态扩容（M16-③）**：vmm 增长窗口动态化——静态 32 页窗外
  触达经 `grow_extension` 纯函数判定（扩展带 = 紧贴下界的 32 页；
  `STACK_GROW_STEP`=32、`STACK_GROW_MAX`=128 硬顶），扩展带内扩窗
  落账（GROW_WINDOW_PAGES/GROW_EXTENSIONS 取证面）后继续补帧；越带/
  硬顶拒绝 → 故障重递走上层致命路径（自保护与 M14 同款）。耗尽探针
  = 策略面直调（t55：窗内 None/扩展带 Some/越带 None/硬顶 None）。
  DEEP_LXE 深触映像（scripts/gen_m16_images.py 产出，触页 40/70
  各触发一次扩窗 32→64→96）。
- **SYS_QUOTA kind 3（M16-③）**：栈增长窗口用量（used = 累计扩栈
  页数、cap = 当前窗口页数，全局口径）；abi parse 域 0..=2 → 0..=3。

### 变更
- 自检 52 → 55（t53 file-create-o-creat / t54 weave-package-image /
  t55 stack-growth-dynamic）；宿主用例 141 → 146（weave::pkg 4 +
  RamFs::truncate 1）；xtask SELFTEST_EXPECTED 52/52 → 55/55。
- t50 directory-face 枚举断言适配新播种面（/files 8 → 10 项——
  prog.lwp/deep.lxe 入列；acc_scan 名单同步扩容）。

### 修复
- open_impl 的 `OpenFlags::from_bits` 改取访问位（低 2 位）——原始
  mode 含 O_CREAT 修饰位时被拒收的缺陷（t53 排障记档）；
  OPEN_MODE_MASK 补 O_CREAT bit2（0b1011 → 0b1111，漏位致 O_CREAT
  族全数 EINVAL——同轮排障记档）。

## v0.16.0（2026-10-10）—— M15-①：目录面 + M15-②：句柄面深化 + M15-③：TSC 纳秒面
