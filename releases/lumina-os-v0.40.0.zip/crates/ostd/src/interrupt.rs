//! 中断基础设施：IDT 门描述符 + 手写中断桩（HW-05 配套，CONTEXT 白名单外延）。
//!
//! rustc 1.99 的 `extern "x86-interrupt"` ABI 仍为实验特性
//! （`abi_x86_interrupt` 门控），故 M3 采用经典手写桩方案：
//!
//! - 每个受支持向量一段最小汇编桩（本模块 `stubs`，框架内核白名单）：
//!   仅保存 caller-saved 寄存器 + 显式对齐栈后调用 Rust 主体；
//! - Rust 主体（`extern "C"`）遵循 SysV ABI，自行保护 callee-saved；
//! - 异常桩路径为「诊断即退出」：向量号经寄存器传入主体，永不返回。
//!
//! 受支持向量（M3）：32 = IRQ0 定时器（tick + EOI）；0/6/13/14 =
//! #DE/#UD/#GP/#PF 致命异常（经故障钩子退出，见 [`set_fault_hook`]）。
//! 其余向量不注册——误触即三重故障，冒烟阶段以非 33 退出码暴露。
//!
//! M5 新增两类桩：
//! - `isr_ipi`（向量 0x40，LAPIC IPI）：定时器同构的对称保存/恢复，
//!   主体转交注册钩子（内核侧完成击落处理 + LAPIC EOI）；
//! - `isrf_pf_rec`（向量 14 的**可恢复**版）：完整保存 caller-saved 现场
//!   → 主体（rdi=CR2，rsi=错误码）返回 handled 标志 → handled 则对称
//!   恢复 + 丢弃错误码 + iretq（故障指令重执行），否则转原致命路径。
//!   未注册钩子时行为与致命版严格一致（现网语义零回归）。
//!
//! M6 新增/重构（per-CPU 统一调度器）：
//! - 抢占目标传递改为**栈上 [`PreemptPlan`]**：桩 `sub rsp,16` 预留、
//!   主体填写、同中断窗口内消费——天然 per-CPU（每核各用自己的栈），
//!   消除 M4 全局静态槽在双核同时抢占时互相覆盖的竞态；
//! - `isr_lapic_timer`（向量 0x41）：统一 per-CPU 抢占源（M6-A）；
//!   M10-A 前 PIT（向量 32）退化为纯墙钟打点，不驱动抢占；
//! - `isr_resched`（向量 0x42）：跨核重调度提示 IPI（唤醒 idle 核重新
//!   检查全局就绪队列；对忙核无副作用）。
//!
//! M10-A 扩展（per-CPU tick 账户，解除 ring3 时间面冻结）：
//! - `isr_timer`（向量 32）升级为**全上下文时间源**：LAPIC 定时器在
//!   ring3 驻留期间被 prepare_dispatch 屏蔽（TCG 双异常交付缺陷族规避，
//!   S31 记档），时间面（计账/老化/抢占）随之冻结；PIT 实测交付不触发
//!   缺陷族 → 桩尾部加装与 LAPIC 定时器同构的 PreemptPlan 交换路径，
//!   主体经墙钟钩子承载 per-CPU 账户 + 老化 + 接收核抢占；
//! - `isr_resched`（向量 0x42）加装同构交换路径：对侧核 ring3 驻留的
//!   抢占经 PREEMPT_REQ 旗 + 本 IPI 送达（交付实测安全：M6-M9 门铃
//!   持续交付于 ring3 驻留核）——三抢占源（LAPIC/PIT/RESCHED）全就位。

use core::sync::atomic::{AtomicUsize, Ordering};

/// 中断门选择子：启动 GDT 的 64 位代码段（见 kernel boot 汇编）。
pub const KERNEL_CS: u64 = 0x08;

/// 64 位中断门属性字节：P=1 | DPL=0 | type=0xE。
pub const GATE_INTERRUPT: u64 = 0x8E;

/// 单条 IDT 门描述符（16 字节：lo|hi 两个 u64）。
#[derive(Debug, Clone, Copy)]
pub struct IdtEntry {
    lo: u64,
    hi: u64,
}

impl IdtEntry {
    /// 空门（P=0）。
    pub const EMPTY: IdtEntry = IdtEntry { lo: 0, hi: 0 };

    /// 以处理程序线性地址构造中断门。
    ///
    /// 布局（Intel SDM Vol.3 §6.14）：lo = 偏移[15:0] | 选择子[31:16] |
    /// IST[39:32] | 属性[47:40] | 偏移[47:32]；hi = 偏移[63:48]。
    pub const fn interrupt(handler: u64) -> Self {
        Self {
            lo: (handler & 0xFFFF)
                | (KERNEL_CS << 16)
                | (GATE_INTERRUPT << 40)
                | ((handler & 0xFFFF_0000) << 32),
            hi: handler >> 32,
        }
    }

    /// 以处理程序线性地址构造中断门（IST 指定版，M41-笔①）。
    ///
    /// 布局同上；`ist` ∈ 1..=7 时填入门 IST 域（[39:32]）——中断入
    /// 场 CPU 无条件切换至 `TSS.IST[ist]`（含 CPL0 现场——RSP0 语义
    /// 只在特权切换时生效），故障门专用（保底栈：CPL0 用户栈未映射时
    /// 中断帧不再压同一页 → 嵌套 #PF/#DF 链根治）。
    pub const fn interrupt_ist(handler: u64, ist: u8) -> Self {
        debug_assert!(ist <= 7);
        Self {
            lo: (handler & 0xFFFF)
                | (KERNEL_CS << 16)
                | ((ist as u64) << 32)
                | (GATE_INTERRUPT << 40)
                | ((handler & 0xFFFF_0000) << 32),
            hi: handler >> 32,
        }
    }

    /// 门是否指向给定处理程序地址（自检用）。
    pub const fn points_to(self, handler: u64) -> bool {
        (self.lo & 0xFFFF) | ((self.lo >> 32) & 0xFFFF_0000) | (self.hi << 32) == handler
    }
}

/// 256 向量 IDT（x86_64 恒定 4096 字节）。
#[repr(C, align(16))]
pub struct Idt {
    entries: [IdtEntry; 256],
}

impl Idt {
    /// 全空表。
    pub const fn new() -> Self {
        Self {
            entries: [IdtEntry::EMPTY; 256],
        }
    }

    /// 以原始地址设置向量 `vector`（0..=255）的中断门；越界忽略（防御式）。
    pub fn set_raw(&mut self, vector: usize, handler_addr: u64) {
        if let Some(slot) = self.entries.get_mut(vector) {
            *slot = IdtEntry::interrupt(handler_addr);
        }
    }

    /// 以原始地址 + IST 槽设置向量 `vector`（0..=255）的中断门
    /// （M41-笔①：#PF 门挂 IST1 应急栈）；越界忽略（防御式）。
    pub fn set_raw_ist(&mut self, vector: usize, handler_addr: u64, ist: u8) {
        if let Some(slot) = self.entries.get_mut(vector) {
            *slot = IdtEntry::interrupt_ist(handler_addr, ist);
        }
    }

    /// 向量 `vector` 的门是否指向 `handler_addr`（自检断言用）。
    pub fn entry_points_to(&self, vector: usize, handler_addr: u64) -> bool {
        self.entries
            .get(vector)
            .is_some_and(|e| e.points_to(handler_addr))
    }

    /// 表常量字节数（IDTR 界限 = 表长 − 1）。
    pub const fn byte_len() -> u16 {
        4096
    }

    /// 表基址（AP handoff / 诊断用；零 deref，safe）。
    pub fn base(&self) -> u64 {
        core::ptr::addr_of!(self.entries) as u64
    }

    /// 装载 IDTR（表基址按实际字段地址计算，与外部布局无关）。
    ///
    /// # Safety
    ///
    /// - 本表必须为静态存储期且装载后不再修改（IDTR 长期引用它）；
    /// - 装载期间不得并发修改（调用方持锁或处于关中断窗口）。
    pub unsafe fn load(&self) {
        let base = core::ptr::addr_of!(self.entries) as usize;
        crate::hw::intr::lidt(base, Self::byte_len() - 1);
    }
}

impl Default for Idt {
    fn default() -> Self {
        Self::new()
    }
}

/// 抢占交换计划（repr(C)：与桩汇编偏移严格对应——old 在 +0、new 在 +8、
/// handoff 在 +16，M11-D 调度切换握手扩展）。
///
/// 生存期：位于中断桩的栈上临时区（`sub rsp,32` 预留），仅在单次中断
/// 窗口内有效——主体填写后立即由桩消费，无跨核、跨窗口引用。
/// 这使抢占目标选择天然 per-CPU：每核写的是自己的栈。
///
/// **handoff（M11-D）**：被抢占任务的切换握手旗地址（`SWITCHING[old]`，
/// u64 槽）。桩在旧上下文全部保存完成后一次性写 0（asm 单 Store）——
/// 从该指令起被抢占者才可被任意核安全拾取（现场已完整，拾取方恢复的
/// 是刚保存的连续帧）；旗置位期间拾取面（eligible）拒绝该槽位，
/// 根治「锁释放 → 物理切换」窗口内对侧核拾取陈旧上下文副本的竞态
/// （t37 裸机实证：自由跨核 spawn 子任务交叉命中，寄存器面腐坏）。
/// 桩在主体调用前将本槽清零，主体仅在真实切换时填写——防野指针。
#[repr(C)]
pub struct PreemptPlan {
    /// 被抢占任务的上下文（桩将全部现场存入）。
    pub old: *mut crate::task::TaskContext,
    /// 即将切入任务的上下文（桩从中加载现场）。
    pub new: *mut crate::task::TaskContext,
    /// 切换握手旗地址（M11-D；0 = 无旗可清——防御桩读垃圾指针）。
    pub handoff: *mut u64,
}

/// 受支持的中断桩。
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Stub {
    /// 向量 32：IRQ0 定时器。
    Timer,
    /// 向量 0：#DE 除法错误。
    FaultDe,
    /// 向量 6：#UD 非法指令。
    FaultUd,
    /// 向量 13：#GP 一般保护错误。
    FaultGp,
    /// 向量 14：#PF 页错误。
    FaultPf,
    /// 向量 10：#TS 无效 TSS（ring3 切栈失败诊断）。
    FaultTs,
    /// 向量 8：#DF 双重故障（向量化失败的最后一道防线）。
    FaultDf,
    /// 向量 1：#DB 调试异常（M22-③ DR0 写监视点透明探针——命中转储后
    /// 原指令流继续，永不致命）。
    FaultDb,
    /// 向量 0x40：LAPIC IPI（TLB 击落等核间命令，M5）。
    Ipi,
    /// 向量 14：可恢复 #PF（同 FaultPf 向量号；钩子可补映射后重执行）。
    FaultPfRec,
    /// 向量 0x41：LAPIC 定时器（统一 per-CPU 抢占源，M6-A）。
    LapicTimer,
    /// 向量 0x43：TSC deadline one-shot 定时器（M43-TSC39 笔㊹——
    /// IA32_TSC_DEADLINE 武装交付面：EOI + 计数取证，零抢占）。
    TscDeadline,
    /// 向量 0x42：跨核重调度提示 IPI（唤醒 idle 核，M6-A）。
    Resched,
    /// 向量 33：IRQ1 PS/2 键盘（M23-①；PIC 主片，EOI 在桩主体内发）。
    Irq1,
    /// 向量 44（0x2C = 0x28+4）：IRQ12 PS/2 aux 第二通道（M42-AUX25 笔
    /// ㉕电气源接线；PIC 从片 IRQ4，级联 EOI 在桩主体内发——从片先、
    /// 主片随行）。
    Irq12,
}

/// 桩符号地址（供 [`Idt::set_raw`] 注册）。
pub fn stub_addr(stub: Stub) -> u64 {
    // rustc 1.99 起 extern 块函数指针按 unsafe extern "C" fn() 处理；
    // 我们只需要其地址（注册进 IDT 门），永不直接调用，故取地址转型。
    unsafe extern "C" {
        fn isr_timer();
        fn isr_fault_de();
        fn isr_fault_ud();
        fn isr_fault_gp();
        fn isr_fault_pf();
        fn isr_fault_ts();
        fn isr_fault_df();
        fn isr_fault_db();
        fn isr_ipi();
        fn isrf_pf_rec();
        fn isr_lapic_timer();
        fn isr_tsc_deadline();
        fn isr_resched();
        fn isr_kbd();
        fn isr_aux();
    }
    let f: unsafe extern "C" fn() = match stub {
        Stub::Timer => isr_timer,
        Stub::FaultDe => isr_fault_de,
        Stub::FaultUd => isr_fault_ud,
        Stub::FaultGp => isr_fault_gp,
        Stub::FaultPf => isr_fault_pf,
        Stub::FaultTs => isr_fault_ts,
        Stub::FaultDf => isr_fault_df,
        Stub::FaultDb => isr_fault_db,
        Stub::Ipi => isr_ipi,
        Stub::FaultPfRec => isrf_pf_rec,
        Stub::LapicTimer => isr_lapic_timer,
        Stub::TscDeadline => isr_tsc_deadline,
        Stub::Resched => isr_resched,
        Stub::Irq1 => isr_kbd,
        Stub::Irq12 => isr_aux,
    };
    f as usize as u64
}

static FAULT_HOOK: AtomicUsize = AtomicUsize::new(0);

/// 注册致命异常钩子：收到未恢复异常时以（向量号, 故障 RIP, 诊断帧指针）
/// 调用并永不返回。诊断帧指针 = 异常桩入场时栈指针（#GP/#PF 桩传入，
/// 其余传 0）：[frame]=错误码、[frame+8]=RIP、[frame+16]=CS、
/// [frame+24]=RFLAGS、[frame+32]=故障时 RSP、[frame+40]=SS。
///
/// **M18-① 取证面扩容与伪影根治**：v0.18 及之前仅 #GP 传入 aux——
/// 可恢复 #PF 桩的致命分支从未设置 rdx，钩子拿到的 aux = 主体返回后
/// 的寄存器残渣：指向低物理地址时转储出的「iretq 帧」实为恒等映射
/// IVT 区内容（v0.18.0 观察记档「实模式 IVT 形态」即此伪影），指向
/// 野值时 read_u64(aux) 自身二次 #PF（cr2=-0x28 同源）。自本版起
/// #PF 致命桩与可恢复→致命分支均传入真实帧指针，伪影链封死。
///
/// 注册时机 MUST 早于 `sti`（否则早期异常只停机不落盘诊断）。
pub fn set_fault_hook(hook: fn(u64, u64, u64) -> !) {
    FAULT_HOOK.store(hook as usize, Ordering::Release);
}

/// 故障出口：转交钩子；未注册则停机兜底。
fn fault_exit(vector: u64, rip: u64, aux: u64) -> ! {
    let hook = FAULT_HOOK.load(Ordering::Acquire);
    if hook != 0 {
        // SAFETY: 前置条件 —— 地址来自 set_fault_hook 存入的
        //          fn(u64,u64,u64)->!。
        // 不变式 —— Release/Acquire 配对保证读取到完整写入。
        // 并发 —— 注册只发生在 sti 之前。
        // 违反后果 —— 转移到伪造地址即跳入任意代码。
        let f: fn(u64, u64, u64) -> ! = unsafe { core::mem::transmute(hook) };
        f(vector, rip, aux);
    }
    loop {
        crate::hw::intr::halt();
    }
}

/// 中断桩（框架内核白名单汇编，SPEC 第十七章申请）。
///
/// - 定时器桩：9 个 caller-saved 入栈 → `and rsp, -16` 对齐 → 主体 →
///   `mov rsp, rbp` 一口气撤栈 → `iretq`；rbp 作锚点由主体按 ABI 保护。
/// - 异常桩：向量号置 edi → 主体（永不返回）→ 兜底 cli+hlt。
///   #GP/#PF 的错误码留在栈上无人读取（致命路径，随退出销毁）；
///   #GP/#PF 桩另将入场 rsp 作 aux 传入（诊断帧指针，M18-① 扩容）。
pub mod stubs {
    core::arch::global_asm! {
        ".text",
        // ---- 向量 32：IRQ0 定时器（M10-A 起：墙钟打点 + per-CPU tick 账户
        // + 抢占源；与 LAPIC 定时器桩同构的 PreemptPlan 交换路径）----
        // M6-M9 历史：纯墙钟打点，不驱动抢占（统一抢占源 = LAPIC 定时器）。
        // M10-A 重构：LAPIC 定时器在 ring3 驻留期间被 prepare_dispatch 屏蔽
        // （TCG 双异常交付缺陷族规避），时间面（计账/老化/抢占）随之冻结；
        // PIT 实测交付不触发缺陷族 → 升级为全上下文时间源。桩尾部与
        // isr_lapic_timer 同构：主体返回 eax=1 则从栈上 PreemptPlan 执行
        // 抢占交换（ring3 抢占首次成立）。
        // 纪律：保存/恢复 caller-saved 全集（rax,rcx,rdx,rsi,rdi,r8-r11）
        // 与 rbp；锚点 rbp 落在 10 个 push 之后（锚点 = 最后压入的 r11 槽），
        // 恢复走对称 POP 而非「mov rsp, rbp 跳过」——否则被中断代码的
        // 寄存器现场全毁。
        //
        // 抢占路径（M10-A 扩展）：栈上 PreemptPlan——桩 `sub rsp,16` 预留，
        // 主体（rdi = &plan）填写后返回 eax=1，桩从 [rsp]/[rsp+8] 取
        // 新旧上下文指针执行交换。计划生存期 = 单次中断窗口（栈上临时区），
        // 天然 per-CPU：双核同时抢占各自写各自的栈，零共享状态。
        ".globl isr_timer",
        "isr_timer:",
        "    push rbp",
        "    push rax",
        "    push rcx",
        "    push rdx",
        "    push rsi",
        "    push rdi",
        "    push r8",
        "    push r9",
        "    push r10",
        "    push r11",
        "    mov rbp, rsp",
        "    and rsp, -16",
        "    sub rsp, 32",
        "    mov qword ptr [rsp + 16], 0",
        "    mov rdi, rsp",
        "    call isr_timer_body",
        "    test eax, eax",
        "    jnz 8f",
        "    mov rsp, rbp",
        "    pop r11",
        "    pop r10",
        "    pop r9",
        "    pop r8",
        "    pop rdi",
        "    pop rsi",
        "    pop rdx",
        "    pop rcx",
        "    pop rax",
        "    pop rbp",
        "    iretq",
        "8:",
        // plan 位于 [rsp]/[rsp+8]/[rsp+16]（handoff = M11-D 握手旗）；
        // 旧上下文七槽保存完成后一次性清旗（asm 单 Store）——从本指令起
        // 被抢占者可被任意核安全拾取（M11-D 握手，根治锁释放→物理切换窗口）
        "    lea rax, [rip + 9f]",
        "    mov rdi, [rsp]",
        "    mov rsi, [rsp + 8]",
        "    mov [rdi + 0x00], rax",
        "    mov [rdi + 0x08], rbx",
        "    mov [rdi + 0x10], rbp",
        "    mov [rdi + 0x18], r12",
        "    mov [rdi + 0x20], r13",
        "    mov [rdi + 0x28], r14",
        "    mov [rdi + 0x30], r15",
        "    mov [rdi + 0x38], rbp",
        "    mov rcx, [rsp + 16]",
        "    test rcx, rcx",
        "    jz 12f",
        "    mov qword ptr [rcx], 0",
        "12:",
        "    mov rbx, [rsi + 0x08]",
        "    mov rbp, [rsi + 0x10]",
        "    mov r12, [rsi + 0x18]",
        "    mov r13, [rsi + 0x20]",
        "    mov r14, [rsi + 0x28]",
        "    mov r15, [rsi + 0x30]",
        "    mov rsp, [rsi + 0x38]",
        "    push QWORD PTR [rsi + 0x00]",
        "    ret",
        // 9: = .resume（被抢占任务的续点，语义同 LAPIC 定时器桩）
        // M22-③：全局符号导出——哨兵合法续点全集（白名单）构件
        "9:",
        ".globl lumina_resume_timer",
        "lumina_resume_timer:",
        "    mov rsp, rbp",
        "    pop r11",
        "    pop r10",
        "    pop r9",
        "    pop r8",
        "    pop rdi",
        "    pop rsi",
        "    pop rdx",
        "    pop rcx",
        "    pop rax",
        "    pop rbp",
        "    iretq",
        // ---- LAPIC 定时器桩（向量 0x41，M6-A：统一 per-CPU 抢占源）----
        // 与定时器桩同构：对称保存 caller-saved + rbp → 主体（rdi = &plan）
        // 返回 eax=1 则从栈上 PreemptPlan 取新旧上下文执行抢占交换。
        // 标签 6/7 与定时器桩的 4 隔离（同一 global_asm 块内标签唯一）。
        ".globl isr_lapic_timer",
        "isr_lapic_timer:",
        "    push rbp",
        "    push rax",
        "    push rcx",
        "    push rdx",
        "    push rsi",
        "    push rdi",
        "    push r8",
        "    push r9",
        "    push r10",
        "    push r11",
        "    mov rbp, rsp",
        "    and rsp, -16",
        "    sub rsp, 32",
        "    mov qword ptr [rsp + 16], 0",
        "    mov rdi, rsp",
        "    call isr_lapic_timer_body",
        "    test eax, eax",
        "    jnz 6f",
        "    mov rsp, rbp",
        "    pop r11",
        "    pop r10",
        "    pop r9",
        "    pop r8",
        "    pop rdi",
        "    pop rsi",
        "    pop rdx",
        "    pop rcx",
        "    pop rax",
        "    pop rbp",
        "    iretq",
        // ---- TSC deadline one-shot 桩（向量 0x43，M43-TSC39 笔㊹）：
        // 与 LAPIC timer 桩同构裁剪（零抢占——EOI + 主体计数后直返；
        // 对称保存 caller-saved + rbp → 主体 → 恢复 iretq；标签 8 与
        // 既有 4/6/7/12/13 隔离——同一 global_asm 块内标签唯一）。
        ".globl isr_tsc_deadline",
        "isr_tsc_deadline:",
        "    push rbp",
        "    push rax",
        "    push rcx",
        "    push rdx",
        "    push rsi",
        "    push rdi",
        "    push r8",
        "    push r9",
        "    push r10",
        "    push r11",
        "    mov rbp, rsp",
        "    and rsp, -16",
        "    sub rsp, 16",
        "    mov qword ptr [rsp + 8], 0",
        "    mov qword ptr [rsp], 0",
        "    mov rdi, rsp",
        "    call isr_tsc_deadline_body",
        "    mov rsp, rbp",
        "    pop r11",
        "    pop r10",
        "    pop r9",
        "    pop r8",
        "    pop rdi",
        "    pop rsi",
        "    pop rdx",
        "    pop rcx",
        "    pop rax",
        "    pop rbp",
        "    iretq",
        "6:",
        // plan 位于 [rsp]/[rsp+8]/[rsp+16]（handoff 同 M11-D 握手契约，
        // 与定时器桩 12 标签隔离——同一 global_asm 块内标签唯一）
        "    lea rax, [rip + 7f]",
        "    mov rdi, [rsp]",
        "    mov rsi, [rsp + 8]",
        "    mov [rdi + 0x00], rax",
        "    mov [rdi + 0x08], rbx",
        "    mov [rdi + 0x10], rbp",
        "    mov [rdi + 0x18], r12",
        "    mov [rdi + 0x20], r13",
        "    mov [rdi + 0x28], r14",
        "    mov [rdi + 0x30], r15",
        "    mov [rdi + 0x38], rbp",
        "    mov rcx, [rsp + 16]",
        "    test rcx, rcx",
        "    jz 13f",
        "    mov qword ptr [rcx], 0",
        "13:",
        "    mov rbx, [rsi + 0x08]",
        "    mov rbp, [rsi + 0x10]",
        "    mov r12, [rsi + 0x18]",
        "    mov r13, [rsi + 0x20]",
        "    mov r14, [rsi + 0x28]",
        "    mov r15, [rsi + 0x30]",
        "    mov rsp, [rsi + 0x38]",
        "    push QWORD PTR [rsi + 0x00]",
        "    ret",
        // 7: = .resume（被抢占任务的续点，语义同 M4 设计）
        // M22-③：全局符号导出（同上）
        "7:",
        ".globl lumina_resume_lapic",
        "lumina_resume_lapic:",
        "    mov rsp, rbp",
        "    pop r11",
        "    pop r10",
        "    pop r9",
        "    pop r8",
        "    pop rdi",
        "    pop rsi",
        "    pop rdx",
        "    pop rcx",
        "    pop rax",
        "    pop rbp",
        "    iretq",
        // ---- 跨核重调度提示 IPI 桩（向量 0x42，M6-A；M10-A 扩展）----
        // 基础语义：唤醒 halt 中的 idle 核；主体 EOI + 置重调度标志。
        // M10-A 扩展：与定时器桩同构的 PreemptPlan 交换路径——对侧核
        // ring3 驻留期间 LAPIC 定时器被屏蔽（TCG 缺陷族），墙钟钩子判定
        // 其需抢占时置 PREEMPT_REQ 并发本 IPI；主体消费旗标后按抢占规则
        // 填写 plan（ring3 交付实测安全：M6-M9 spawn/分页门铃持续交付于
        // ring3 驻留核），桩完成抢占交换。
        ".globl isr_resched",
        "isr_resched:",
        "    push rbp",
        "    push rax",
        "    push rcx",
        "    push rdx",
        "    push rsi",
        "    push rdi",
        "    push r8",
        "    push r9",
        "    push r10",
        "    push r11",
        "    mov rbp, rsp",
        "    and rsp, -16",
        "    sub rsp, 32",
        "    mov qword ptr [rsp + 16], 0",
        "    mov rdi, rsp",
        "    call isr_resched_body",
        "    test eax, eax",
        "    jnz 10f",
        "    mov rsp, rbp",
        "    pop r11",
        "    pop r10",
        "    pop r9",
        "    pop r8",
        "    pop rdi",
        "    pop rsi",
        "    pop rdx",
        "    pop rcx",
        "    pop rax",
        "    pop rbp",
        "    iretq",
        "10:",
        "    lea rax, [rip + 11f]",
        "    mov rdi, [rsp]",
        "    mov rsi, [rsp + 8]",
        "    mov [rdi + 0x00], rax",
        "    mov [rdi + 0x08], rbx",
        "    mov [rdi + 0x10], rbp",
        "    mov [rdi + 0x18], r12",
        "    mov [rdi + 0x20], r13",
        "    mov [rdi + 0x28], r14",
        "    mov [rdi + 0x30], r15",
        "    mov [rdi + 0x38], rbp",
        "    mov rcx, [rsp + 16]",
        "    test rcx, rcx",
        "    jz 14f",
        "    mov qword ptr [rcx], 0",
        "14:",
        "    mov rbx, [rsi + 0x08]",
        "    mov rbp, [rsi + 0x10]",
        "    mov r12, [rsi + 0x18]",
        "    mov r13, [rsi + 0x20]",
        "    mov r14, [rsi + 0x28]",
        "    mov r15, [rsi + 0x30]",
        "    mov rsp, [rsi + 0x38]",
        "    push QWORD PTR [rsi + 0x00]",
        "    ret",
        "11:",
        // M22-③：全局符号导出（同上）
        ".globl lumina_resume_resched",
        "lumina_resume_resched:",
        "    mov rsp, rbp",
        "    pop r11",
        "    pop r10",
        "    pop r9",
        "    pop r8",
        "    pop rdi",
        "    pop rsi",
        "    pop rdx",
        "    pop rcx",
        "    pop rax",
        "    pop rbp",
        "    iretq",
        // ---- 向量 1：#DB 调试异常（M22-③ DR0 写监视点透明探针）----
        // 契约：命中 → 转储写者 rip → 原指令流继续（永不致命）。与定时
        // 器桩同构的对称保存/恢复；无分支无标签（同一 global_asm 块内
        // 标签零冲突）。cli 防嵌套（trap 语境 IF 不自动清）；iretq 按
        // 帧恢复原 IF。数据断点为后置陷阱：命中时写入已完成，转储读
        // 到的即新值（取证语义恰好所需）。
        ".globl isr_fault_db",
        "isr_fault_db:",
        "    cli",
        "    push rbp",
        "    push rax",
        "    push rcx",
        "    push rdx",
        "    push rsi",
        "    push rdi",
        "    push r8",
        "    push r9",
        "    push r10",
        "    push r11",
        "    mov rbp, rsp",
        "    and rsp, -16",
        "    sub rsp, 16",
        "    mov rdi, [rbp + 80]",
        "    mov rsi, rbp",
        "    call isr_fault_db_body",
        "    mov rsp, rbp",
        "    pop r11",
        "    pop r10",
        "    pop r9",
        "    pop r8",
        "    pop rdi",
        "    pop rsi",
        "    pop rdx",
        "    pop rcx",
        "    pop rax",
        "    pop rbp",
        "    iretq",
        // ---- 致命异常桩（永不返回）----
        // 约定：rstore 诊断前先取 [rsp] = 故障 RIP（中断帧首字段）。
        // #DE/#UD 无错误码，[rsp] 即 RIP；#GP/#PF 有错误码，
        // RIP 位于 [rsp+8]。诊断用 rip 一律从对应偏移提取。
        ".globl isr_fault_de",
        "isr_fault_de:",
        "    mov edi, 0",
        "    mov rsi, [rsp]",
        "    xor edx, edx",
        "    sub rsp, 8",
        "    and rsp, -16",
        "    call isr_fault_body",
        "    cli",
        "    hlt",
        ".globl isr_fault_ud",
        "isr_fault_ud:",
        "    mov edi, 6",
        "    mov rsi, [rsp]",
        "    xor edx, edx",
        "    sub rsp, 8",
        "    and rsp, -16",
        "    call isr_fault_body",
        "    cli",
        "    hlt",
        ".globl isr_fault_gp",
        "isr_fault_gp:",
        "    mov edi, 13",
        "    mov rsi, [rsp+8]",
        "    mov rdx, rsp",
        "    sub rsp, 8",
        "    and rsp, -16",
        "    call isr_fault_body",
        "    cli",
        "    hlt",
        ".globl isr_fault_pf",
        "isr_fault_pf:",
        "    mov edi, 14",
        "    mov rsi, [rsp+8]",
        "    mov rdx, rsp", // M18-①：aux = 真实帧指针（错误码槽；与 #GP 同款）
        "    sub rsp, 8",
        "    and rsp, -16",
        "    call isr_fault_body",
        "    cli",
        "    hlt",
        ".globl isr_fault_ts",
        "isr_fault_ts:",
        "    mov edi, 10",
        "    mov rsi, [rsp+8]",
        "    xor edx, edx",
        "    sub rsp, 8",
        "    and rsp, -16",
        "    call isr_fault_body",
        "    cli",
        "    hlt",
        ".globl isr_fault_df",
        "isr_fault_df:",
        "    mov edi, 8",
        "    mov rsi, [rsp+8]",
        "    xor edx, edx",
        "    sub rsp, 8",
        "    and rsp, -16",
        "    call isr_fault_body",
        "    cli",
        "    hlt",
        // ---- LAPIC IPI 桩（向量 0x40，M5）----
        // 定时器同构：对称保存 caller-saved + rbp → 主体 → 对称恢复 → iretq。
        // EOI 不在本桩做（PIC/LAPIC 归属由内核钩子决定）。
        ".globl isr_ipi",
        "isr_ipi:",
        "    push rbp",
        "    push rax",
        "    push rcx",
        "    push rdx",
        "    push rsi",
        "    push rdi",
        "    push r8",
        "    push r9",
        "    push r10",
        "    push r11",
        "    mov rbp, rsp",
        "    and rsp, -16",
        "    call isr_ipi_body",
        "    mov rsp, rbp",
        "    pop r11",
        "    pop r10",
        "    pop r9",
        "    pop r8",
        "    pop rdi",
        "    pop rsi",
        "    pop rdx",
        "    pop rcx",
        "    pop rax",
        "    pop rbp",
        "    iretq",
        // ---- 可恢复 #PF 桩（向量 14，M5）----
        // 入场（CPU 推入错误码后）：[rsp]=错误码、[rsp+8]=RIP。
        // 布局：10 次 push 后 rbp=锚点，错误码位于 [rbp+80]（见 offset 注释）。
        // handled：对称恢复 → add rsp,8 丢弃错误码 → iretq（重执行故障指令）；
        // 未 handled：转致命主体（向量 14，RIP 取 [rbp+88]），永不返回。
        ".globl isrf_pf_rec",
        "isrf_pf_rec:",
        "    push rbp",
        "    push rax",
        "    push rcx",
        "    push rdx",
        "    push rsi",
        "    push rdi",
        "    push r8",
        "    push r9",
        "    push r10",
        "    push r11",
        "    mov rbp, rsp",
        "    and rsp, -16",
        "    mov rdi, cr2",
        "    mov rsi, [rbp+80]",
        "    call isrf_pf_rec_body",
        "    test eax, eax",
        "    jnz 5f",
        "    mov rdi, 14",
        "    mov rsi, [rbp+88]",
        // M18-①：aux = rbp+80 = 错误码槽（真实帧基址）——v0.18 及之前
        // 本分支不设 rdx，钩子拿到的 aux = 主体返回后寄存器残渣，
        // 转储面读野值指针即伪影（IVT 形态帧 / cr2=-0x28 链式 #PF）
        "    lea rdx, [rbp+80]",
        "    call isr_fault_body",
        "    cli",
        "    hlt",
        "5:",
        "    mov rsp, rbp",
        "    pop r11",
        "    pop r10",
        "    pop r9",
        "    pop r8",
        "    pop rdi",
        "    pop rsi",
        "    pop rdx",
        "    pop rcx",
        "    pop rax",
        "    pop rbp",
        "    add rsp, 8",
        "    iretq",
        // ---- PS/2 键盘桩（向量 33 = IRQ1，M23-①）----
        // IPI 桩同构：对称保存 caller-saved + rbp → 主体 → 对称恢复 → iretq。
        // scancode 读取与 EOI 全在主体（PIC 主片归属确定，非钩子策略）。
        ".globl isr_kbd",
        "isr_kbd:",
        "    push rbp",
        "    push rax",
        "    push rcx",
        "    push rdx",
        "    push rsi",
        "    push rdi",
        "    push r8",
        "    push r9",
        "    push r10",
        "    push r11",
        "    mov rbp, rsp",
        "    and rsp, -16",
        "    call isr_kbd_body",
        "    mov rsp, rbp",
        "    pop r11",
        "    pop r10",
        "    pop r9",
        "    pop r8",
        "    pop rdi",
        "    pop rsi",
        "    pop rdx",
        "    pop rcx",
        "    pop rax",
        "    pop rbp",
        "    iretq",
        // ---- PS/2 aux 桩（向量 44 = IRQ12，M42-AUX25 笔㉕）----
        // isr_kbd 同构：对称保存 caller-saved + rbp → 主体 → 对称恢复
        // → iretq。源位判读（STATUS bit5）与级联 EOI 全在主体。
        ".globl isr_aux",
        "isr_aux:",
        "    push rbp",
        "    push rax",
        "    push rcx",
        "    push rdx",
        "    push rsi",
        "    push rdi",
        "    push r8",
        "    push r9",
        "    push r10",
        "    push r11",
        "    mov rbp, rsp",
        "    and rsp, -16",
        "    call isr_aux_body",
        "    mov rsp, rbp",
        "    pop r11",
        "    pop r10",
        "    pop r9",
        "    pop r8",
        "    pop rdi",
        "    pop rsi",
        "    pop rdx",
        "    pop rcx",
        "    pop rax",
        "    pop rbp",
        "    iretq",
    }

    /// 定时器钩子：返回 true 表示已填写 plan 并完成切换目标布置
    /// （桩随即从栈上 plan 取指针执行抢占交换）。
    static TIMER_HOOK: core::sync::atomic::AtomicUsize = core::sync::atomic::AtomicUsize::new(0);

    /// M22-③：三抢占桩 `.resume` 续点的符号地址（哨兵合法续点全集构件）。
    ///
    /// 抢占保存的 `ctx.cont` 恒为本桩 `.resume` 标签（asm `lea rax,[rip+Xf]`
    /// 写入面）——三地址与协作站点返回址、trampoline 一起构成 cont 白名单。
    pub fn preempt_resume_labels() -> [usize; 3] {
        extern "C" {
            static lumina_resume_timer: u8;
            static lumina_resume_lapic: u8;
            static lumina_resume_resched: u8;
        }
        // SAFETY: 前置条件 —— 三符号由本文件 global_asm .globl 导出，链接期定址。
        // 不变式 —— 仅取地址不读取本体（零尺寸符号约定；addr_of 建
        //           指针本身为 safe 操作，unsafe 包裹冗余——clippy 指认后移除）。
        // 并发 —— 链接期常量，只读无竞争。
        // 违反后果 —— 符号缺失即链接期报错（无运行期风险）。
        [
            core::ptr::addr_of!(lumina_resume_timer) as usize,
            core::ptr::addr_of!(lumina_resume_lapic) as usize,
            core::ptr::addr_of!(lumina_resume_resched) as usize,
        ]
    }

    /// 注册定时器钩子（M6：仅 LAPIC 定时器主体消费；PIT 主体不再调用）。
    pub fn set_timer_hook(hook: fn(&mut super::PreemptPlan) -> bool) {
        TIMER_HOOK.store(hook as usize, core::sync::atomic::Ordering::Release);
    }

    /// M22-③：#DB 写监视点取证钩子（DR0 命中面）。
    static DB_HOOK: core::sync::atomic::AtomicUsize = core::sync::atomic::AtomicUsize::new(0);

    /// 注册 #DB 取证钩子（内核 init 布防时调用；未注册时命中即静默返回）。
    pub fn set_db_hook(hook: fn(trap_rip: u64, anchor: u64)) {
        DB_HOOK.store(hook as usize, core::sync::atomic::Ordering::Release);
    }

    /// DR0 写监视点布防（64 位模式下数据断点长度固定 8 字节）。
    /// DR7 = L0|G0 使能 + R/W0=01（写）+ 保留位 10 置 1。DR 每核一套——
    /// 双核各布一次（同一目标地址，幂等）。
    pub fn arm_write_watchpoint(addr: u64) {
        // SAFETY: 前置条件 —— 内核特权语境调用（ring0 专属指令）。
        // 不变式 —— DR0/DR7 每核独立；重复布防同值幂等。
        // 并发 —— 每 CPU 各自写自身 DR，无交叉。
        // 违反后果 —— 用户态调用即 #GP（权限面自封）。
        unsafe {
            core::arch::asm!("mov dr0, {0}", in(reg) addr, options(nostack, nomem));
            core::arch::asm!("mov dr7, {0}", in(reg) 0x1_0403u64, options(nostack, nomem));
        }
    }

    /// M22-③ [B] 猎场扩网 v2：DR1 写监视点布防（恢复帧 RIP 槽动态蹲守）。
    /// DR7 = DR0 基态 | L1|G1(0xC) | R/W1=01（写，bit20=0x10_0000）——
    /// DR0 目标（主任务 ctx 槽）保持原布防不动，DR1 叠加蹲守。
    pub fn arm_write_watchpoint_dr1(addr: u64) {
        // SAFETY: 前置条件 —— 内核特权语境调用（ring0 专属指令）。
        // 不变式 —— DR1 目标与 DR7 位域编码互不干扰 DR0 基态（位或叠加）。
        // 并发 —— 每 CPU 各自写自身 DR（拾取核自布，无交叉）。
        // 违反后果 —— 用户态调用即 #GP（权限面自封）。
        unsafe {
            core::arch::asm!("mov dr1, {0}", in(reg) addr, options(nostack, nomem));
            core::arch::asm!("mov dr7, {0}", in(reg) 0x11_040Fu64, options(nostack, nomem));
        }
    }

    /// DR1 撤防（回 DR0 单桩基态；换目标前清陈值防野监视）。
    pub fn disarm_watchpoint_dr1() {
        // SAFETY: 前置条件 —— 同上（ring0 专属指令）。
        // 不变式 —— DR7 回 0x1_0403（DR0 基态）+ DR1 清零，幂等。
        // 并发 —— 每 CPU 独立。
        // 违反后果 —— 无（撤防只降监视面，不增权）。
        unsafe {
            core::arch::asm!("mov dr1, {0}", in(reg) 0u64, options(nostack, nomem));
            core::arch::asm!("mov dr7, {0}", in(reg) 0x1_0403u64, options(nostack, nomem));
        }
    }

    /// 读 DR1 当前监视目标（#DB 钩子值签名判别用；本核现场直读）。
    pub fn read_dr1() -> u64 {
        let v: u64;
        // SAFETY: 前置条件 —— ring0 语境（#DB 桩内/内核态）。
        // 不变式 —— 只读不写，零副作用。
        // 并发 —— DR 每核一套，本核读本核。
        // 违反后果 —— 用户态调用即 #GP（权限面自封）。
        unsafe {
            core::arch::asm!("mov {0}, dr1", out(reg) v, options(nostack, nomem));
        }
        v
    }

    /// #DB 主体（isr_fault_db 调入；rdi = 写者 rip，rsi = 桩锚点）。
    /// 透明探针：钩子转储后返回，原指令流 iretq 继续——永不致命。
    /// （asm 唯一引用面 → #[no_mangle] 保符号，同 isr_timer_body 惯例。）
    #[no_mangle]
    extern "C" fn isr_fault_db_body(trap_rip: u64, anchor: u64) {
        let h = DB_HOOK.load(core::sync::atomic::Ordering::Acquire);
        if h != 0 {
            // SAFETY: 前置条件 —— 地址来自 set_db_hook 存入的 fn(u64,u64)。
            // 不变式 —— Release/Acquire 配对；注册先于布防。
            // 并发 —— 每 CPU 独立命中，钩子自身无共享可变态（串口写）。
            // 违反后果 —— 跳转伪造地址即任意代码执行（注册纪律封死）。
            let f: fn(u64, u64) = unsafe { core::mem::transmute(h) };
            f(trap_rip, anchor);
        }
    }

    /// 墙钟钩子（M10-A）：IRQ0 主体消费——per-CPU tick 账户 + 老化扫描
    /// + 本核（接收核）抢占判定。返回 true = 已填写 plan（桩执行交换）。
    static WALL_HOOK: core::sync::atomic::AtomicUsize = core::sync::atomic::AtomicUsize::new(0);

    /// 注册墙钟钩子（内核调度器初始化时调用；未注册时 PIT 退回纯墙钟）。
    pub fn set_wall_hook(hook: fn(&mut super::PreemptPlan) -> bool) {
        WALL_HOOK.store(hook as usize, core::sync::atomic::Ordering::Release);
    }

    /// RESCHED 抢占钩子（M10-A）：RESCHED IPI 主体在重调度提示钩子之后
    /// 消费本核 PREEMPT_REQ 旗——置位则按抢占规则填写 plan。
    static RESCHED_PREEMPT_HOOK: core::sync::atomic::AtomicUsize =
        core::sync::atomic::AtomicUsize::new(0);

    /// 注册 RESCHED 抢占钩子（内核调度器初始化时调用）。
    pub fn set_resched_preempt_hook(hook: fn(&mut super::PreemptPlan) -> bool) {
        RESCHED_PREEMPT_HOOK.store(hook as usize, core::sync::atomic::Ordering::Release);
    }

    /// 重调度提示钩子（M6-A：RESCHED IPI 主体；置跨核唤醒标志）。
    static RESCHED_HOOK: core::sync::atomic::AtomicUsize = core::sync::atomic::AtomicUsize::new(0);

    /// 注册重调度提示钩子（内核调度器初始化时调用）。
    pub fn set_resched_hook(hook: fn()) {
        RESCHED_HOOK.store(hook as usize, core::sync::atomic::Ordering::Release);
    }

    /// IRQ0 主体（向量 32）：墙钟打点 + 主片 EOI + 墙钟钩子（M10-A）。
    ///
    /// plan 参数由桩汇编契约传入（rdi = &plan）；返回 1 = 已填写 plan
    /// （桩执行抢占交换）。M6-M10 历史语义：M6 起纯墙钟不再驱动抢占；
    /// M10-A 起 PIT 升级为全上下文时间源（账户/老化/接收核抢占）。
    #[no_mangle]
    extern "C" fn isr_timer_body(plan: &mut super::PreemptPlan) -> u32 {
        crate::time::tick();
        crate::hw::pic::eoi_master();
        let hook = WALL_HOOK.load(core::sync::atomic::Ordering::Acquire);
        if hook != 0 {
            // SAFETY: 前置条件 —— 地址来自 set_wall_hook 存入的
            //          fn(&mut PreemptPlan) -> bool。
            // 不变式 —— Release/Acquire 配对；注册先于 PIT 抢占消费。
            // 并发 —— IRQ0 仅交付接收核（PIC 路由 BSP）；plan 在本核栈上。
            // 违反后果 —— 跳转伪造地址即任意代码执行（注册纪律封死）。
            let f: fn(&mut super::PreemptPlan) -> bool = unsafe { core::mem::transmute(hook) };
            return u32::from(f(plan));
        }
        0
    }

    /// TSC deadline one-shot 主体（向量 0x43，M43-TSC39 笔㊹）：
    /// LAPIC EOI + DEADLINE_TICKS 计数取证 + **交付后解除武装**
    /// （M44-TSCRG44 笔㊾——tsc_deadline_disarm LVT mask 口径：QEMU
    /// TCG deadline 过期重复交付域退役〔MSR deadline 未清持续真
    /// ——mask 斩断交付路径零重交付〕，真硬件 LVT deadline 交付后
    /// 本不重触发、mask 无害同谱——双域收敛 exact-one 交付，t143
    /// 零增判据承载；零抢占零钩子——one-shot 交付面，t138 断言面）。
    #[no_mangle]
    extern "C" fn isr_tsc_deadline_body(plan: &mut super::PreemptPlan) -> u32 {
        crate::hw::lapic::eoi();
        crate::hw::lapic::tsc_deadline_disarm();
        crate::hw::lapic::DEADLINE_TICKS.fetch_add(1, core::sync::atomic::Ordering::AcqRel);
        let _ = plan;
        0
    }

    /// LAPIC 定时器主体（向量 0x41）：LAPIC EOI + 定时器钩子。
    ///
    /// 返回 1 = 已填写 plan（桩执行抢占交换）；0 = 放行。
    #[no_mangle]
    extern "C" fn isr_lapic_timer_body(plan: &mut super::PreemptPlan) -> u32 {
        crate::hw::lapic::eoi();
        let hook = TIMER_HOOK.load(core::sync::atomic::Ordering::Acquire);
        if hook != 0 {
            // SAFETY: 前置条件 —— 地址来自 set_timer_hook 存入的
            //          fn(&mut PreemptPlan) -> bool。
            // 不变式 —— Release/Acquire 配对；注册先于定时器启动。
            // 并发 —— 各核仅在自身中断窗口内调用（plan 在本核栈上）。
            // 违反后果 —— 跳转伪造地址即任意代码执行（注册纪律封死）。
            let f: fn(&mut super::PreemptPlan) -> bool = unsafe { core::mem::transmute(hook) };
            return u32::from(f(plan));
        }
        0
    }

    /// RESCHED IPI 主体（向量 0x42）：LAPIC EOI + 重调度提示钩子 +
    /// 抢占钩子（M10-A：消费本核 PREEMPT_REQ，置位则填写 plan）。
    ///
    /// 返回 1 = 已填写 plan（桩执行抢占交换）；0 = 放行。
    #[no_mangle]
    extern "C" fn isr_resched_body(plan: &mut super::PreemptPlan) -> u32 {
        crate::hw::lapic::eoi();
        let hook = RESCHED_HOOK.load(core::sync::atomic::Ordering::Acquire);
        if hook != 0 {
            // SAFETY: 前置条件 —— 地址来自 set_resched_hook 存入的 fn()。
            // 不变式 —— Release/Acquire 配对；注册先于任何 RESCHED IPI。
            // 并发 —— 各核处理各自收到的 IPI（钩子只写本核可见状态）。
            // 违反后果 —— 跳转伪造地址即任意代码执行（注册纪律封死）。
            let f: fn() = unsafe { core::mem::transmute(hook) };
            f();
        }
        let preempt = RESCHED_PREEMPT_HOOK.load(core::sync::atomic::Ordering::Acquire);
        if preempt != 0 {
            // SAFETY: 前置条件 —— 地址来自 set_resched_preempt_hook 存入的
            //          fn(&mut PreemptPlan) -> bool。
            // 不变式 —— Release/Acquire 配对；注册先于任何抢占请求。
            // 并发 —— 各核仅在自身 IPI 窗口内调用（plan 在本核栈上）。
            // 违反后果 —— 跳转伪造地址即任意代码执行（注册纪律封死）。
            let f: fn(&mut super::PreemptPlan) -> bool = unsafe { core::mem::transmute(preempt) };
            return u32::from(f(plan));
        }
        0
    }

    /// 致命异常主体：转交流程（携带故障 RIP 与诊断帧；见 [`super::fault_exit`]）。
    #[no_mangle]
    extern "C" fn isr_fault_body(vector: u64, rip: u64, aux: u64) -> ! {
        super::fault_exit(vector, rip, aux)
    }

    /// IPI 钩子（M5：内核侧击落处理 + LAPIC EOI；向量 0x40 窗口内调用）。
    static IPI_HOOK: core::sync::atomic::AtomicUsize = core::sync::atomic::AtomicUsize::new(0);

    /// 注册 IPI 钩子（内核 SMP 初始化时调用；注册前收到 IPI 将被静默丢弃）。
    pub fn set_ipi_hook(hook: fn()) {
        IPI_HOOK.store(hook as usize, core::sync::atomic::Ordering::Release);
    }

    /// IPI 主体：转交钩子（EOI 由钩子负责——PIC/LAPIC 归属属内核策略）。
    #[no_mangle]
    extern "C" fn isr_ipi_body() {
        let hook = IPI_HOOK.load(core::sync::atomic::Ordering::Acquire);
        if hook != 0 {
            // SAFETY: 前置条件 —— 地址来自 set_ipi_hook 存入的 fn()。
            // 不变式 —— Release/Acquire 配对；注册只发生在首次 IPI 之前。
            // 并发 —— IPI 窗口串行（每核各自处理各自收到的 IPI）。
            // 违反后果 —— 跳转伪造地址即任意代码执行（注册纪律封死）。
            let f: fn() = unsafe { core::mem::transmute(hook) };
            f();
        }
    }

    /// 键盘钩子（M23-①：入参 = 原始 scancode；翻译/入环属内核 tty 策略）。
    static KBD_HOOK: core::sync::atomic::AtomicUsize = core::sync::atomic::AtomicUsize::new(0);

    /// 注册键盘钩子（内核 kbd 初始化时调用；PIC IRQ1 解 mask 先于此）。
    pub fn set_kbd_hook(hook: fn(u8)) {
        KBD_HOOK.store(hook as usize, core::sync::atomic::Ordering::Release);
    }

    /// 键盘主体（向量 33 = IRQ1）：读 scancode → 转交钩子 → 主片 EOI。
    /// IRQ1 恒落 PIC 主片（BSP 布线），EOI 归属确定故在桩内完成
    /// （与 IPI 桩「钩子负责 EOI」不同——那里 LAPIC/PIC 两可）。
    #[no_mangle]
    extern "C" fn isr_kbd_body() {
        // SAFETY: IRQ1 触发即输出缓冲满（控制器保证），直读 0x60。
        let sc = crate::hw::ports::read_u8(0x60);
        let hook = KBD_HOOK.load(core::sync::atomic::Ordering::Acquire);
        if hook != 0 {
            // SAFETY: 前置条件 —— 地址来自 set_kbd_hook 存入的 fn(u8)。
            // 并发 —— IRQ1 仅 BSP 布线触发（PIC 单一投递），串行。
            let f: fn(u8) = unsafe { core::mem::transmute(hook) };
            f(sc);
        }
        crate::hw::pic::eoi_master();
    }

    /// aux 钩子（M42-AUX25 笔㉕）：内核 kbd aux 车道注册点。
    static AUX_HOOK: core::sync::atomic::AtomicUsize = core::sync::atomic::AtomicUsize::new(0);

    /// 注册 aux 钩子（内核 kbd 初始化时调用；PIC IRQ12 解 mask 先于此）。
    pub fn set_aux_hook(hook: fn(u8)) {
        AUX_HOOK.store(hook as usize, core::sync::atomic::Ordering::Release);
    }

    /// aux 主体（向量 44 = IRQ12，M42-AUX25 笔㉕）：源位判读 → 读 0x60
    /// → 转交钩子 → 级联 EOI（从片先、主片随行——i8042 第二通道经
    /// PIC 从片 IRQ4 布线，级联协议双 EOI 纪律）。
    /// 源位判读 = STATUS bit5（ST_AUX_FULL）：IRQ12 触发即输出缓冲满，
    /// 但伪中断窗（spurious）下缓冲可空——OUT_FULL 未置位即跳过读取
    /// （零 0x60 误吸——防键盘字节被 aux 桩吞没）；置位时读 0x60，
    /// 仅 aux 源位在场的字节转交钩子（键盘源字节〔理论窗〕随行排空
    /// 不投递——投递域 = aux 电气源定义域）。
    #[no_mangle]
    extern "C" fn isr_aux_body() {
        let st = crate::hw::ps2::status();
        if st & crate::hw::ps2::ST_OUT_FULL != 0 {
            // SAFETY: OUT_FULL 置位即 DATA 可读（控制器保证）。
            let b = crate::hw::ports::read_u8(0x60);
            if st & crate::hw::ps2::ST_AUX_FULL != 0 {
                let hook = AUX_HOOK.load(core::sync::atomic::Ordering::Acquire);
                if hook != 0 {
                    // SAFETY: 前置条件 —— 地址来自 set_aux_hook 存入的
                    //          fn(u8)。
                    // 并发 —— IRQ12 仅 BSP 布线触发（PIC 从片单一投递），
                    //         串行；IRQ1/IRQ12 异源可交错——钩子侧环
                    //         生产单写纪律由消费域承载（aux 车道 SPSC
                    //         生产侧 ISR 语境 = aux 桩唯一写者）。
                    let f: fn(u8) = unsafe { core::mem::transmute(hook) };
                    f(b);
                }
            }
        }
        crate::hw::pic::eoi_slave(); // 级联纪律：从片 EOI 先行
        crate::hw::pic::eoi_master(); // 主片随行（IRQ12 经从片级联）
    }

    /// 可恢复 #PF 钩子（M5：按需分页；参数 = CR2 故障地址 + 错误码，
    /// 返回 true 表示已修复映射、桩将重执行故障指令）。
    static PF_REC_HOOK: core::sync::atomic::AtomicUsize = core::sync::atomic::AtomicUsize::new(0);

    /// 注册可恢复 #PF 钩子（内核 VMM 初始化时调用；未注册时 #PF 保持
    /// 致命语义——与 M3/M4 行为严格一致）。
    pub fn set_pf_rec_hook(hook: fn(u64, u64) -> bool) {
        PF_REC_HOOK.store(hook as usize, core::sync::atomic::Ordering::Release);
    }

    /// 可恢复 #PF 主体：返回 1 = 已处理（桩恢复现场重执行），0 = 转致命。
    #[no_mangle]
    extern "C" fn isrf_pf_rec_body(cr2: u64, error_code: u64) -> u32 {
        let hook = PF_REC_HOOK.load(core::sync::atomic::Ordering::Acquire);
        if hook != 0 {
            // SAFETY: 前置条件 —— 地址来自 set_pf_rec_hook 存入的
            //          fn(u64, u64) -> bool。
            // 不变式 —— Release/Acquire 配对；注册先于任何可恢复 #PF。
            // 并发 —— #PF 天然串行于当前核；钩子自身不得再触发 #PF
            //         （其映射路径走物理地址直写，不依赖 MMU）。
            // 违反后果 —— 递归 #PF 将升级为 #DF（致命，冒烟非 33 退出）。
            let f: fn(u64, u64) -> bool = unsafe { core::mem::transmute(hook) };
            return u32::from(f(cr2, error_code));
        }
        0
    }
}

#[cfg(test)]
#[allow(clippy::unwrap_used, clippy::expect_used)]
mod tests {
    use super::{Idt, IdtEntry};

    #[test]
    fn interrupt_gate_encodes_handler() {
        let addr: u64 = 0x1_2345_6789_ABCD;
        let e = IdtEntry::interrupt(addr);
        assert!(e.points_to(addr));
        assert!(!e.points_to(0xDEAD_BEEF));
    }

    #[test]
    fn interrupt_gate_ist_encodes_handler_and_ist() {
        // M41-笔①：IST 版门——同 handler 编码 + IST 域置位（位 32）
        let addr: u64 = 0x1_2345_6789_ABCD;
        let e = IdtEntry::interrupt_ist(addr, 1);
        assert!(e.points_to(addr));
        // IST 域 = 1：lo 位 32 置位（interrupt() 版恒 0）
        assert!(e.lo & (1 << 32) != 0);
        let e0 = IdtEntry::interrupt(addr);
        assert!(e0.lo & (1 << 32) == 0);
    }

    #[test]
    fn gate_layout_matches_sdm() {
        // 0x1000：低 16 位与 [47:32] 承载；属性 0x8E 在 [47:40]；IST=0
        let e = IdtEntry::interrupt(0x1000);
        assert!(e.points_to(0x1000));
        // 空门不指向任何非零地址
        assert!(!IdtEntry::EMPTY.points_to(0x1000));
    }

    #[test]
    fn set_raw_and_check() {
        let mut idt = Idt::new();
        idt.set_raw(32, 0x2000);
        idt.set_raw(14, 0x3000);
        assert!(idt.entry_points_to(32, 0x2000));
        assert!(idt.entry_points_to(14, 0x3000));
        assert!(!idt.entry_points_to(33, 0x2000));
        idt.set_raw(256, 0x4000); // 越界：防御式忽略
        assert_eq!(Idt::byte_len(), 4096);
    }
}
