//! 用户态进程支持（M4）：用户页表构建、ring3 进入桩、首测试程序映像。
//!
//! 页表布局（用户根 = 全新四级表）：
//! - PML4[0] → 新建 PDPT → 新建 PD：PD[i] 复刻启动恒等映射（2 MiB 大页，
//!   P|W，supervisor）——**PD[2] 例外**：展开为 4 KiB PT，承载用户页；
//! - PT[0] = 用户代码帧（virt 0x400000，P|U，只读——NX 未启用可执行）；
//!   PT[2] = 用户栈帧（virt 0x402000，P|U|W）；
//! - supervisor 页对 ring3 不可见（U=0），内核隔离成立。
//!
//! ring3 进入：`lumina_enter_user` 桩载入用户数据段选择子（DS/ES=0x23，
//! FS/GS 置空）后以 iretq 压入 SS/RSP/RFLAGS(IF=1)/CS/RIP 五元组。
//! 自此该任务的后续内核切入全部经 TSS.RSP0（其独立内核栈顶）。
//!
//! unsafe 面：进入桩（USER-01 白名单）与恒等映射物理内存直写
//! （经 `ostd::hw::phys` 收口）。

use core::arch::global_asm;

use alloc::vec::Vec;
use ostd::mm::frame::FRAME_SIZE;
use ostd::mm::page::Entry;

// M14-① 多段映像生成产物（勿手改：scripts/gen_m14_images.py 再生成）。
include!("exec_images_gen.rs");
// M16 探针包装与深触映像（勿手改：scripts/gen_m16_images.py 再生成）。
include!("exec_images_m16_gen.rs");
// M23-②③ init（PID 1 ring3 shell）映像（勿手改：scripts/gen_m23_images.py 再生成）。
include!("exec_images_gen_m23.rs");
// M42-FBDEV1 用户态 fb 驱动进程映像（勿手改：scripts/gen_m42_fbdev_image.py 再生成）。
include!("exec_images_gen_m42.rs");
// M42-ELF5 用户态 ELF 播种 lane 映像（勿手改：scripts/gen_m42_elf_lane.py 再生成）。
include!("exec_images_gen_m42_elf.rs");
// M47-LDCONS53 装载计划消费面批交付件（勿手改：scripts/gen_m47_ldlumina.py
// 再生成——ld-lumina.so 本体 + ring3 消费探针；artifacts/ 单一事实源）。
include!("exec_images_m47.rs");
// M47-DLOPEN54 dlopen 真消费面批交付件（勿手改：scripts/gen_m47b_dlopen.py
// 再生成——liblumina-core.so 依赖库 + ring3 自装载链探针；artifacts/
// 单一事实源——gen_m47_ldlumina 单源锚随行）。
include!("exec_images_m47b.rs");
// M48-PLTGOT55 PLT/GOT 惰性绑定电气执行批交付件（勿手改：
// scripts/gen_m48a_pltgot.py 再生成——ring3 惰性绑定电气探针；
// artifacts/ 单一事实源）。
include!("exec_images_m48a.rs");
include!("exec_images_m50.rs");
// M48-DLSYM56 dlsym 跨模块查找电气批交付件（勿手改：scripts/gen_m48b_dlsym.py
// 再生成——ring3 跨模块查找电气探针；artifacts/ 单一事实源——
// gen_m47b core 本体单源锚随行）。
include!("exec_images_m48b.rs");
// M48-INIT57 init_array 执行域批交付件（勿手改：scripts/gen_m48c_init.py
// 再生成——liblumina-init.so 初始化域模块；artifacts/ 单一事实源）。
include!("exec_images_m48c.rs");
// M51-EXECDYN73 SYS_EXEC 动态分流批交付件（勿手改：scripts/gen_m51_execdyn.py
// 再生成——ring3 动态分流电气探针 + 迷你动态件；artifacts/ 单一事实源）。
include!("exec_images_m51.rs");

/// 用户代码段虚拟基址（PT[0]）。
pub const USER_CODE_VIRT: u64 = 0x40_0000;
/// 用户栈虚拟基址（PT[2]，单页）。
pub const USER_STACK_VIRT: u64 = 0x40_2000;
/// 用户栈顶（栈向低地址生长；首压即 0x403000-8）。
pub const USER_STACK_TOP: u64 = USER_STACK_VIRT + FRAME_SIZE;

/// 首测试程序：LOG("USER-OK") → YIELD×32 → EXIT(42)。
///
/// 手工汇编（位置固定 0x400000；寄存器约定 = bedrock abi v0：
/// rax=编号，rdi/rsi/rdx/r10/r8 = 五参数，rcx/r11 被 SYSCALL 吞掉）：
///
/// ```text
/// 0x400000  BF 2C 00 40 00   mov edi, 0x40002C       ; 字符串指针
/// 0x400005  BE 07 00 00 00   mov esi, 7              ; 长度
/// 0x40000A  31 C0            xor eax, eax            ; SYS_LOG
/// 0x40000C  0F 05            syscall
/// 0x40000E  BB 20 00 00 00   mov ebx, 32             ; 循环计数
/// 0x400013  B8 02 00 00 00   mov eax, 2              ; SYS_YIELD（循环头）
/// 0x400018  0F 05            syscall
/// 0x40001A  FF CB            dec ebx
/// 0x40001C  75 F5            jnz 0x400013
/// 0x40001E  BF 2A 00 00 00   mov edi, 42             ; 退出码
/// 0x400023  B8 01 00 00 00   mov eax, 1              ; SYS_EXIT
/// 0x400028  0F 05            syscall
/// 0x40002A  EB FE            jmp $                   ; EXIT 失效则原地停
/// 0x40002C  "USER-OK"                                ; 7 字节
/// ```
pub const USER_PROGRAM: [u8; 51] = [
    0xBF, 0x2C, 0x00, 0x40, 0x00, // mov edi, 0x40002C
    0xBE, 0x07, 0x00, 0x00, 0x00, // mov esi, 7
    0x31, 0xC0, // xor eax, eax
    0x0F, 0x05, // syscall
    0xBB, 0x20, 0x00, 0x00, 0x00, // mov ebx, 32
    0xB8, 0x02, 0x00, 0x00, 0x00, // mov eax, 2
    0x0F, 0x05, // syscall
    0xFF, 0xCB, // dec ebx
    0x75, 0xF5, // jnz loop
    0xBF, 0x2A, 0x00, 0x00, 0x00, // mov edi, 42
    0xB8, 0x01, 0x00, 0x00, 0x00, // mov eax, 1
    0x0F, 0x05, // syscall
    0xEB, 0xFE, // jmp $
    b'U', b'S', b'E', b'R', b'-', b'O', b'K', // "USER-OK"
];

/// IPC 客户端常量：载荷缓冲（栈页内，P|U|W；程序字节码内嵌同值）。
#[allow(dead_code)] // 文档锚点：字节码内嵌 0x402F00 的常量定义源
pub const USER_IPC_PAYLOAD_VA: u64 = 0x40_2F00;
/// IPC 客户端常量：接收缓冲。
pub const USER_IPC_RECV_VA: u64 = 0x40_2E00;
/// 回声验证字（"PING" 的小端双字）。
pub const PING_WORD: u32 = 0x474E_4950;

/// IPC 客户程序（自检 24；位置固定 0x400000，能力槽由 spawn 注入）。
/// M12-A 句柄寻址版：端点参数 = 调用方句柄（内核解析句柄→能力→对象→
/// 通道反查；无效句柄与无授权对外同面 ERR_CAP）。
///
/// ```text
/// payload = "PING"（写 0x402F00）
/// 负探针：SEND(h=2 未持有) → 必返回 ERR_CAP(1)，否则 EXIT(53)
/// 正发送：SEND(h=1 主身份=回声能力, payload, 4, tag=0x21) → 必 0
/// 重试环（≤64 次，间以 SYS_YIELD）：
///   RECV(h=1, 0x402E00, 120)
///   非零 = (tag<<32)|len → 校验 [0x402E00] == "PING" → EXIT(52)
///   零 = 让出重试；超预算 → EXIT(53)
/// ```
///
/// 字节码由两遍微型汇编器生成（scripts/asm_m12/，objdump 已收口）。
pub const USER_IPC_PROGRAM: [u8; 171] = [
    0xB8, 0x50, 0x49, 0x4E, 0x47, 0xA3, 0x00, 0x2F, 0x40, 0x00, 0x00, 0x00, 0x00, 0x00, 0xBF, 0x02,
    0x00, 0x00, 0x00, 0xBE, 0x04, 0x00, 0x00, 0x00, 0xBA, 0x00, 0x2F, 0x40, 0x00, 0x41, 0xBA, 0x21,
    0x00, 0x00, 0x00, 0xB8, 0x03, 0x00, 0x00, 0x00, 0x0F, 0x05, 0x48, 0x83, 0xF8, 0x01, 0x75, 0x6D,
    0xBF, 0x01, 0x00, 0x00, 0x00, 0xBE, 0x04, 0x00, 0x00, 0x00, 0xBA, 0x00, 0x2F, 0x40, 0x00, 0x41,
    0xBA, 0x21, 0x00, 0x00, 0x00, 0xB8, 0x03, 0x00, 0x00, 0x00, 0x0F, 0x05, 0x48, 0x85, 0xC0, 0x75,
    0x4C, 0xB9, 0x40, 0x00, 0x00, 0x00, 0xBF, 0x01, 0x00, 0x00, 0x00, 0xBE, 0x78, 0x00, 0x00, 0x00,
    0xBA, 0x00, 0x2E, 0x40, 0x00, 0xB8, 0x04, 0x00, 0x00, 0x00, 0x0F, 0x05, 0x48, 0x85, 0xC0, 0x75,
    0x0D, 0xB8, 0x02, 0x00, 0x00, 0x00, 0x0F, 0x05, 0xFF, 0xC9, 0x75, 0xDA, 0xEB, 0x1F, 0xA1, 0x00,
    0x2E, 0x40, 0x00, 0x00, 0x00, 0x00, 0x00, 0xB9, 0x50, 0x49, 0x4E, 0x47, 0x48, 0x39, 0xC8, 0x75,
    0x0C, 0xBF, 0x34, 0x00, 0x00, 0x00, 0xB8, 0x01, 0x00, 0x00, 0x00, 0x0F, 0x05, 0xBF, 0x35, 0x00,
    0x00, 0x00, 0xB8, 0x01, 0x00, 0x00, 0x00, 0x0F, 0x05, 0xEB, 0xFE,
];

// ring3 进入桩（USER-01 白名单，M7-A 扩展；M12 扩：rdx = 遗传细胞 → r14）：
// 载用户数据段后 iretq 降权。
//
// M12 遗传细胞寄存器协议：细胞值由第三参数传入，桩首指令 `mov r14,
// rdx` 后方进入环——子进程凭非零 r14 自证被派生身份（根父恒 0）。
// M22-③ 第二项：rdx 来源改跳板入口窗传参（trampoline_user 与入口点
// 同窗取任务父链）+ 任务创建时点 ctx.r14 焊接同源交叉自证——桥面
// 不再读 CURRENT（round-585/664 首派发窗口二次读竞态根治）。
// 置于 asm 内是为了避开 Rust 中间函数的 r14 使用（callee-saved 寄存器
// 对编译器自由可用，只有桩自身能保证入口前的取值存续到 iretq）。
// iretq 不触碰 GPR，r14 直达用户首指令。
//
// M8-A 注意：**不触碰 GS 选择子**（FS 置空保留）——GS/FS 保留未来用户
// TLS；内核不消费 GS（swapgs 纪律定版，见 syscall.rs 模块文档），
// 长模式下向 FS/GS 装载选择子会重写隐藏基址，维持不触碰纪律。
//
// SAFETY（调用方义务）：
// - CR3 已为该任务的用户根（调度器 `prepare_dispatch` 保证）；
// - GDT 已装载完整布局（ucode=0x18/udata=0x20，ostd::hw::gdt::install）；
// - 本函数运行于该任务的内核栈上，iretq 后内核栈视为「已清空」；
// - 本核 per-CPU syscall 栈已由 prepare_dispatch 落位（syscall 入口
//   桩 LAPIC 索引读数，M8-A 契约）。
global_asm! {
    ".text",
    ".globl lumina_enter_user",
    "lumina_enter_user:",
    "    mov r14, rdx",
    "    mov ax, 0x23",
    "    mov ds, ax",
    "    mov es, ax",
    "    xor ax, ax",
    "    mov fs, ax",
    "    push 0x23",
    "    push rsi",
    "    push 0x202",
    "    push 0x1B",
    "    push rdi",
    "    iretq",
}

unsafe extern "C" {
    /// 见上方 global_asm 契约（rdi=入口 rip，rsi=用户栈顶，rdx=遗传细胞）。
    fn lumina_enter_user(entry: u64, stack_top: u64, cell: u64) -> !;
}

/// 用户入口桥：task.rs 的 `trampoline_user` 经此进入 ring3。
/// M22-③ 第二项：遗传细胞改参数传入（跳板入口窗与入口点同窗取值，
/// 桥面免读 CURRENT——round-585/664 r14 注入竞态根治）。
pub extern "C" fn enter_user_bridge(cell: u64) -> ! {
    let (entry, stack) = (USER_CODE_VIRT, USER_STACK_TOP);
    // SAFETY: 桩契约（见 global_asm 文档）：CR3/GDT 由调度器与内核
    //         初始化路径保证；本调用永不返回。
    unsafe { lumina_enter_user(entry, stack, cell) }
}

// fork 子代定点进入桩（M33-P1；USER-01 白名单同族——iretq 降权面）：
// rdi = 全量寄存器快照指针（SyscallFrame repr(C) 槽序 15 槽）。
//
// Linux fork 子代返回协议：rip/rsp/rflags 取自快照（父 syscall 返回
// 点），callee-saved（rbx/rbp/r12-r15）逐槽恢复（musl/busybox 子代
// 跨 fork 活跃局部量保真面），rax = 0 定子代身份。参数寄存器
// （rdi/rsi/rdx/r10/r8/r9/rcx/r11）不恢复——SysV caller-saved 语义
// 用户态不跨 syscall 依赖（Linux 内核侧亦只保 callee-saved 面）。
//
// 栈序：SS/RSP/RFLAGS/CS/RIP 五元组自高址向低址压入（iretq 期望序）。
//
// SAFETY（调用方义务）：
// - CR3 已为该子任务的用户根（调度器 prepare_dispatch 保证——COW 克
//   隆根与父同构，快照中的 rip/rsp 虚地址天然有效）；
// - slots 指针在 iretq 前持续有效（调用方栈局部存活至本函数永不返回）；
// - 中断前置条件与 lumina_enter_user 同（trampoline_user 已 enable）。
global_asm! {
    ".text",
    ".globl lumina_enter_user_fork",
    "lumina_enter_user_fork:",
    "    push 0x23",            // SS
    "    mov rax, [rdi + 56]", // 用户 RSP 槽
    "    push rax",            // RSP
    "    mov rax, [rdi + 0]",  // RFLAGS 槽（IF=1 同源）
    "    push rax",            // RFLAGS
    "    push 0x1B",           // CS
    "    push qword ptr [rdi + 8]", // RIP（父 syscall 返回点）
    "    mov rbx, [rdi + 72]",
    "    mov rbp, [rdi + 80]",
    "    mov r12, [rdi + 88]",
    "    mov r13, [rdi + 96]",
    "    mov r14, [rdi + 104]",
    "    mov r15, [rdi + 112]",
    "    xor eax, eax",        // Linux fork 子代返回协议：rax = 0
    "    iretq",
}

unsafe extern "C" {
    /// 见上方 global_asm 契约（rdi = 快照指针；永不返回）。
    fn lumina_enter_user_fork(slots: *const u64) -> !;
}

/// fork 子代定点进入（M33-P1）：task.rs `trampoline_user` fork 分流
/// 消费面。SAFETY：slots 为调用方栈局部（trampoline 帧存活至 iretq）；
/// 桩契约见 global_asm 文档。
pub fn enter_fork_child(slots: &[u64; 15]) -> ! {
    // SAFETY: 前置条件 —— CR3/GDT/中断由调度器与 trampoline_user 保证；
    //         slots 指针跨 iretq 存活（本函数永不返回，调用方帧冻结）。
    unsafe { lumina_enter_user_fork(slots.as_ptr()) }
}

/// 用户地址空间构造结果。
pub struct UserSpace {
    /// 用户页表根物理地址。
    pub root: u64,
    /// 用户代码帧物理地址。
    pub code_frame: u64,
    /// 用户栈帧物理地址。
    pub stack_frame: u64,
}

// ---------------------------------------------------------------------------
// M8-B：swap 回收全链测试面（数据页分支 + ring3 读写程序）
// ---------------------------------------------------------------------------

/// 回收测试数据区虚拟基址（PML4[0]→PDPT[5] 全新分支——避开 PD[2]
/// 恒等镜像区：内核映像/堆依赖镜像完整，不可拆位）。
pub const SWAP_DATA_VA: u64 = 0x1_4000_0000;
/// 回收测试数据页数（4 页 ring3 写入 + 4 页内核预写，共 8 页）。
pub const SWAP_DATA_PAGES: usize = 8;
/// ring3 写入魔数基（页 i 期望值 = 基 | i；字节码内嵌同值——文档锚点）。
#[allow(dead_code)] // USER_SWAP_PROGRAM 字节码内嵌 0x5CA9000000A00000 的常量定义源
pub const SWAP_MAGIC_USER: u64 = 0x5CA9_0000_00A0_0000;
/// 内核预写魔数基（页 4..8；淘汰后经盘往返复原取证）。
pub const SWAP_MAGIC_KERN: u64 = 0x5CA9_0000_00B0_0000;

/// 为既有用户根挂载回收测试数据页：PML4[0]→PDPT[5]→PD→PT 四级全新
/// 分支（中间层逐层补 U 位——权限逐层 AND，任一层缺 U 用户态即被拒）。
/// 页帧清零后返回帧地址表；由调用方决定预写内容。表帧（PD/PT）留作
/// 遗迹（与自检 9/14 惯例一致）。
pub fn attach_data_pages<F>(root: u64, mut alloc_frame: F) -> Option<alloc::vec::Vec<u64>>
where
    F: FnMut() -> Option<u64>,
{
    let pml4e0 = ostd::hw::phys::read_u64(root);
    if pml4e0 & 1 == 0 {
        return None;
    }
    let pdpt = pml4e0 & !0xFFF;
    let pdpt5_slot = pdpt + 5 * 8;
    if ostd::hw::phys::read_u64(pdpt5_slot) & 1 != 0 {
        return None; // 槽位已占用（非全新分支，防御拒绝）
    }
    let pd2 = alloc_frame()?;
    let pt2 = alloc_frame()?;
    ostd::hw::phys::write_zero(pd2, FRAME_SIZE);
    ostd::hw::phys::write_zero(pt2, FRAME_SIZE);
    let user_table = Entry::USER;
    ostd::hw::phys::write_u64(pdpt5_slot, Entry::table(pd2).bits() | user_table);
    ostd::hw::phys::write_u64(pd2, Entry::table(pt2).bits() | user_table);
    let mut frames = alloc::vec::Vec::new();
    for j in 0..SWAP_DATA_PAGES as u64 {
        let f = alloc_frame()?;
        ostd::hw::phys::write_zero(f, FRAME_SIZE);
        ostd::hw::phys::write_u64(
            pt2 + j * 8,
            Entry::page(f, Entry::USER | Entry::WRITABLE).bits(),
        );
        frames.push(f);
    }
    Some(frames)
}

/// 回收全链测试程序（位置固定 0x400000，共 0x91 字节）：
///
/// ```text
/// 阶段一：写页 0..3 = SWAP_MAGIC_USER|i（页 4..8 已由内核预写魔数）
/// 阶段二：SYS_YIELD ×1（调度节拍；淘汰已在派生前内核侧完成）
/// 阶段三：读 8 页并校验（0..3 用户魔数 / 4..8 内核魔数——被淘汰的
///         4 页经 #PF → swap-in 重映射复原），失败 EXIT(45)
/// 终态：EXIT(44)
/// ```
///
/// 字节码手工汇编（寄存器约定 = bedrock abi v0；rel 偏移已逐条核算：
/// jl@0x28→0x0C、jge@0x50→0x5C、jne@0x62→0x84、jl@0x74→0x3D，总长 0x92）。
pub const USER_SWAP_PROGRAM: [u8; 0x92] = [
    // 0x00: movabs r15, 0x140000000
    0x49, 0xBF, 0x00, 0x00, 0x00, 0x40, 0x01, 0x00, 0x00, 0x00, // 0x0A: xor ebx, ebx
    0x31, 0xDB, // 0x0C: movabs rax, 0x5CA9000000A00000（写环起点）
    0x48, 0xB8, 0x00, 0x00, 0xA0, 0x00, 0x00, 0x00, 0xA9, 0x5C, // 0x16: or rax, rbx
    0x48, 0x09, 0xD8, // 0x19: mov [r15], rax
    0x49, 0x89, 0x07, // 0x1C: add r15, 4096
    0x49, 0x81, 0xC7, 0x00, 0x10, 0x00, 0x00, // 0x23: inc ebx
    0xFF, 0xC3, // 0x25: cmp ebx, 4
    0x83, 0xFB, 0x04, // 0x28: jl 0x0C
    0x7C, 0xE2, // 0x2A: mov eax, 2（SYS_YIELD）
    0xB8, 0x02, 0x00, 0x00, 0x00, // 0x2F: syscall
    0x0F, 0x05, // 0x31: movabs r15, 0x140000000（读环复位）
    0x49, 0xBF, 0x00, 0x00, 0x00, 0x40, 0x01, 0x00, 0x00, 0x00, // 0x3B: xor ebx, ebx
    0x31, 0xDB,
    // 0x3D: mov rax, [r15]（淘汰页故障点：#PF → swap-in → 重执行）
    0x49, 0x8B, 0x07, // 0x40: mov rcx, rbx
    0x48, 0x89, 0xD9,
    // 0x43: movabs rdx, 0x5CA9000000B00000（内核魔数基，默认期望）
    0x48, 0xBA, 0x00, 0x00, 0xB0, 0x00, 0x00, 0x00, 0xA9, 0x5C, // 0x4D: cmp ebx, 4
    0x83, 0xFB, 0x04, // 0x50: jge 0x5C（跳过用户魔数基装载）
    0x7D, 0x0A, // 0x52: movabs rdx, 0x5CA9000000A00000（用户魔数基）
    0x48, 0xBA, 0x00, 0x00, 0xA0, 0x00, 0x00, 0x00, 0xA9, 0x5C, // 0x5C: or rcx, rdx
    0x48, 0x09, 0xD1, // 0x5F: cmp rax, rcx
    0x48, 0x39, 0xC8, // 0x62: jne 0x84（校验失败 → EXIT 45）
    0x0F, 0x85, 0x1C, 0x00, 0x00, 0x00, // 0x68: add r15, 4096
    0x49, 0x81, 0xC7, 0x00, 0x10, 0x00, 0x00, // 0x6F: inc ebx
    0xFF, 0xC3,
    // 0x71: cmp ebx, 4（读环止于自有写入页——被淘汰页由内核态读回）
    0x83, 0xFB, 0x04, // 0x74: jl 0x3D
    0x7C, 0xC7, // 0x76: mov edi, 44（EXIT 成功码）
    0xBF, 0x2C, 0x00, 0x00, 0x00, // 0x7B: mov eax, 1（SYS_EXIT）
    0xB8, 0x01, 0x00, 0x00, 0x00, // 0x80: syscall
    0x0F, 0x05, // 0x82: jmp $（EXIT 失效则原地停）
    0xEB, 0xFE, // 0x84: mov edi, 45（失败码）
    0xBF, 0x2D, 0x00, 0x00, 0x00, // 0x89: mov eax, 1
    0xB8, 0x01, 0x00, 0x00, 0x00, // 0x8E: syscall
    0x0F, 0x05, // 0x90: jmp $
    0xEB, 0xFE,
];

/// 优先级调度面自检程序（位置固定 0x400000，共 0x3B 字节）：
///
/// ```text
/// SYS_GET_PRIO → 期望 NORMAL(1)，否则 EXIT(50)
/// SYS_SET_PRIO(0) → 期望生效级 0，否则 EXIT(50)
/// EXIT(49)
/// ```
///
/// 字节码手工汇编（jne@0x0B→0x2B、jne@0x1D→0x2B 逐条核算）。
pub const USER_PRIO_PROGRAM: [u8; 0x3B] = [
    // 0x00: mov eax, 8（SYS_GET_PRIO）
    0xB8, 0x08, 0x00, 0x00, 0x00, // 0x05: syscall
    0x0F, 0x05, // 0x07: cmp rax, 1（NORMAL）
    0x48, 0x83, 0xF8, 0x01, // 0x0B: jne 0x2B
    0x75, 0x1E, // 0x0D: mov edi, 0（HIGH）
    0xBF, 0x00, 0x00, 0x00, 0x00, // 0x12: mov eax, 7（SYS_SET_PRIO）
    0xB8, 0x07, 0x00, 0x00, 0x00, // 0x17: syscall
    0x0F, 0x05, // 0x19: cmp rax, 0（生效级回读）
    0x48, 0x83, 0xF8, 0x00, // 0x1D: jne 0x2B
    0x75, 0x0C, // 0x1F: mov edi, 49（EXIT 成功码）
    0xBF, 0x31, 0x00, 0x00, 0x00, // 0x24: mov eax, 1（SYS_EXIT）
    0xB8, 0x01, 0x00, 0x00, 0x00, // 0x29: syscall
    0x0F, 0x05, // 0x2B: jmp $（EXIT 失效则原地停）
    0xEB, 0xFE, // 0x2D: mov edi, 50（失败码）
    0xBF, 0x32, 0x00, 0x00, 0x00, // 0x32: mov eax, 1
    0xB8, 0x01, 0x00, 0x00, 0x00, // 0x37: syscall
    0x0F, 0x05, // 0x39: jmp $
    0xEB, 0xFE,
];

// ---------------------------------------------------------------------------
// M9-A：进程模型测试面（跨任务能力授予 + 句柄生命周期，ring3 双程序）
// ---------------------------------------------------------------------------

/// 授予方数据槽：子任务 pid 存放虚拟地址（栈页内偏移 0x100；内核在
/// spawn 后写入，授予方轮询等待非零——无派发顺序假设，消除竞态窗口）。
pub const GRANT_PID_VA: u64 = 0x40_2100;
/// 授予测试对象 id（能力对象寻址；父能力 R|W 安装至授予方主身份句柄）。
pub const GRANT_OBJECT: u64 = 0x7A59_0000_0000_0001;

/// 能力授予方程序（父任务 A；位置固定 0x400000，共 0xA8 字节）：
///
/// ```text
/// 等待 [0x402100]（子任务 pid）非零（内核写入）
/// 探针 1：GRANT(子pid, handle=0, R) → 期望 ERR_HANDLE(5)，否则 EXIT(52)
/// 探针 2：GRANT(pid=0, handle=1, R) → 期望 ERR_TARGET(6)，否则 EXIT(52)
/// 探针 3：GRANT(子pid, handle=1, EXEC) → 期望 ERR_DERIVE(3)，否则 EXIT(52)
/// 正路径：GRANT(子pid, handle=1, READ) → 期望 (1<<32)|h（>7），否则 EXIT(56)
/// GET_PID → 期望 ≥ 1，否则 EXIT(52)
/// EXIT(53)
/// ```
///
/// 字节码由 scripts/asm_m9a.py 两遍微型汇编器生成（rel8 跳转已解析）。
pub const USER_CAP_GRANT_PROGRAM: [u8; 0xA8] = [
    0x4C, 0x8B, 0x3C, 0x25, 0x00, 0x21, 0x40, 0x00, 0x4D, 0x85, 0xFF, 0x74, 0xF3, 0x4C, 0x89, 0xFF,
    0x31, 0xF6, 0xBA, 0x01, 0x00, 0x00, 0x00, 0xB8, 0x09, 0x00, 0x00, 0x00, 0x0F, 0x05, 0x48, 0x83,
    0xF8, 0x05, 0x75, 0x68, 0x31, 0xFF, 0xBE, 0x01, 0x00, 0x00, 0x00, 0xBA, 0x01, 0x00, 0x00, 0x00,
    0xB8, 0x09, 0x00, 0x00, 0x00, 0x0F, 0x05, 0x48, 0x83, 0xF8, 0x06, 0x75, 0x4F, 0x4C, 0x89, 0xFF,
    0xBE, 0x01, 0x00, 0x00, 0x00, 0xBA, 0x04, 0x00, 0x00, 0x00, 0xB8, 0x09, 0x00, 0x00, 0x00, 0x0F,
    0x05, 0x48, 0x83, 0xF8, 0x03, 0x75, 0x35, 0x4C, 0x89, 0xFF, 0xBE, 0x01, 0x00, 0x00, 0x00, 0xBA,
    0x01, 0x00, 0x00, 0x00, 0xB8, 0x09, 0x00, 0x00, 0x00, 0x0F, 0x05, 0x48, 0x83, 0xF8, 0x07, 0x76,
    0x29, 0xB8, 0x0B, 0x00, 0x00, 0x00, 0x0F, 0x05, 0x48, 0x83, 0xF8, 0x01, 0x72, 0x0E, 0xBF, 0x35,
    0x00, 0x00, 0x00, 0xB8, 0x01, 0x00, 0x00, 0x00, 0x0F, 0x05, 0xEB, 0xFE, 0xBF, 0x34, 0x00, 0x00,
    0x00, 0xB8, 0x01, 0x00, 0x00, 0x00, 0x0F, 0x05, 0xEB, 0xFE, 0xBF, 0x38, 0x00, 0x00, 0x00, 0xB8,
    0x01, 0x00, 0x00, 0x00, 0x0F, 0x05, 0xEB, 0xFE,
];

/// 被授予方程序（子任务 B；cap_slot = 0，句柄表全空；位置固定 0x400000，
/// 共 0x3E 字节）：
///
/// ```text
/// 循环（≤10 万轮，间以 YIELD）：REVOKE(handle=1)
///   返回 0 → 授予已到达且本任务真实持有句柄 → EXIT(54)
///   返回非 0（ERR_HANDLE=5）→ 让出重试；超预算 → EXIT(55)
/// ```
///
/// 预算取值依据：YIELD 在空就绪队列上是 no-op（保持 Running 原地继续），
/// 纯迭代预算在微秒级烧完；A 需经 kick → idle 拾取 → 探针全链后才授予，
/// 预算必须覆盖量子级调度时延（10 万轮 ≈ 数百 ms 上界；正常首轮 REVOKE
/// 前授予已到达——A 钉扎 CPU1 无竞争，先于 B 首次派发完成全链）。
pub const USER_CAP_RECV_PROGRAM: [u8; 0x3E] = [
    0xBF, 0x01, 0x00, 0x00, 0x00, 0xB8, 0x0A, 0x00, 0x00, 0x00, 0x0F, 0x05, 0x48, 0x85, 0xC0, 0x74,
    0x1F, 0xB8, 0x02, 0x00, 0x00, 0x00, 0x0F, 0x05, 0xFF, 0xC3, 0x81, 0xFB, 0xA0, 0x86, 0x01, 0x00,
    0x7C, 0xDE, 0xBF, 0x37, 0x00, 0x00, 0x00, 0xB8, 0x01, 0x00, 0x00, 0x00, 0x0F, 0x05, 0xEB, 0xFE,
    0xBF, 0x36, 0x00, 0x00, 0x00, 0xB8, 0x01, 0x00, 0x00, 0x00, 0x0F, 0x05, 0xEB, 0xFE,
];

// ---------------------------------------------------------------------------
// M10：per-CPU tick 账户 / waitpid 测试面（ring3 双程序）
// ---------------------------------------------------------------------------

/// SPIN 哨兵虚拟地址（栈页内偏移 0x800；内核置非零后 spinner 退出——
/// 退出前无任何 syscall，旧形态下 ring3 时间面冻结的触发态）。
pub const SPIN_SENTINEL_VA: u64 = 0x40_2800;
/// WAIT_PID 父任务数据槽：子任务 pid 存放虚拟地址（栈页内偏移 0x100；
/// 内核 spawn 子任务后写入，父任务轮询等待非零——无派发顺序假设）。
pub const WAITPID_CPID_VA: u64 = 0x40_2100;

/// 遗传细胞寄存器协议（M12，替代 v0.11 的内存细胞）：父 pid 由
/// `lumina_enter_user` 桩写入 r14（根父恒 0）——同源程序凭非零 r14
/// 自证被派生身份（0 = 根父 / 非零 = 被派生子），杜绝 fork 炸弹族。
/// 寄存器协议是 COW 派生的前置：共享栈帧不可物理直写细胞。
/// （v0.11 内存细胞 0x402100 已退役；WAITPID 数据槽复用同址不受扰
/// —— t36 的空间为 build_user_space 私有栈，不经 spawn 克隆路径。）
///
/// HQ 武装哨兵虚拟地址（t38；栈页内偏移 0x108）：内核装完句柄 2 后写 1，
/// 探针程序轮询本哨兵——句柄预装与任务首跑的确定性排序面。
pub const HQ_ARM_VA: u64 = 0x40_2108;
/// HQ 武装哨兵栈帧内偏移。
pub const HQ_ARM_OFF: u64 = HQ_ARM_VA - USER_STACK_VIRT;

/// SPIN 程序（t34；位置固定 0x400000，共 0x1B 字节）：
///
/// ```text
/// 循环：读 [0x402800] 哨兵，非零 → EXIT(57)；零 → 继续（纯 ring3
/// 自旋——无 syscall：LAPIC 定时器被 prepare_dispatch 屏蔽，时间面
/// 冻结触发态；M10-A 后经 PIT 抢占/账户推进）
/// ```
///
/// 字节码由 scripts/asm_m10.py 生成（rel8 跳转已解析；test r15,r15
/// REX.WRB=0x4D 编码与 M9 同源核算）。
pub const USER_SPIN_PROGRAM: [u8; 0x1B] = [
    0x4C, 0x8B, 0x3C, 0x25, 0x00, 0x28, 0x40, 0x00, 0x4D, 0x85, 0xFF, 0x74, 0xF3, 0xBF, 0x39, 0x00,
    0x00, 0x00, 0xB8, 0x01, 0x00, 0x00, 0x00, 0x0F, 0x05, 0xEB, 0xFE,
];

/// WAIT_PID 父任务程序（t36；位置固定 0x400000，共 0xBC 字节）：
///
/// ```text
/// 等待 [0x402100]（子任务 pid）非零（内核写入）
/// WAIT_PID(0) → 拆位校验（成功位 1 / cpid == 哨兵 / 码 == 42）
///   任一不符 → EXIT(60)
/// WAIT_PID(0) 二次 → 期望 ERR_CHILD(8)（C 已收割），否则 EXIT(60)
/// GET_PID → WAIT_PID(own) → 期望 ERR_CHILD(8)（自身非自身子任务）
/// EXIT(59)
/// ```
///
/// 字节码由 scripts/asm_m10.py 生成（rel8 跳转 + REX 位操作族已核算）。
pub const USER_WAITPID_PROGRAM: [u8; 0xBC] = [
    0x4C, 0x8B, 0x3C, 0x25, 0x00, 0x21, 0x40, 0x00, 0x4D, 0x85, 0xFF, 0x74, 0xF3, 0x31, 0xFF, 0xB8,
    0x0C, 0x00, 0x00, 0x00, 0x0F, 0x05, 0x48, 0x89, 0xC3, 0x48, 0xC1, 0xEB, 0x20, 0x48, 0x83, 0xFB,
    0x01, 0x75, 0x53, 0x48, 0x89, 0xC1, 0x48, 0xC1, 0xE9, 0x10, 0x48, 0x81, 0xE1, 0xFF, 0xFF, 0x00,
    0x00, 0x49, 0x3B, 0xCF, 0x75, 0x4E, 0x48, 0x81, 0xE0, 0xFF, 0xFF, 0x00, 0x00, 0x48, 0x83, 0xF8,
    0x2A, 0x75, 0x4F, 0x31, 0xFF, 0xB8, 0x0C, 0x00, 0x00, 0x00, 0x0F, 0x05, 0x48, 0x83, 0xF8, 0x08,
    0x75, 0x4E, 0xB8, 0x0B, 0x00, 0x00, 0x00, 0x0F, 0x05, 0x89, 0xC7, 0xB8, 0x0C, 0x00, 0x00, 0x00,
    0x0F, 0x05, 0x48, 0x83, 0xF8, 0x08, 0x75, 0x46, 0xBF, 0x3B, 0x00, 0x00, 0x00, 0xB8, 0x01, 0x00,
    0x00, 0x00, 0x0F, 0x05, 0xEB, 0xFE, 0xBF, 0x3D, 0x00, 0x00, 0x00, 0xB8, 0x01, 0x00, 0x00, 0x00,
    0x0F, 0x05, 0xEB, 0xFE, 0xBF, 0x3E, 0x00, 0x00, 0x00, 0xB8, 0x01, 0x00, 0x00, 0x00, 0x0F, 0x05,
    0xEB, 0xFE, 0xBF, 0x3F, 0x00, 0x00, 0x00, 0xB8, 0x01, 0x00, 0x00, 0x00, 0x0F, 0x05, 0xEB, 0xFE,
    0xBF, 0x40, 0x00, 0x00, 0x00, 0xB8, 0x01, 0x00, 0x00, 0x00, 0x0F, 0x05, 0xEB, 0xFE, 0xBF, 0x41,
    0x00, 0x00, 0x00, 0xB8, 0x01, 0x00, 0x00, 0x00, 0x0F, 0x05, 0xEB, 0xFE,
];

/// 用户空间构造错误。
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum UserSpaceError {
    /// 中间表/页帧分配失败。
    FramesExhausted,
    /// LXE1 结构或放置策略不合格（M14-①：parse 失败/entry 不落 X 段/
    /// 段落点越域/槽位重叠/stack_top 非法）。
    BadImage,
}

// ---- M14-① 多段映像放置策略常量（与 scripts/gen_m14_images.py 交叉锚点双向对账） ----

/// PDPT[6] 全新分支段区基址（0x1_8000_0000；attach_data_pages 的
/// PDPT[5] 先例同款——**PD[2] 恒等镜像不可拆位**：内核堆 .bss 跨距
/// 覆盖 0x400000-0x600000，内核在用户 CR3 下经镜像访问堆，任何
/// PT[1]/PT[4+] 槽改写均属禁区，M14 设计定案 S55）。
pub const FRESH_BASE: u64 = 0x1_8000_0000;
/// 全新分支段区上界（PD6[0]→PT 一张，覆盖 2 MiB；段映射不得越界）。
pub const FRESH_LIMIT: u64 = FRESH_BASE + 0x20_0000;
/// ELF 链用户段域基址（M33-T1：PD[2] PT 槽域——linker.ld「程序基址
/// 0x400000 硬编码」契约窗口；Alpine 官方静态介质原生基址直载）。
/// S55 现况复核注：PD[2] 恒等镜像的内核借根依赖随 M19-① 内核堆显式
/// 放置 @0x600000（PD[3]+）+ round-243 收口后已不驻留内核数据（实测
/// 内核映像尾 ≈ 0x17b000 < 0x400000）——域内槽装载让渡为 busybox
/// 驻存期口径，swap/reap 跨帧借根面单任务挂账（build_user_space_elf
/// 文档注同源）。
pub const ELF_USER_BASE: u64 = 0x40_0000;
/// ELF 链用户段域上界（PD[2] 2 MiB 窗口 = 512 槽；busybox ~1 MiB 在域）。
pub const ELF_USER_LIMIT: u64 = 0x60_0000;
/// 增长栈顶（PD6[1]→pt_stack 顶；pt_stack[511] 预映射首帧，rsp 起此）。
pub const STACK_TOP_GROW: u64 = 0x1_8040_0000;
/// 动态解释器槽域基址（M50-MUSLRUN72 笔82：PD6[2] 槽——PDPT[6] 全新
/// 分支第三张 PT。布局雷区实录：PD[3+] = 0x600000+ 为内核堆恒等镜像
/// 借根禁区（用户 CR3 supervisor 面不可拆位），PD6[0] = LXE 段区 /
/// PD6[1] = 增长栈之外的双 MiB 空窗；ld-musl 真件 161 页（644 KiB）
/// 在域。栈自 STACK_TOP_GROW 向下长入 PD6[1]，本域向上无碰撞）。
pub const DYN_INTERP_BASE: u64 = 0x1_8040_0000;
/// 动态解释器槽域上界（PD6[2] 2 MiB 窗口 = 512 槽）。
pub const DYN_INTERP_LIMIT: u64 = DYN_INTERP_BASE + 0x20_0000;
/// 增长栈窗口页数（#PF 可扩上限 = 增长配额；与 M14-② 配额治理呼应）。
pub const STACK_GROW_WINDOW: usize = 32;
/// prog.lxe 成功哨兵（gen 脚本 RESULT_MAGIC 对账；低 16 位 = 退出码 91）。
/// 数据段虚地址 = FRESH_BASE + 0x1000（gen 脚本 PROG_DATA_VA 对账）、
/// 种子 = 0x00B0_0001（gen 脚本 SEED_MAGIC 对账）——仅生成器与映像
/// 字节引用，内核侧不直接取用（dead-code 门禁同步删除锚点常量）。
pub const PROG_RESULT_MAGIC: u64 = 0x00B0_0091;
/// LXE 映像装载预算（read_image 上限；M33-F1 起 busybox 介质 ~1 MiB
/// 在账——8 KiB 级静态映像之外，介质面同走 read_image 通道）。
pub const EXEC_IMAGE_MAX: usize = 4 * 1024 * 1024;

/// 构建用户地址空间：4 张中间表 + 代码帧 + 栈帧；返回根与帧地址。
///
/// 全程经 `ostd::hw::phys`（HW-03）直写恒等映射；表结构纯函数化，
/// 与 S4 宿主测试共享同一 Entry 位域语义。
pub fn build_user_space<F>(alloc_frame: &mut F) -> Result<UserSpace, UserSpaceError>
where
    F: FnMut() -> Option<u64>,
{
    build_user_space_with(&USER_PROGRAM, alloc_frame)
}

/// 指定映像的用户空间构建（M12-B SYS_EXEC 映像面：[`EXEC_IMAGES`] 表
/// 驱动；栈帧清零、代码帧装载指定映像）。
pub fn build_user_space_with<F>(
    image: &[u8],
    alloc_frame: &mut F,
) -> Result<UserSpace, UserSpaceError>
where
    F: FnMut() -> Option<u64>,
{
    let cs = build_space_frames(alloc_frame)?;
    // 装载用户程序映像
    ostd::hw::phys::write_bytes(cs.code_frame, image);
    Ok(UserSpace {
        root: cs.root,
        code_frame: cs.code_frame,
        stack_frame: cs.stack_frame,
    })
}

/// M51-EXECDYN73 笔84：ELF 动态分流探针（语义核）——ELF blob 探针
/// PT_INTERP 解释器路径串（NUL 已由 [`bedrock::elf::parse`] 剥离）：
/// 在场且 UTF-8 = 动态车道 `Some(路径)`；缺席/解析失败/非 UTF-8 =
/// 静态车道 `None`。[`crate::procs::exec_load_switch`] 分流臂唯一
/// 消费面（sys_exec/lin_execve 双车道上游单一事实源）。
pub fn elf_dyn_interp_path(blob: &[u8]) -> Option<&str> {
    if !bedrock::elf::probe(blob) {
        return None;
    }
    let img = bedrock::elf::parse(blob).ok()?;
    let raw = img.interp?;
    core::str::from_utf8(raw).ok()
}

/// SYS_EXEC 映像表（M14-① 扩容：内核内嵌字节表 → **VFS 路径表**；
/// M16-② 再扩容：追加 Weave 包源映像 prog.lwp 与增长栈动态扩容映像
/// deep.lxe）。索引即 SYS_EXEC 参数；越界 → ERR_IMAGE(10)。装载器经
/// 命名空间解析路径并整读映像（**VFS 第二消费者**——第一消费者为
/// 文件面 syscall），LXE1 解析与放置策略见 [`build_user_space_lxe`]。
/// **Weave 包源映像**（M16-②，EXEC 第 2+ 消费者）：.lwp 载荷经
/// `weave::pkg` 解包后进入同一 LXE1 装载链（直接 .lxe 为第一消费者）。
/// **动态链尾槽**（M51-EXECDYN73 笔84）：第 6 槽 `/bin/busybox-dyn`
/// = ELF 链首 EXEC 槽——PT_INTERP 在场即走动态分流臂（musl ldso
/// ring3 真执行——t161 直呼面升 ring3 车道；既有五槽 LXE/LWP 面
/// 零扰）。
pub const EXEC_IMAGES: [&str; 6] = [
    "/files/selftest.lxe",
    "/files/prog.lxe",
    "/files/grow.lxe",
    "/files/prog.lwp",
    "/files/deep.lxe",
    "/bin/busybox-dyn",
];

/// SYS_IMAGE_ENUM 主体（M18-③）：[`EXEC_IMAGES`] ring3 查询面。
///
/// 成功 = `(1 << 32) | (表容量 << 16) | 拷贝字节数`：第 `index` 项路径
/// 以 NUL 结尾整路径拷入调用方缓冲（零拷贝路径——长度校验先行）。
/// 索引越界 → [`crate::procs::ERR_IMAGE`]；缓冲容不下 NUL 结尾全路径
/// 或不可写 → `EFAULT(14)`。ring3 自此免硬编码映像表（枚举循环以
/// ERR_IMAGE 或高 16 位总数收口）。
pub fn sys_image_enum(index: u64, buf: u64, buf_len: u64) -> u64 {
    const EFAULT: u64 = 14;
    if index >= EXEC_IMAGES.len() as u64 {
        return crate::procs::ERR_IMAGE;
    }
    let path = EXEC_IMAGES[index as usize].as_bytes();
    let need = path.len() + 1; // NUL 结尾全路径
    if buf_len < need as u64 {
        return EFAULT;
    }
    let Some(dst) = crate::syscall::validate_user_slice_mut(buf, need as u64) else {
        return EFAULT;
    };
    dst[..path.len()].copy_from_slice(path);
    dst[path.len()] = 0;
    (1 << 32) | ((EXEC_IMAGES.len() as u64) << 16) | need as u64
}

/// 多段映像装载结果（M14-①）：根、入口、栈顶 + 段帧取证表。
pub struct ExecSpace {
    /// 用户页表根物理地址。
    pub root: u64,
    /// 入口虚地址（LXE 头 entry；已验证落于某 X 段内）。
    pub entry: u64,
    /// 栈顶（0x403000 遗留或 [`STACK_TOP_GROW`] 增长栈）。
    pub stack_top: u64,
    /// Linux 初始栈 rsp（M33-E1）：0 = 旧语义（rsp = stack_top）；
    /// 非 0 = ELF 链初始栈构造后的 rsp（argc/argv/envp/auxv 已写栈顶帧）。
    pub rsp: u64,
    /// 段帧表 (vaddr, frame)：每段首帧一条（v0 段均单帧预算内）。
    pub seg_frames: Vec<(u64, u64)>,
    /// 首个 W 段的首帧（哨兵轮询取证；无 W 段 = 0）。
    pub data_frame: u64,
}

/// LXE1 多段映像装载（M14-①）：结构解析（bedrock::exec）→ 放置
/// 策略校验 → PDPT[6] 全新分支映射。
///
/// 策略（结构校验已在 parse 完成，此处仅放置域）：
/// - 段 vaddr ∈ {0x400000（兼容槽：RX、单帧——repkg 既有程序）} ∪
///   [[`FRESH_BASE`], [`FRESH_LIMIT`])（PD6[0]→PT 全新分支，逐槽
///   映射、槽位互斥、段不得越 PT 上界）；
/// - **PD[2] 恒等镜像不可拆位**：除兼容槽 PT[0]（既有先例豁免）外，
///   禁止任何 PD[2] 落点；
/// - entry 必须落于某 X 段 [vaddr, vaddr+mem_len) 内；
/// - stack_top ∈ {0（遗留栈：PT[2] 单帧，rsp=0x403000）,
///   [`STACK_TOP_GROW`]（增长栈：PD6[1]→pt_stack，顶帧预映射，
///   其余窗口页由 #PF 扩栈补帧）}。
///
/// 映射纪律：中间层逐层补 U 位（权限逐层 AND）；帧内容经
/// `ostd::hw::phys` 直写（文件部分拷贝、mem_len 尾部保持清零）。
/// 失败路径：已分配帧按 v0 存续期语义不回收（与 build_space_frames
/// 同款，如实记档）。
pub fn build_user_space_lxe<F>(
    blob: &[u8],
    alloc_frame: &mut F,
) -> Result<ExecSpace, UserSpaceError>
where
    F: FnMut() -> Option<u64>,
{
    use bedrock::exec::{parse, FLAG_W, FLAG_X};
    let img = parse(blob).map_err(|_| UserSpaceError::BadImage)?;
    if img.stack_top != 0 && img.stack_top != STACK_TOP_GROW {
        return Err(UserSpaceError::BadImage);
    }
    // 段表策略预检：落点域 + 槽位互斥 + entry 落段
    let mut slots = [false; 512];
    let mut entry_ok = false;
    for seg in img.segments.iter().take(img.seg_count) {
        let is_compat = seg.vaddr == USER_CODE_VIRT;
        let in_fresh = seg.vaddr >= FRESH_BASE && seg.vaddr < FRESH_LIMIT;
        if !is_compat && !in_fresh {
            return Err(UserSpaceError::BadImage);
        }
        if is_compat {
            // 兼容槽：RX 单帧（代码只读；W 位拒绝；mem_len ≤ 一页）
            if seg.flags & FLAG_W != 0 || seg.mem_len > FRAME_SIZE {
                return Err(UserSpaceError::BadImage);
            }
        } else {
            let end = seg.vaddr + seg.mem_len;
            if end > FRESH_LIMIT {
                return Err(UserSpaceError::BadImage);
            }
            for k in 0..seg.mem_len.div_ceil(FRAME_SIZE) {
                let slot = ((seg.vaddr - FRESH_BASE) / FRAME_SIZE + k) as usize;
                if slots[slot] {
                    return Err(UserSpaceError::BadImage); // 槽位重叠
                }
                slots[slot] = true;
            }
        }
        if seg.flags & FLAG_X != 0 && img.entry >= seg.vaddr && img.entry < seg.vaddr + seg.mem_len
        {
            entry_ok = true;
        }
    }
    if !entry_ok {
        return Err(UserSpaceError::BadImage);
    }
    // 4 表骨架（PD[2] 恒等镜像纪律同 build_space_tables）
    let (root, pdpt, _pd, pt) = build_space_tables(alloc_frame)?;
    let mut seg_frames: Vec<(u64, u64)> = Vec::new();
    let mut data_frame = 0u64;
    // PDPT[6] 分支帧（惰性建支）：pd6[0] → 段区 PT、pd6[1] → 增长栈 PT
    let mut pd6 = 0u64;
    let mut pt_seg = 0u64;
    for i in 0..img.seg_count {
        let seg = img.segments[i];
        let is_compat = seg.vaddr == USER_CODE_VIRT;
        let bytes = img.seg_bytes(i);
        if is_compat {
            let Some(code) = alloc_frame() else {
                return Err(UserSpaceError::FramesExhausted);
            };
            ostd::hw::phys::write_zero(code, FRAME_SIZE);
            ostd::hw::phys::write_bytes(code, bytes);
            ostd::hw::phys::write_u64(pt, Entry::page(code, Entry::USER).bits());
            seg_frames.push((seg.vaddr, code));
        } else {
            if pd6 == 0 {
                // 首个新分支段触发建支：PDPT[6]→pd6→段区 PT（逐层补 U）
                let Some(p) = alloc_frame() else {
                    return Err(UserSpaceError::FramesExhausted);
                };
                ostd::hw::phys::write_zero(p, FRAME_SIZE);
                let Some(s) = alloc_frame() else {
                    return Err(UserSpaceError::FramesExhausted);
                };
                ostd::hw::phys::write_zero(s, FRAME_SIZE);
                let slot6 = (FRESH_BASE >> 30) & 0x1FF;
                ostd::hw::phys::write_u64(pdpt + slot6 * 8, Entry::table(p).bits() | Entry::USER);
                ostd::hw::phys::write_u64(p, Entry::table(s).bits() | Entry::USER);
                pd6 = p;
                pt_seg = s;
            }
            let frames_n = seg.mem_len.div_ceil(FRAME_SIZE);
            for k in 0..frames_n {
                let Some(f) = alloc_frame() else {
                    return Err(UserSpaceError::FramesExhausted);
                };
                ostd::hw::phys::write_zero(f, FRAME_SIZE);
                let start = (k * FRAME_SIZE) as usize;
                let end = (start + FRAME_SIZE as usize).min(bytes.len());
                if start < end {
                    ostd::hw::phys::write_bytes(f, &bytes[start..end]);
                }
                let flags = if seg.flags & FLAG_W != 0 {
                    Entry::USER | Entry::WRITABLE
                } else {
                    Entry::USER
                };
                let slot = ((seg.vaddr - FRESH_BASE) / FRAME_SIZE + k) as usize;
                ostd::hw::phys::write_u64(pt_seg + slot as u64 * 8, Entry::page(f, flags).bits());
                if k == 0 {
                    seg_frames.push((seg.vaddr, f));
                    if seg.flags & FLAG_W != 0 && data_frame == 0 {
                        data_frame = f;
                    }
                }
            }
        }
    }
    // 栈：遗留（PT[2] 单帧）或增长（pd6[1] → pt_stack，顶帧预映射）
    let stack_top = if img.stack_top == 0 {
        let Some(stack) = alloc_frame() else {
            return Err(UserSpaceError::FramesExhausted);
        };
        ostd::hw::phys::write_zero(stack, FRAME_SIZE);
        ostd::hw::phys::write_u64(
            pt + 2 * 8,
            Entry::page(stack, Entry::USER | Entry::WRITABLE).bits(),
        );
        USER_STACK_TOP
    } else {
        if pd6 == 0 {
            // 无段区但需增长栈：仅建 pd6（pd6[0] 留空，段区无人映射）
            let Some(p) = alloc_frame() else {
                return Err(UserSpaceError::FramesExhausted);
            };
            ostd::hw::phys::write_zero(p, FRAME_SIZE);
            let slot6 = (FRESH_BASE >> 30) & 0x1FF;
            ostd::hw::phys::write_u64(pdpt + slot6 * 8, Entry::table(p).bits() | Entry::USER);
            pd6 = p;
        }
        let Some(s) = alloc_frame() else {
            return Err(UserSpaceError::FramesExhausted);
        };
        ostd::hw::phys::write_zero(s, FRAME_SIZE);
        ostd::hw::phys::write_u64(pd6 + 8, Entry::table(s).bits() | Entry::USER); // pd6[1]
        let Some(stack) = alloc_frame() else {
            return Err(UserSpaceError::FramesExhausted);
        };
        ostd::hw::phys::write_zero(stack, FRAME_SIZE);
        ostd::hw::phys::write_u64(
            s + 511 * 8,
            Entry::page(stack, Entry::USER | Entry::WRITABLE).bits(),
        );
        STACK_TOP_GROW
    };
    Ok(ExecSpace {
        root,
        entry: img.entry,
        stack_top,
        rsp: 0,
        seg_frames,
        data_frame,
    })
}

/// ELF64 静态映像装载（M33-E1）：Linux 兼容路径（bedrock::elf）。
///
/// 放置域（M33-T1 修订：Alpine 官方介质原生基址直载口径）：
/// - 段 vaddr ∈ [[`ELF_USER_BASE`], [`ELF_USER_LIMIT`))（PML4[0]→
///   PDPT[0]→PD[2]→PT 槽域——linker.ld「程序基址 0x400000 硬编码」
///   契约窗口：Alpine busybox 静态 ET_EXEC 原生基址 0x400000 直载，
///   不重基址、不重编——ET_EXEC 绝对地址烧死无 RELA 可迁，重基址
///   仅源码重编可达，与「官方介质」制备契约相斥，T1 裁决改挂）；
///   **恒等槽让渡注**：域内槽装载时覆盖恒等镜像——内核借根窗口对
///   phys 0x400000..0x500000 段的借读在 busybox 驻存期让渡（swap/reap
///   借根面单任务口径挂账如实记档；内核堆 @0x600000 起不受累）；
/// - entry 必须落于某 X 段；
/// - 栈 = 增长栈域（PD6[1]→pt_stack，顶帧预映射）；
/// - **Linux 初始栈**（argc/argv/envp/auxv）构造于栈顶帧
///   （bedrock::elf::build_initial_stack 顶帧镜像缓冲一次落帧），
///   rsp 经 [`ExecSpace::rsp`] 下发（消费面 sys_exec）。
///
/// 映射纪律：W 段 USER|WRITABLE、其余 USER（none 目标 NX 未启用，
/// RO/RX 同型——v0 口径如实记档）；帧内容经 `ostd::hw::phys` 直写
/// （file 部分拷贝、mem_len 尾部保持清零——bss 语义）。装载完成后
/// 域内段间空洞显式清零（P=0）——恒等镜像残留清除，用户态触达空洞
/// = 干净 not-present #PF（fail-visible，非内核恒等借读错域）。
/// 失败路径：已分配帧按 v0 存续期语义不回收（LXE1 同款如实记档）。
#[allow(clippy::too_many_arguments)]
pub fn build_user_space_elf<F>(
    blob: &[u8],
    argv: &[&str],
    envp: &[&str],
    random: [u8; 16],
    exec_fn: &str,
    alloc_frame: &mut F,
) -> Result<ExecSpace, UserSpaceError>
where
    F: FnMut() -> Option<u64>,
{
    use bedrock::elf::{build_initial_stack, parse, AuxSys, PF_W, PF_X};
    let img = parse(blob).map_err(|_| UserSpaceError::BadImage)?;
    // 放置域预检：PD[2] 槽域 + 页槽互斥 + entry 落 X 段（页域式——
    // 非对齐 vaddr 的首/尾部分页计入页账，与装载循环同口径）
    let mut slots = [false; 512];
    let mut entry_ok = false;
    for seg in img.loads.iter().take(img.load_count) {
        let end = seg.vaddr + seg.mem_len;
        if seg.vaddr < ELF_USER_BASE || end > ELF_USER_LIMIT {
            return Err(UserSpaceError::BadImage);
        }
        let lo_page = seg.vaddr / FRAME_SIZE;
        let pages_n = end.div_ceil(FRAME_SIZE) - lo_page;
        for q in 0..pages_n {
            let slot = (lo_page + q - ELF_USER_BASE / FRAME_SIZE) as usize;
            if slots[slot] {
                return Err(UserSpaceError::BadImage);
            }
            slots[slot] = true;
        }
        if seg.flags & PF_X != 0 && img.entry >= seg.vaddr && img.entry < end {
            entry_ok = true;
        }
    }
    if !entry_ok {
        return Err(UserSpaceError::BadImage);
    }
    // 4 表骨架 + PD6 栈支（ELF 段区 = PD[2] PT 槽域 = 骨架第 4 表 `pt`；
    // 栈区 = PD6[1] 增长栈。PD6[0] 段支 LXE1 链专用，ELF 链不分配）
    let (root, pdpt, _pd, pt) = build_space_tables(alloc_frame)?;
    let Some(pd6) = alloc_frame() else {
        return Err(UserSpaceError::FramesExhausted);
    };
    ostd::hw::phys::write_zero(pd6, FRAME_SIZE);
    let Some(pt_stack) = alloc_frame() else {
        return Err(UserSpaceError::FramesExhausted);
    };
    ostd::hw::phys::write_zero(pt_stack, FRAME_SIZE);
    let slot6 = (STACK_TOP_GROW >> 30) & 0x1FF;
    ostd::hw::phys::write_u64(pdpt + slot6 * 8, Entry::table(pd6).bits() | Entry::USER);
    ostd::hw::phys::write_u64(pd6 + 8, Entry::table(pt_stack).bits() | Entry::USER); // pd6[1]
                                                                                     // 逐段逐页装载（file 拷贝 + bss 清零零帧；PD[2] 槽域覆盖恒等镜像）。
                                                                                     // 页域交拷贝算法（M33-T1：Alpine 官方介质尾段 vaddr 页内余
                                                                                     // ≠ 0 是 ld 常规布局，p_offset ≡ p_vaddr mod PAGE 同余式保
                                                                                     // file 偏移与 VA 页内余一致——首页空腔/尾页 bss 域由帧清零
                                                                                     // 先行承担，file 交区间帧内偏移直写）。
    let mut seg_frames: Vec<(u64, u64)> = Vec::new();
    let mut data_frame = 0u64;
    for i in 0..img.load_count {
        let seg = img.loads[i];
        let bytes = img.seg_bytes(i);
        let lo_page = seg.vaddr / FRAME_SIZE;
        let pages_n = (seg.vaddr + seg.mem_len).div_ceil(FRAME_SIZE) - lo_page;
        for k in 0..pages_n {
            let page_va = (lo_page + k) * FRAME_SIZE;
            let Some(f) = alloc_frame() else {
                return Err(UserSpaceError::FramesExhausted);
            };
            ostd::hw::phys::write_zero(f, FRAME_SIZE);
            // 页 ∩ file 数据区间（VA 域 [vaddr, vaddr+file_len)）
            let lo = page_va.max(seg.vaddr);
            let hi = (page_va + FRAME_SIZE).min(seg.vaddr + seg.file_len);
            if lo < hi {
                let src = (lo - seg.vaddr) as usize;
                let n = (hi - lo) as usize;
                let dst_phys = f + (lo - page_va); // 帧基 + 页内偏移（phys 直写）
                ostd::hw::phys::write_bytes(dst_phys, &bytes[src..src + n]);
            }
            let flags = if seg.flags & PF_W != 0 {
                Entry::USER | Entry::WRITABLE
            } else {
                Entry::USER
            };
            let slot = (lo_page + k - ELF_USER_BASE / FRAME_SIZE) as usize;
            ostd::hw::phys::write_u64(pt + slot as u64 * 8, Entry::page(f, flags).bits());
            if k == 0 {
                seg_frames.push((seg.vaddr, f));
                if seg.flags & PF_W != 0 && data_frame == 0 {
                    data_frame = f;
                }
            }
        }
    }
    // 段间空洞显式清零（P=0）：域内预检覆盖范围 [min,max) 未命中槽——
    // 恒等镜像残留清除面（本装载的 slots 数组即覆盖账本）
    let lo = slots.iter().position(|&s| s).unwrap_or(0);
    let hi = slots.iter().rposition(|&s| s).unwrap_or(0);
    for (i, s) in slots.iter().enumerate().take(hi + 1).skip(lo) {
        if !s {
            ostd::hw::phys::write_u64(pt + i as u64 * 8, 0);
        }
    }
    // 增长栈顶帧预映射（LXE1 增长栈同款）
    let Some(stack) = alloc_frame() else {
        return Err(UserSpaceError::FramesExhausted);
    };
    ostd::hw::phys::write_zero(stack, FRAME_SIZE);
    ostd::hw::phys::write_u64(
        pt_stack + 511 * 8,
        Entry::page(stack, Entry::USER | Entry::WRITABLE).bits(),
    );
    // Linux 初始栈：顶帧镜像缓冲构造 → 一次落帧；AT_PHDR = 映像基 + phoff
    let img_base = img.loads[..img.load_count]
        .iter()
        .map(|s| s.vaddr)
        .min()
        .unwrap_or(FRESH_BASE);
    let aux = AuxSys {
        pagesz: FRAME_SIZE,
        entry: img.entry,
        phdr: img_base + img.phoff,
        phent: bedrock::elf::PHDR_LEN as u64,
        phnum: img.phnum,
        clktck: 100,
        base: 0, // 静态域零 AT_BASE（动态车道归 build_user_space_elf_dynamic）
    };
    let region_base = STACK_TOP_GROW - FRAME_SIZE;
    let mut region = alloc::vec![0u8; FRAME_SIZE as usize];
    let region_top = region.len();
    let rsp = build_initial_stack(
        &mut region,
        region_base,
        region_top,
        argv,
        envp,
        &random,
        exec_fn,
        &aux,
    )
    .map_err(|_| UserSpaceError::BadImage)?;
    ostd::hw::phys::write_bytes(stack, &region);
    Ok(ExecSpace {
        root,
        entry: img.entry,
        stack_top: STACK_TOP_GROW,
        rsp,
        seg_frames,
        data_frame,
    })
}

/// 动态映像装载（M50-MUSLRUN72 笔82）：ET_DYN 程序 + ET_DYN 解释器
/// 双真件页域装载 + 解释器域初始栈——真实 musl 动态链的内核侧唯一
/// 职责面（重定位/符号决议/init 序全部归解释器本体机器码在 ring3
/// 自行执行，内核零代劳——bedrock::elf 模块口径注同源）。
///
/// 布局（busybox-dynamic 1.36.1 + ld-musl-x86_64.so.1 官方媒体实测
/// 口径——双件结构探针锚：程序 4 PT_LOAD 跨 198 页 / PT_PHDR@0x40
/// 含在首段 / PT_INTERP = "/lib/ld-musl-x86_64.so.1" / DT_NEEDED =
/// libc.musl-x86_64.so.1 = ld-musl 自身 SONAME（自解域零文件访问）；
/// 解释器 4 PT_LOAD 跨 161 页 / 自重定位 15 项 / 无 PT_TLS）：
/// - 程序 = [`ELF_USER_BASE`]..[`ELF_USER_LIMIT`]（PD[2] 2 MiB——
///   PIE vaddr 重基址 +ELF_USER_BASE，静态链同域先例）；
/// - 解释器 = [`DYN_INTERP_BASE`]..[`DYN_INTERP_LIMIT`]（PD6[2] 槽）；
/// - 栈 = [`STACK_TOP_GROW`]（PD6[1]，静态链同款顶帧 + 初始栈）；
/// - auxv：AT_PHDR = 程序基 + phoff（musl 基式换算消费面）/ AT_BASE =
///   解释器基 / AT_ENTRY = 程序基 + e_entry / AT_EXECFN / AT_RANDOM
///   全谱（base 对动态域发射——静态链字节面零扰动回归锚 t82/t83）。
///
/// 入口 RIP = 解释器基 + 解释器 e_entry（musl _dlstart——Linux 同款
/// 语义：内核进解释器，解释器进程序）。
///
/// 闸序（fail-visible，先于任何帧分配零泄漏）：程序须 ET_DYN ∧
/// PT_INTERP 在场（静态 blob 误入动态车道即 BadImage 显形——t161
/// NEG1）；解释器须 ET_DYN ∧ 入口落 X 段；双件放置域预检（越界/
/// 页槽互斥/程序入口落 X 段）。
pub fn build_user_space_elf_dynamic<F>(
    prog: &[u8],
    interp: &[u8],
    argv: &[&str],
    envp: &[&str],
    random: [u8; 16],
    exec_fn: &str,
    alloc_frame: &mut F,
) -> Result<ExecSpace, UserSpaceError>
where
    F: FnMut() -> Option<u64>,
{
    use bedrock::elf::{build_initial_stack, parse, AuxSys, ET_DYN, PF_W, PF_X};
    // 结构解析 + 动态车道闸（ET_DYN ∧ PT_INTERP——静态 blob 拒收域）
    let img = parse(prog).map_err(|_| UserSpaceError::BadImage)?;
    if img.etype != ET_DYN || img.interp.is_none() {
        return Err(UserSpaceError::BadImage);
    }
    let idef = parse(interp).map_err(|_| UserSpaceError::BadImage)?;
    if idef.etype != ET_DYN {
        return Err(UserSpaceError::BadImage);
    }
    // 放置域预检（帧分配前——闸序零泄漏）：程序 PIE 重基址 +ELF_USER_BASE
    // 落 PD[2]；解释器重基址 +DYN_INTERP_BASE 落 PD6[2]；双域页槽互斥 +
    // entry 落 X 段（页域式——非对齐 vaddr 首/尾部分页计入页账）。
    let mut slots = [false; 512];
    let mut entry_ok = false;
    for seg in img.loads.iter().take(img.load_count) {
        let va = ELF_USER_BASE + seg.vaddr;
        let end = va + seg.mem_len;
        if va < ELF_USER_BASE || end > ELF_USER_LIMIT {
            return Err(UserSpaceError::BadImage);
        }
        let lo_page = va / FRAME_SIZE;
        let pages_n = end.div_ceil(FRAME_SIZE) - lo_page;
        for q in 0..pages_n {
            let slot = (lo_page + q - ELF_USER_BASE / FRAME_SIZE) as usize;
            if slots[slot] {
                return Err(UserSpaceError::BadImage);
            }
            slots[slot] = true;
        }
        let entry_va = ELF_USER_BASE + img.entry;
        if seg.flags & PF_X != 0 && entry_va >= va && entry_va < end {
            entry_ok = true;
        }
    }
    if !entry_ok {
        return Err(UserSpaceError::BadImage);
    }
    let mut islots = [false; 512];
    let mut ientry_ok = false;
    for seg in idef.loads.iter().take(idef.load_count) {
        let va = DYN_INTERP_BASE + seg.vaddr;
        let end = va + seg.mem_len;
        if va < DYN_INTERP_BASE || end > DYN_INTERP_LIMIT {
            return Err(UserSpaceError::BadImage);
        }
        let lo_page = va / FRAME_SIZE;
        let pages_n = end.div_ceil(FRAME_SIZE) - lo_page;
        for q in 0..pages_n {
            let slot = (lo_page + q - DYN_INTERP_BASE / FRAME_SIZE) as usize;
            if islots[slot] {
                return Err(UserSpaceError::BadImage);
            }
            islots[slot] = true;
        }
        let entry_va = DYN_INTERP_BASE + idef.entry;
        if seg.flags & PF_X != 0 && entry_va >= va && entry_va < end {
            ientry_ok = true;
        }
    }
    if !ientry_ok {
        return Err(UserSpaceError::BadImage);
    }
    // 4 表骨架 + PD6 栈支（静态链同款）+ PD6[2] 解释器支
    let (root, pdpt, _pd, pt) = build_space_tables(alloc_frame)?;
    let Some(pd6) = alloc_frame() else {
        return Err(UserSpaceError::FramesExhausted);
    };
    ostd::hw::phys::write_zero(pd6, FRAME_SIZE);
    let Some(pt_stack) = alloc_frame() else {
        return Err(UserSpaceError::FramesExhausted);
    };
    ostd::hw::phys::write_zero(pt_stack, FRAME_SIZE);
    let Some(pt_interp) = alloc_frame() else {
        return Err(UserSpaceError::FramesExhausted);
    };
    ostd::hw::phys::write_zero(pt_interp, FRAME_SIZE);
    let slot6 = (STACK_TOP_GROW >> 30) & 0x1FF;
    ostd::hw::phys::write_u64(pdpt + slot6 * 8, Entry::table(pd6).bits() | Entry::USER);
    ostd::hw::phys::write_u64(pd6 + 8, Entry::table(pt_stack).bits() | Entry::USER); // pd6[1]
    ostd::hw::phys::write_u64(pd6 + 16, Entry::table(pt_interp).bits() | Entry::USER); // pd6[2]
                                                                                       // 程序逐段逐页装载（页域交拷贝算法——静态链同款；file 拷贝 + bss
                                                                                       // 清零零帧；PD[2] 槽域重基址覆盖恒等镜像）。
    let mut seg_frames: Vec<(u64, u64)> = Vec::new();
    let mut data_frame = 0u64;
    for i in 0..img.load_count {
        let seg = img.loads[i];
        let bytes = img.seg_bytes(i);
        let lo_page = (ELF_USER_BASE + seg.vaddr) / FRAME_SIZE;
        let pages_n = (ELF_USER_BASE + seg.vaddr + seg.mem_len).div_ceil(FRAME_SIZE) - lo_page;
        for k in 0..pages_n {
            let page_va = (lo_page + k) * FRAME_SIZE;
            let Some(f) = alloc_frame() else {
                return Err(UserSpaceError::FramesExhausted);
            };
            ostd::hw::phys::write_zero(f, FRAME_SIZE);
            let seg_va = ELF_USER_BASE + seg.vaddr;
            let lo = page_va.max(seg_va);
            let hi = (page_va + FRAME_SIZE).min(seg_va + seg.file_len);
            if lo < hi {
                let src = (lo - seg_va) as usize;
                let n = (hi - lo) as usize;
                let dst_phys = f + (lo - page_va);
                ostd::hw::phys::write_bytes(dst_phys, &bytes[src..src + n]);
            }
            let flags = if seg.flags & PF_W != 0 {
                Entry::USER | Entry::WRITABLE
            } else {
                Entry::USER
            };
            let slot = (lo_page + k - ELF_USER_BASE / FRAME_SIZE) as usize;
            ostd::hw::phys::write_u64(pt + slot as u64 * 8, Entry::page(f, flags).bits());
            if k == 0 {
                seg_frames.push((seg_va, f));
                if seg.flags & PF_W != 0 && data_frame == 0 {
                    data_frame = f;
                }
            }
        }
    }
    // 程序段间空洞显式清零（P=0；slots 账本覆盖域内未命中槽——静态链同款）
    let lo = slots.iter().position(|&s| s).unwrap_or(0);
    let hi = slots.iter().rposition(|&s| s).unwrap_or(0);
    for (i, s) in slots.iter().enumerate().take(hi + 1).skip(lo) {
        if !s {
            ostd::hw::phys::write_u64(pt + i as u64 * 8, 0);
        }
    }
    // 解释器逐段逐页装载（PD6[2] 槽域重基址；W 段可写——musl 自重定位
    // 与 GOT 写面消费域；恒等镜像页表槽独立于内核借根分支零冲突）。
    for i in 0..idef.load_count {
        let seg = idef.loads[i];
        let bytes = idef.seg_bytes(i);
        let lo_page = (DYN_INTERP_BASE + seg.vaddr) / FRAME_SIZE;
        let pages_n = (DYN_INTERP_BASE + seg.vaddr + seg.mem_len).div_ceil(FRAME_SIZE) - lo_page;
        for k in 0..pages_n {
            let page_va = (lo_page + k) * FRAME_SIZE;
            let Some(f) = alloc_frame() else {
                return Err(UserSpaceError::FramesExhausted);
            };
            ostd::hw::phys::write_zero(f, FRAME_SIZE);
            let seg_va = DYN_INTERP_BASE + seg.vaddr;
            let lo = page_va.max(seg_va);
            let hi = (page_va + FRAME_SIZE).min(seg_va + seg.file_len);
            if lo < hi {
                let src = (lo - seg_va) as usize;
                let n = (hi - lo) as usize;
                let dst_phys = f + (lo - page_va);
                ostd::hw::phys::write_bytes(dst_phys, &bytes[src..src + n]);
            }
            let flags = if seg.flags & PF_W != 0 {
                Entry::USER | Entry::WRITABLE
            } else {
                Entry::USER
            };
            let slot = (lo_page + k - DYN_INTERP_BASE / FRAME_SIZE) as usize;
            ostd::hw::phys::write_u64(pt_interp + slot as u64 * 8, Entry::page(f, flags).bits());
        }
    }
    // 解释器段间空洞显式清零（islots 账本同款）
    let ilo = islots.iter().position(|&s| s).unwrap_or(0);
    let ihi = islots.iter().rposition(|&s| s).unwrap_or(0);
    for (i, s) in islots.iter().enumerate().take(ihi + 1).skip(ilo) {
        if !s {
            ostd::hw::phys::write_u64(pt_interp + i as u64 * 8, 0);
        }
    }
    // 增长栈顶帧预映射（静态链同款）
    let Some(stack) = alloc_frame() else {
        return Err(UserSpaceError::FramesExhausted);
    };
    ostd::hw::phys::write_zero(stack, FRAME_SIZE);
    ostd::hw::phys::write_u64(
        pt_stack + 511 * 8,
        Entry::page(stack, Entry::USER | Entry::WRITABLE).bits(),
    );
    // Linux 初始栈（动态域）：AT_PHDR = 程序基 + phoff / AT_BASE =
    // 解释器基 / AT_ENTRY = 程序基 + e_entry（musl 基式换算全谱）
    let aux = AuxSys {
        pagesz: FRAME_SIZE,
        entry: ELF_USER_BASE + img.entry,
        phdr: ELF_USER_BASE + img.phoff,
        phent: bedrock::elf::PHDR_LEN as u64,
        phnum: img.phnum,
        clktck: 100,
        base: DYN_INTERP_BASE,
    };
    let region_base = STACK_TOP_GROW - FRAME_SIZE;
    let mut region = alloc::vec![0u8; FRAME_SIZE as usize];
    let region_top = region.len();
    let rsp = build_initial_stack(
        &mut region,
        region_base,
        region_top,
        argv,
        envp,
        &random,
        exec_fn,
        &aux,
    )
    .map_err(|_| UserSpaceError::BadImage)?;
    ostd::hw::phys::write_bytes(stack, &region);
    Ok(ExecSpace {
        root,
        entry: DYN_INTERP_BASE + idef.entry,
        stack_top: STACK_TOP_GROW,
        rsp,
        seg_frames,
        data_frame,
    })
}

/// 构建用户页表骨架（M11-A 重构；M12-B 拆分：表主体与叶帧分离）。
/// 4 张中间表 + 内核分支克隆 + PD/PT 恒等镜像；PT[0]/PT[2] 留空由
/// 调用方填装（私有帧或 COW 共享映射）。
fn build_space_tables<F>(alloc_frame: &mut F) -> Result<(u64, u64, u64, u64), UserSpaceError>
where
    F: FnMut() -> Option<u64>,
{
    let Some(root) = alloc_frame() else {
        return Err(UserSpaceError::FramesExhausted);
    };
    let Some(pdpt) = alloc_frame() else {
        return Err(UserSpaceError::FramesExhausted);
    };
    let Some(pd) = alloc_frame() else {
        return Err(UserSpaceError::FramesExhausted);
    };
    let Some(pt) = alloc_frame() else {
        return Err(UserSpaceError::FramesExhausted);
    };
    for f in [root, pdpt, pd, pt] {
        ostd::hw::phys::write_zero(f, FRAME_SIZE);
    }
    // PML4[0] → PDPT → PD：中间层补 U 位——页访问权限逐层 AND，
    // 任一层缺 U，用户态叶页访问即被拒（e=5 保护违例，开发期实测）
    let user_table = Entry::USER;
    ostd::hw::phys::write_u64(root, Entry::table(pdpt).bits() | user_table);
    ostd::hw::phys::write_u64(pdpt, Entry::table(pd).bits() | user_table);
    // 克隆内核必需分支（恒等内核 + LAPIC MMIO，supervisor-only）：必须在
    // PML4[0] 已链接新 PDPT 之后调用，否则 LAPIC 槽位拷贝落空（M6 实测）。
    ostd::mm::page::clone_kernel_branches(ostd::hw::control::read_cr3(), root);
    // PD[0..512]：2 MiB 恒等大页（P|W，supervisor），PD[2] 展开为 PT
    for i in 0..512u64 {
        let slot = pd + i * 8;
        if i == 2 {
            ostd::hw::phys::write_u64(slot, Entry::table(pt).bits() | user_table);
        } else {
            ostd::hw::phys::write_u64(slot, Entry::huge(i * 0x20_0000, Entry::WRITABLE).bits());
        }
    }
    // PT 全量镜像 PD[2] 覆盖的 2 MiB 恒等区（内核映像/堆跨界，缺页即
    // 三重故障）；PT[0]/PT[2] 留空——用户代码/栈槽由调用方填装。
    for j in 0..512u64 {
        if j == 0 || j == 2 {
            continue;
        }
        let phys = 0x40_0000 + j * FRAME_SIZE;
        ostd::hw::phys::write_u64(pt + j * 8, Entry::page(phys, Entry::WRITABLE).bits());
    }
    Ok((root, pdpt, pd, pt))
}

/// 构建用户页表骨架 + 私有代码/栈帧（M12-B 拆分后：表主体经
/// [`build_space_tables`]，叶帧在此分配填装）。不装载程序映像。
fn build_space_frames<F>(alloc_frame: &mut F) -> Result<CloneSpace, UserSpaceError>
where
    F: FnMut() -> Option<u64>,
{
    let (root, pdpt, pd, pt) = build_space_tables(alloc_frame)?;
    let Some(code) = alloc_frame() else {
        return Err(UserSpaceError::FramesExhausted);
    };
    let Some(stack) = alloc_frame() else {
        return Err(UserSpaceError::FramesExhausted);
    };
    ostd::hw::phys::write_zero(code, FRAME_SIZE);
    ostd::hw::phys::write_zero(stack, FRAME_SIZE);
    ostd::hw::phys::write_u64(pt, Entry::page(code, Entry::USER).bits());
    ostd::hw::phys::write_u64(
        pt + 2 * 8,
        Entry::page(stack, Entry::USER | Entry::WRITABLE).bits(),
    );
    Ok(CloneSpace {
        root,
        pdpt,
        pd,
        pt,
        code_frame: code,
        stack_frame: stack,
    })
}

/// 程序级翻译（自检用）：经 IdentityAccess 走表验证映射生效。
pub fn translate(root: u64, virt: u64) -> Option<u64> {
    let w = ostd::mm::page::Walker {
        mem: &mut ostd::mm::page::IdentityAccess,
        alloc_table: || None,
    };
    w.translate(root, virt)
}

// ---------------------------------------------------------------------------
// M11-A：SYS_SPAWN 子地址空间克隆（ring3 自主派生的内核登记面）
// ---------------------------------------------------------------------------

/// 克隆子空间全帧记录（失败路径全量归还用；与 [`UserSpace`] 的差别
/// 在于补齐三张中间表帧）。
pub struct CloneSpace {
    /// 用户页表根物理地址。
    pub root: u64,
    /// PML4 下 PDPT 帧物理地址。
    pub pdpt: u64,
    /// PD 帧物理地址。
    pub pd: u64,
    /// PT 帧物理地址。
    pub pt: u64,
    /// 用户代码帧物理地址（父代码帧克隆）。
    pub code_frame: u64,
    /// 用户栈帧物理地址（清零 + 遗传细胞）。
    pub stack_frame: u64,
}

/// 克隆子空间（M12-B COW 派生）：全新 4 表骨架 + **零拷贝共享父帧**。
///
/// 与 v0.11 逐字节克隆的差别（克隆成本 O(1) 化）：
/// - **代码帧共享**：子 PT[0] 直映父代码帧物理地址（本就 P|U 只读，
///   零降级零拷贝）；
/// - **栈帧共享 + COW**：子 PT[2] 映射父栈帧，P|U 去 W + COW 标记位
///   （PTE avail bit 9）；**父侧同步降级**（去 W + COW 位）+ invlpg
///   （父任务运行于本核，无跨核击落需求）；任一侧首次写触发 #PF →
///   [`crate::vmm`] 的 COW 分支私拷回写。
/// - 遗传细胞：寄存器协议（r14 ← 父 pid，派发面注入）——共享栈帧
///   不可物理直写，内存细胞随 COW 退役。
///
/// `alloc_frame` 为帧分配器闭包。返回 [`CloneSpace`] 全 6 帧记录
/// （code_frame/stack_frame = 父侧共享帧地址——取证面 t37 v2 对证
/// 代码帧物理同一性；失败路径全量归还新建帧，共享帧不归还）。
pub fn clone_user_space_cow<F>(
    parent_root: u64,
    alloc_frame: &mut F,
) -> Result<CloneSpace, UserSpaceError>
where
    F: FnMut() -> Option<u64>,
{
    // 4 表骨架（无叶帧分配——COW 零拷贝的关键：不产生孤儿帧）
    let (root, pdpt, pd, pt) = build_space_tables(alloc_frame)?;
    let Some(parent_code) = translate(parent_root, USER_CODE_VIRT) else {
        return Err(UserSpaceError::FramesExhausted); // 父代码帧不可达 = 空间残缺
    };
    let Some(parent_stack) = translate(parent_root, USER_STACK_VIRT) else {
        return Err(UserSpaceError::FramesExhausted);
    };
    let Some(parent_pt) = parent_pt_of(parent_root) else {
        return Err(UserSpaceError::FramesExhausted);
    };
    // 子 PT：代码帧共享（P|U 只读）、栈帧 COW（P|U + COW 位，去 W）。
    // PT 帧物理直写（与 build_space_tables 同款恒等写纪律）。
    let cow_bit: u64 = 1 << 9; // PTE avail 位 9：COW 标记（vmm #PF 分支识别）
    ostd::hw::phys::write_u64(pt, Entry::page(parent_code, Entry::USER).bits());
    ostd::hw::phys::write_u64(
        pt + 2 * 8,
        (Entry::page(parent_stack, Entry::USER).bits() & !Entry::WRITABLE) | cow_bit,
    );
    // 父侧栈降级：PT[2] 去 W + COW 位（共享语义对父同步生效）+ invlpg
    // （父任务运行于调用核，无跨核击落需求）。
    let old = ostd::hw::phys::read_u64(parent_pt + 2 * 8);
    ostd::hw::phys::write_u64(parent_pt + 2 * 8, (old & !Entry::WRITABLE) | cow_bit);
    ostd::hw::control::invlpg(USER_STACK_VIRT);
    Ok(CloneSpace {
        root,
        pdpt,
        pd,
        pt,
        code_frame: parent_code,
        stack_frame: parent_stack,
    })
}

/// 父侧栈降级回滚（spawn 后续步骤失败时恢复原 PTE，父侧零残留）。
pub fn rollback_cow_demote(parent_root: u64) {
    if let Some(parent_pt) = parent_pt_of(parent_root) {
        let cur = ostd::hw::phys::read_u64(parent_pt + 2 * 8);
        ostd::hw::phys::write_u64(parent_pt + 2 * 8, (cur & !(1 << 9)) | Entry::WRITABLE);
        ostd::hw::control::invlpg(USER_STACK_VIRT);
    }
}

/// 父根的用户 PT 基址（M12-B COW 降级定位；布局由 build_space_frames
/// 定约：PML4[0]→PDPT[0]→PD[2]→PT）。
fn parent_pt_of(root: u64) -> Option<u64> {
    let pml4e = ostd::hw::phys::read_u64(root) & Entry::ADDR_MASK;
    if pml4e == 0 {
        return None;
    }
    let pdpte = ostd::hw::phys::read_u64(pml4e) & Entry::ADDR_MASK;
    if pdpte == 0 {
        return None;
    }
    let pde = ostd::hw::phys::read_u64(pdpte + 2 * 8) & Entry::ADDR_MASK;
    if pde == 0 {
        return None;
    }
    Some(pde)
}

// ---------------------------------------------------------------------------
// M11：进程创建 / 句柄查询枚举 / IPC 阻塞接收测试面（ring3 程序）
// 生成：scripts/asm_m11.py（两遍微型汇编器，rel8 溢出自动升级 rel32；
// objdump 逐条反汇编收口，见 lumina-build/logs/asm_m11/）
// ---------------------------------------------------------------------------

/// SPAWN 程序 v2（t37；位置固定 0x400000；M12-B COW 全协议）：
///
/// ```text
/// r14 = 父 pid（trampoline 注入；根父恒 0——寄存器细胞协议）
/// 子分支（r14 != 0）：
///   GET_PID → r14 == 自 pid 即 EXIT(75)（细胞协议自证失败）
///   写 [0x402000] ← 0x5A5A（子侧 COW 缺页 → 私拷）→ 回读校验，
///     不符 EXIT(76)
///   YIELD×8 → EXIT(42)
/// 父分支（r14 == 0）：
///   SPAWN(0) → 成功位校验 → WAIT_PID(cpid) → 拆位校验
///   （成功位 / cpid 域 / 码 == 42）
///   写 [0x402008] ← 0xA5A5（父侧 COW 缺页 → 私拷）→ 回读校验
///   → EXIT(61)
/// 分级失败码：70 SPAWN 成功位 / 71 WAIT 成功位 / 72 cpid 域 /
/// 73 码域 / 75 细胞自证 / 76 子 COW 回读 / 77 父 COW 回读
/// ```
pub const USER_SPAWN_PROGRAM: [u8; 331] = [
    0x4D, 0x85, 0xF6, 0x74, 0x4E, 0xB8, 0x0B, 0x00, 0x00, 0x00, 0x0F, 0x05, 0x4C, 0x39, 0xF0, 0x0F,
    0x84, 0xD4, 0x00, 0x00, 0x00, 0x48, 0xC7, 0xC0, 0x5A, 0x5A, 0x00, 0x00, 0x48, 0x89, 0x04, 0x25,
    0x00, 0x20, 0x40, 0x00, 0x48, 0x8B, 0x0C, 0x25, 0x00, 0x20, 0x40, 0x00, 0x48, 0x39, 0xC1, 0x0F,
    0x85, 0xC2, 0x00, 0x00, 0x00, 0xBB, 0x08, 0x00, 0x00, 0x00, 0xB8, 0x02, 0x00, 0x00, 0x00, 0x0F,
    0x05, 0xFF, 0xCB, 0x75, 0xF5, 0xBF, 0x2A, 0x00, 0x00, 0x00, 0xB8, 0x01, 0x00, 0x00, 0x00, 0x0F,
    0x05, 0xEB, 0xFE, 0x48, 0x31, 0xFF, 0xB8, 0x0D, 0x00, 0x00, 0x00, 0x0F, 0x05, 0x49, 0x89, 0xC5,
    0x4C, 0x89, 0xE8, 0x48, 0xC1, 0xE8, 0x20, 0x48, 0x83, 0xF8, 0x01, 0x0F, 0x85, 0x94, 0x00, 0x00,
    0x00, 0x4C, 0x89, 0xE8, 0x8B, 0xC0, 0x49, 0x89, 0xC5, 0x48, 0x85, 0xC0, 0x0F, 0x84, 0x9F, 0x00,
    0x00, 0x00, 0x48, 0x89, 0xC7, 0xB8, 0x0C, 0x00, 0x00, 0x00, 0x0F, 0x05, 0x49, 0x89, 0xC4, 0x4C,
    0x89, 0xE0, 0x48, 0xC1, 0xE8, 0x20, 0x48, 0x83, 0xF8, 0x01, 0x75, 0x77, 0x4C, 0x89, 0xE0, 0x48,
    0xC1, 0xE8, 0x10, 0x48, 0x81, 0xE0, 0xFF, 0xFF, 0x00, 0x00, 0x4C, 0x39, 0xE8, 0x75, 0x72, 0x4C,
    0x89, 0xE0, 0x48, 0x81, 0xE0, 0xFF, 0xFF, 0x00, 0x00, 0x48, 0x83, 0xF8, 0x2A, 0x75, 0x70, 0x48,
    0xC7, 0xC0, 0xA5, 0xA5, 0x00, 0x00, 0x48, 0x89, 0x04, 0x25, 0x08, 0x20, 0x40, 0x00, 0x48, 0x8B,
    0x0C, 0x25, 0x08, 0x20, 0x40, 0x00, 0x48, 0x39, 0xC1, 0x75, 0x62, 0xBF, 0x3D, 0x00, 0x00, 0x00,
    0xB8, 0x01, 0x00, 0x00, 0x00, 0x0F, 0x05, 0xEB, 0xFE, 0xBF, 0x4B, 0x00, 0x00, 0x00, 0xB8, 0x01,
    0x00, 0x00, 0x00, 0x0F, 0x05, 0xEB, 0xFE, 0xBF, 0x4C, 0x00, 0x00, 0x00, 0xB8, 0x01, 0x00, 0x00,
    0x00, 0x0F, 0x05, 0xEB, 0xFE, 0xBF, 0x46, 0x00, 0x00, 0x00, 0xB8, 0x01, 0x00, 0x00, 0x00, 0x0F,
    0x05, 0xEB, 0xFE, 0xBF, 0x47, 0x00, 0x00, 0x00, 0xB8, 0x01, 0x00, 0x00, 0x00, 0x0F, 0x05, 0xEB,
    0xFE, 0xBF, 0x48, 0x00, 0x00, 0x00, 0xB8, 0x01, 0x00, 0x00, 0x00, 0x0F, 0x05, 0xEB, 0xFE, 0xBF,
    0x49, 0x00, 0x00, 0x00, 0xB8, 0x01, 0x00, 0x00, 0x00, 0x0F, 0x05, 0xEB, 0xFE, 0xBF, 0x4D, 0x00,
    0x00, 0x00, 0xB8, 0x01, 0x00, 0x00, 0x00, 0x0F, 0x05, 0xEB, 0xFE,
];

/// 句柄查询/枚举程序（t38；位置固定 0x400000，共 301 字节）：
///
/// ```text
/// QUERY(1) → 成功位 + rights==R|W（主身份，内核预装）
/// QUERY(0) / QUERY(9) → ERR_HANDLE(5)（NULL / 越界负探针）
/// ENUM(0) → 首句柄 1 + rights==3；ENUM(1) → 句柄 2 + rights==READ
/// （内核预装派生句柄）；ENUM(2) → 0（枚举尽）；QUERY(2) → rights==1
/// EXIT(68) 成功 / EXIT(69) 失败
/// ```
/// 句柄查询/枚举程序（t38；位置固定 0x400000，共 314 字节）：
///
/// ```text
/// 轮询 [0x402108]（HQ_ARM_VA 武装哨兵）非零——内核装完句柄 2 后置位
/// （消除任务先于预装运行的竞态，t38 首跑实录记档）
/// QUERY(1) → 成功位 + rights==R|W（主身份，内核预装）
/// QUERY(0) / QUERY(9) → ERR_HANDLE(5)（NULL / 越界负探针）
/// ENUM(0) → 首句柄 1 + rights==R|W；ENUM(1) → 句柄 2 + rights==READ
/// （内核预装派生句柄）；ENUM(2) → 0（枚举尽）；QUERY(2) → rights==READ
/// EXIT(68) 成功 / EXIT(69) 失败
/// ```
#[allow(dead_code)] // 数组为 t38 唯一消费，构建期即达
pub const USER_HQ_PROGRAM: [u8; 525] = [
    0x4C, 0x8B, 0x3C, 0x25, 0x08, 0x21, 0x40, 0x00, 0x4D, 0x85, 0xFF, 0x74, 0xF3, 0xBF, 0x01, 0x00,
    0x00, 0x00, 0xB8, 0x0E, 0x00, 0x00, 0x00, 0x0F, 0x05, 0x49, 0x89, 0xC4, 0x4C, 0x89, 0xE0, 0x48,
    0xC1, 0xE8, 0x20, 0x48, 0x83, 0xF8, 0x01, 0x0F, 0x85, 0x29, 0x01, 0x00, 0x00, 0x4C, 0x89, 0xE0,
    0x48, 0xC1, 0xE8, 0x10, 0x25, 0xFF, 0xFF, 0x00, 0x00, 0x48, 0x83, 0xF8, 0x03, 0x0F, 0x85, 0x21,
    0x01, 0x00, 0x00, 0x31, 0xFF, 0xB8, 0x0E, 0x00, 0x00, 0x00, 0x0F, 0x05, 0x48, 0x83, 0xF8, 0x05,
    0x0F, 0x85, 0x2B, 0x01, 0x00, 0x00, 0xBF, 0x09, 0x00, 0x00, 0x00, 0xB8, 0x0E, 0x00, 0x00, 0x00,
    0x0F, 0x05, 0x48, 0x83, 0xF8, 0x05, 0x0F, 0x85, 0x23, 0x01, 0x00, 0x00, 0x31, 0xFF, 0xB8, 0x0F,
    0x00, 0x00, 0x00, 0x0F, 0x05, 0x49, 0x89, 0xC4, 0x4C, 0x89, 0xE0, 0x48, 0xC1, 0xE8, 0x20, 0x48,
    0x83, 0xF8, 0x01, 0x0F, 0x85, 0x14, 0x01, 0x00, 0x00, 0x4C, 0x89, 0xE2, 0x48, 0xC1, 0xEA, 0x10,
    0x48, 0x81, 0xE2, 0xFF, 0xFF, 0x00, 0x00, 0x48, 0x83, 0xFA, 0x01, 0x0F, 0x85, 0x0A, 0x01, 0x00,
    0x00, 0x4C, 0x89, 0xE0, 0x25, 0xFF, 0xFF, 0x00, 0x00, 0x48, 0x83, 0xF8, 0x03, 0x0F, 0x85, 0x06,
    0x01, 0x00, 0x00, 0xBF, 0x01, 0x00, 0x00, 0x00, 0xB8, 0x0F, 0x00, 0x00, 0x00, 0x0F, 0x05, 0x49,
    0x89, 0xC4, 0x4C, 0x89, 0xE0, 0x48, 0xC1, 0xE8, 0x20, 0x48, 0x83, 0xF8, 0x01, 0x0F, 0x85, 0xE6,
    0x00, 0x00, 0x00, 0x4C, 0x89, 0xE2, 0x48, 0xC1, 0xEA, 0x10, 0x48, 0x81, 0xE2, 0xFF, 0xFF, 0x00,
    0x00, 0x48, 0x83, 0xFA, 0x02, 0x0F, 0x85, 0xDC, 0x00, 0x00, 0x00, 0x4C, 0x89, 0xE0, 0x25, 0xFF,
    0xFF, 0x00, 0x00, 0x48, 0x83, 0xF8, 0x01, 0x0F, 0x85, 0xD8, 0x00, 0x00, 0x00, 0xBF, 0x02, 0x00,
    0x00, 0x00, 0xB8, 0x0F, 0x00, 0x00, 0x00, 0x0F, 0x05, 0x48, 0x85, 0xC0, 0x0F, 0x85, 0xD1, 0x00,
    0x00, 0x00, 0xBF, 0x02, 0x00, 0x00, 0x00, 0xB8, 0x0E, 0x00, 0x00, 0x00, 0x0F, 0x05, 0x49, 0x89,
    0xC4, 0x4C, 0x89, 0xE0, 0x48, 0xC1, 0xE8, 0x20, 0x48, 0x83, 0xF8, 0x01, 0x0F, 0x85, 0xBF, 0x00,
    0x00, 0x00, 0x4C, 0x89, 0xE0, 0x48, 0xC1, 0xE8, 0x10, 0x25, 0xFF, 0xFF, 0x00, 0x00, 0x48, 0x83,
    0xF8, 0x01, 0x0F, 0x85, 0xB7, 0x00, 0x00, 0x00, 0xBF, 0x44, 0x00, 0x00, 0x00, 0xB8, 0x01, 0x00,
    0x00, 0x00, 0x0F, 0x05, 0xEB, 0xFE, 0xBF, 0x50, 0x00, 0x00, 0x00, 0xB8, 0x01, 0x00, 0x00, 0x00,
    0x0F, 0x05, 0xEB, 0xFE, 0xBF, 0x51, 0x00, 0x00, 0x00, 0xB8, 0x01, 0x00, 0x5C, 0x78, 0x30, 0x30,
    0x5C, 0x78, 0x30, 0x30, 0x0F, 0x5C, 0x78, 0x30, 0x35, 0x5C, 0x78, 0x45, 0x42, 0x5C, 0x78, 0x46,
    0x45, 0xBF, 0x52, 0x00, 0x00, 0x00, 0xB8, 0x01, 0x00, 0x00, 0x00, 0x0F, 0x05, 0xEB, 0xFE, 0xBF,
    0x53, 0x00, 0x00, 0x00, 0xB8, 0x01, 0x00, 0x00, 0x00, 0x0F, 0x05, 0xEB, 0xFE, 0xBF, 0x54, 0x00,
    0x00, 0x00, 0xB8, 0x01, 0x00, 0x00, 0x00, 0x0F, 0x05, 0xEB, 0xFE, 0xBF, 0x55, 0x00, 0x00, 0x00,
    0xB8, 0x01, 0x00, 0x00, 0x00, 0x0F, 0x05, 0xEB, 0xFE, 0xBF, 0x56, 0x00, 0x00, 0x00, 0xB8, 0x01,
    0x00, 0x00, 0x00, 0x0F, 0x05, 0xEB, 0xFE, 0xBF, 0x57, 0x00, 0x00, 0x00, 0xB8, 0x01, 0x00, 0x00,
    0x00, 0x0F, 0x05, 0xEB, 0xFE, 0xBF, 0x58, 0x00, 0x00, 0x00, 0xB8, 0x01, 0x00, 0x00, 0x00, 0x0F,
    0x05, 0xEB, 0xFE, 0xBF, 0x59, 0x00, 0x00, 0x00, 0xB8, 0x01, 0x00, 0x00, 0x00, 0x0F, 0x05, 0xEB,
    0xFE, 0xBF, 0x5A, 0x00, 0x00, 0x00, 0xB8, 0x01, 0x00, 0x00, 0x00, 0x0F, 0x05, 0xEB, 0xFE, 0xBF,
    0x5B, 0x00, 0x00, 0x00, 0xB8, 0x01, 0x00, 0x00, 0x00, 0x0F, 0x05, 0xEB, 0xFE,
];
/// 阻塞接收程序（t39 接收方 R；位置固定 0x400000）。M12-A 句柄寻址版：
///
/// ```text
/// RECV(h=0 NULL) → 必返回 ERR_CAP(1)（非阻塞负探针）
/// RECV(h=1 主身份=BLOCK 通道 RECV 能力) → 环空阻塞 → SEND 唤醒 →
///   (tag<<32)|len 拆位（len==4、tag==0x55）+ 载荷 [0x402E00] == "WAKE"
///   → EXIT(65)；任一不符 EXIT(66)
/// ```
#[allow(dead_code)] // S42/S43 接线（t38/t39）
pub const USER_BLOCKRECV_PROGRAM: [u8; 128] = [
    0xBF, 0x00, 0x00, 0x00, 0x00, 0xBE, 0x78, 0x00, 0x00, 0x00, 0xBA, 0x00, 0x2E, 0x40, 0x00, 0xB8,
    0x04, 0x00, 0x00, 0x00, 0x0F, 0x05, 0x48, 0x83, 0xF8, 0x01, 0x75, 0x56, 0xBF, 0x01, 0x00, 0x00,
    0x00, 0xBE, 0x78, 0x00, 0x00, 0x00, 0xBA, 0x00, 0x2E, 0x40, 0x00, 0xB8, 0x04, 0x00, 0x00, 0x00,
    0x0F, 0x05, 0x49, 0x89, 0xC4, 0x4C, 0x89, 0xE0, 0x48, 0x81, 0xE0, 0xFF, 0xFF, 0x00, 0x00, 0x48,
    0x83, 0xF8, 0x04, 0x75, 0x2D, 0x4C, 0x89, 0xE0, 0x48, 0xC1, 0xE8, 0x20, 0x48, 0x83, 0xF8, 0x55,
    0x75, 0x20, 0x48, 0x8B, 0x04, 0x25, 0x00, 0x2E, 0x40, 0x00, 0x48, 0xC7, 0xC1, 0x57, 0x41, 0x4B,
    0x45, 0x48, 0x39, 0xC8, 0x75, 0x0C, 0xBF, 0x41, 0x00, 0x00, 0x00, 0xB8, 0x01, 0x00, 0x00, 0x00,
    0x0F, 0x05, 0xBF, 0x42, 0x00, 0x00, 0x00, 0xB8, 0x01, 0x00, 0x00, 0x00, 0x0F, 0x05, 0xEB, 0xFE,
];
/// 阻塞发送程序（t39 发送方 S；位置固定 0x400000）。M12-A 句柄寻址版：
///
/// ```text
/// YIELD×4（让接收方先行阻塞）→ "WAKE" 写 [0x402F00] →
/// SEND(h=1 主身份=BLOCK 通道 SEND 能力, ptr, 4, tag=0x55) → 必 0
/// → EXIT(67)；失败 EXIT(46)
/// ```
#[allow(dead_code)] // S42/S43 接线（t38/t39）
pub const USER_BLOCKSEND_PROGRAM: [u8; 89] = [
    0xBB, 0x04, 0x00, 0x00, 0x00, 0xB8, 0x02, 0x00, 0x00, 0x00, 0x0F, 0x05, 0xFF, 0xCB, 0x75, 0xF5,
    0xB8, 0x57, 0x41, 0x4B, 0x45, 0xA3, 0x00, 0x2F, 0x40, 0x00, 0x00, 0x00, 0x00, 0x00, 0xBF, 0x01,
    0x00, 0x00, 0x00, 0xBE, 0x04, 0x00, 0x00, 0x00, 0xBA, 0x00, 0x2F, 0x40, 0x00, 0x41, 0xBA, 0x55,
    0x00, 0x00, 0x00, 0xB8, 0x03, 0x00, 0x00, 0x00, 0x0F, 0x05, 0x48, 0x85, 0xC0, 0x75, 0x0C, 0xBF,
    0x43, 0x00, 0x00, 0x00, 0xB8, 0x01, 0x00, 0x00, 0x00, 0x0F, 0x05, 0xBF, 0x2E, 0x00, 0x00, 0x00,
    0xB8, 0x01, 0x00, 0x00, 0x00, 0x0F, 0x05, 0xEB, 0xFE,
];

/// BIND-GRANT-ECHO 程序（t41；位置固定 0x400000，M12-A 通道运行时化）。
/// 单程序双角色——SYS_SPAWN 克隆父代码帧，父子同映像，凭 r14 遗传细胞
/// 分叉（trampoline 注入父 pid；根父恒 0）：
///
/// ```text
/// 父（r14==0）：
///   BIND(0) → 成功位 + 句柄非零（存 r15；句柄表首空闲位）
///   SPAWN(0) → 成功位 + cpid（存 r14）
///   GRANT(cpid, h, SEND|RECV) → 成功位（跨任务分发复用 M9 父进程面）
///   RECV(h, 0x402E00, 120) → 阻塞 → len==7 + tag==0x77 +
///     [0x402E00] == "BIND-OK" → WAIT_PID(cpid) → 码 81 → EXIT(82)
/// 子（r14!=0）：
///   YIELD×8（让父侧 GRANT 先行落位）
///   负探针：SEND(h=0 NULL, payload, 4, tag=0x77) → 必非零，为零 EXIT(80)
///   SEND(h=1 授予句柄, "BIND-OK"@0x402C00, 7, tag=0x77) → 必 0 → EXIT(81)
/// 分级失败码：80 子探针 / 84 BIND / 85 SPAWN / 86 GRANT / 87 RECV /
/// 88 WAIT / 89 子正发送
/// ```
pub const USER_BIND_PROGRAM: [u8; 479] = [
    0x4D, 0x85, 0xF6, 0x74, 0x75, 0xBB, 0x08, 0x00, 0x00, 0x00, 0xB8, 0x02, 0x00, 0x00, 0x00, 0x0F,
    0x05, 0xFF, 0xCB, 0x75, 0xF5, 0x48, 0x31, 0xFF, 0xBE, 0x04, 0x00, 0x00, 0x00, 0xBA, 0x00, 0x2F,
    0x40, 0x00, 0x41, 0xBA, 0x77, 0x00, 0x00, 0x00, 0xB8, 0x03, 0x00, 0x00, 0x00, 0x0F, 0x05, 0x48,
    0x85, 0xC0, 0x0F, 0x84, 0x45, 0x01, 0x00, 0x00, 0x48, 0xC7, 0xC0, 0x42, 0x49, 0x4E, 0x44, 0x48,
    0x89, 0x04, 0x25, 0x00, 0x2C, 0x40, 0x00, 0xBF, 0x01, 0x00, 0x00, 0x00, 0xBE, 0x07, 0x00, 0x00,
    0x00, 0xBA, 0x00, 0x2C, 0x40, 0x00, 0x41, 0xBA, 0x77, 0x00, 0x00, 0x00, 0xB8, 0x03, 0x00, 0x00,
    0x00, 0x0F, 0x05, 0x48, 0x85, 0xC0, 0x0F, 0x85, 0x1F, 0x01, 0x00, 0x00, 0xBF, 0x51, 0x00, 0x00,
    0x00, 0xB8, 0x01, 0x00, 0x00, 0x00, 0x0F, 0x05, 0xEB, 0xFE, 0x48, 0x31, 0xFF, 0xB8, 0x10, 0x00,
    0x00, 0x00, 0x0F, 0x05, 0x49, 0x89, 0xC5, 0x4C, 0x89, 0xE8, 0x48, 0xC1, 0xE8, 0x20, 0x48, 0x83,
    0xF8, 0x01, 0x0F, 0x85, 0x01, 0x01, 0x00, 0x00, 0x4D, 0x89, 0xEF, 0x49, 0x81, 0xE7, 0xFF, 0xFF,
    0x00, 0x00, 0x4D, 0x85, 0xFF, 0x0F, 0x84, 0xEE, 0x00, 0x00, 0x00, 0x48, 0x31, 0xFF, 0xB8, 0x0D,
    0x00, 0x00, 0x00, 0x0F, 0x05, 0x49, 0x89, 0xC5, 0x4C, 0x89, 0xE8, 0x48, 0xC1, 0xE8, 0x20, 0x48,
    0x83, 0xF8, 0x01, 0x0F, 0x85, 0xDE, 0x00, 0x00, 0x00, 0x4D, 0x89, 0xEE, 0x45, 0x8B, 0xF6, 0x4C,
    0x89, 0xF7, 0x4C, 0x89, 0xFE, 0xBA, 0x30, 0x00, 0x00, 0x00, 0xB8, 0x09, 0x00, 0x00, 0x00, 0x0F,
    0x05, 0x49, 0x89, 0xC5, 0x4C, 0x89, 0xE8, 0x48, 0xC1, 0xE8, 0x20, 0x48, 0x83, 0xF8, 0x01, 0x0F,
    0x85, 0xC0, 0x00, 0x00, 0x00, 0x4C, 0x89, 0xFF, 0xBE, 0x78, 0x00, 0x00, 0x00, 0xBA, 0x00, 0x2E,
    0x40, 0x00, 0xB8, 0x04, 0x00, 0x00, 0x00, 0x0F, 0x05, 0x49, 0x89, 0xC4, 0x4C, 0x89, 0xE0, 0x48,
    0x81, 0xE0, 0xFF, 0xFF, 0x00, 0x00, 0x48, 0x83, 0xF8, 0x07, 0x0F, 0x85, 0xA3, 0x00, 0x00, 0x00,
    0x4C, 0x89, 0xE0, 0x48, 0xC1, 0xE8, 0x20, 0x48, 0x83, 0xF8, 0x77, 0x0F, 0x85, 0x92, 0x00, 0x00,
    0x00, 0x48, 0x8B, 0x04, 0x25, 0x00, 0x2E, 0x40, 0x00, 0x48, 0xC7, 0xC1, 0x42, 0x49, 0x4E, 0x44,
    0x48, 0x39, 0xC8, 0x75, 0x7E, 0x4C, 0x89, 0xF7, 0xB8, 0x0C, 0x00, 0x00, 0x00, 0x0F, 0x05, 0x49,
    0x89, 0xC4, 0x4C, 0x89, 0xE0, 0x48, 0xC1, 0xE8, 0x20, 0x48, 0x83, 0xF8, 0x01, 0x75, 0x72, 0x4C,
    0x89, 0xE0, 0x48, 0x81, 0xE0, 0xFF, 0xFF, 0x00, 0x00, 0x48, 0x83, 0xF8, 0x51, 0x75, 0x62, 0xBF,
    0x52, 0x00, 0x00, 0x00, 0xB8, 0x01, 0x00, 0x00, 0x00, 0x0F, 0x05, 0xEB, 0xFE, 0xBF, 0x50, 0x00,
    0x00, 0x00, 0xB8, 0x01, 0x00, 0x00, 0x00, 0x0F, 0x05, 0xEB, 0xFE, 0xBF, 0x59, 0x00, 0x00, 0x00,
    0xB8, 0x01, 0x00, 0x00, 0x00, 0x0F, 0x05, 0xEB, 0xFE, 0xBF, 0x54, 0x00, 0x00, 0x00, 0xB8, 0x01,
    0x00, 0x00, 0x00, 0x0F, 0x05, 0xEB, 0xFE, 0xBF, 0x55, 0x00, 0x00, 0x00, 0xB8, 0x01, 0x00, 0x00,
    0x00, 0x0F, 0x05, 0xEB, 0xFE, 0xBF, 0x56, 0x00, 0x00, 0x00, 0xB8, 0x01, 0x00, 0x00, 0x00, 0x0F,
    0x05, 0xEB, 0xFE, 0xBF, 0x57, 0x00, 0x00, 0x00, 0xB8, 0x01, 0x00, 0x00, 0x00, 0x0F, 0x05, 0xEB,
    0xFE, 0xBF, 0x58, 0x00, 0x00, 0x00, 0xB8, 0x01, 0x00, 0x00, 0x00, 0x0F, 0x05, 0xEB, 0xFE,
];

/// EXEC 映像面程序（t42；位置固定 0x400000；M12-B SYS_EXEC）：
///
/// ```text
/// EXEC(7) → 必返回 ERR_IMAGE(10)（越界负探针），否则 EXIT(76)
/// EXEC(0) → 成功即不返回（新映像 = EXEC_IMAGES[0] = USER_PROGRAM：
///           LOG "USER-OK" → YIELD×32 → EXIT(42)）
/// 回落（EXEC 返回 = 失败）→ EXIT(76)
/// ```
pub const USER_EXEC_PROGRAM: [u8; 42] = [
    0xBF, 0x07, 0x00, 0x00, 0x00, 0xB8, 0x11, 0x00, 0x00, 0x00, 0x0F, 0x05, 0x48, 0x83, 0xF8, 0x0A,
    0x75, 0x0A, 0x48, 0x31, 0xFF, 0xB8, 0x11, 0x00, 0x00, 0x00, 0x0F, 0x05, 0xBF, 0x4C, 0x00, 0x00,
    0x00, 0xB8, 0x01, 0x00, 0x00, 0x00, 0x0F, 0x05, 0xEB, 0xFE,
];

/// 孤儿链 A 角色程序（t43 v2；YIELD×4 → EXIT(83)，不 SPAWN——
/// B 由内核侧 spawn_user_child 登记，消除 ring3 协议时序依赖）：
pub const USER_EXIT83_PROGRAM: [u8; 30] = [
    0xBB, 0x04, 0x00, 0x00, 0x00, 0xB8, 0x02, 0x00, 0x00, 0x00, 0x0F, 0x05, 0xFF, 0xCB, 0x75, 0xF5,
    0xBF, 0x53, 0x00, 0x00, 0x00, 0xB8, 0x01, 0x00, 0x00, 0x00, 0x0F, 0x05, 0xEB, 0xFE,
];
/// 文件面端到端程序（t45；位置固定 0x400000；M13-② abi v0.7 文件面）：
///
/// ```text
/// OPEN("/files/echo", RDWR) → OK 位 + 句柄（r15）
/// WRITE(r15, "RING3-FS", 8) → (1<<32)|8
/// SEEK(r15, SET, 0)         → (1<<32)|0
/// READ(r15, 0x402E00, 8)    → len==8 且 [0x402E00] == "RING3-FS"
/// NANOSLEEP(1)              → 0（timer 阻塞源 ring3 侧单 tick 睡眠）
/// CLOSE(r15)                → 0
/// READ(r15, ...)（关后旧句柄）→ EBADF(9)（Linux fd 复用语义负探针）
/// OPEN("/nope", READ)       → ENOENT(2)（Conduit 口径负探针）
/// → EXIT(90)；分级失败码：92 OPEN / 93 WRITE / 94 SEEK / 95 READ /
///   96 NANOSLEEP / 97 CLOSE / 98 负探针 / 99 关后读
/// ```
pub const USER_FILE_PROGRAM: [u8; 478] = [
    0x48, 0x8D, 0x3D, 0xC7, 0x01, 0x00, 0x00, 0xBE, 0x0B, 0x00, 0x00, 0x00, 0xBA, 0x03, 0x00, 0x00,
    0x00, 0xB8, 0x12, 0x00, 0x00, 0x00, 0x0F, 0x05, 0x49, 0x89, 0xC4, 0x4C, 0x89, 0xE0, 0x48, 0xC1,
    0xE8, 0x20, 0x48, 0x83, 0xF8, 0x01, 0x0F, 0x85, 0x2A, 0x01, 0x00, 0x00, 0x45, 0x89, 0xE7, 0x44,
    0x89, 0xFF, 0x48, 0x8D, 0x35, 0x8D, 0x01, 0x00, 0x00, 0xBA, 0x08, 0x00, 0x00, 0x00, 0xB8, 0x14,
    0x00, 0x00, 0x00, 0x0F, 0x05, 0x49, 0x89, 0xC4, 0x4C, 0x89, 0xE0, 0x48, 0xC1, 0xE8, 0x20, 0x48,
    0x83, 0xF8, 0x01, 0x0F, 0x85, 0x0B, 0x01, 0x00, 0x00, 0x4C, 0x89, 0xE0, 0x83, 0xF8, 0x08, 0x0F,
    0x85, 0xFF, 0x00, 0x00, 0x00, 0x44, 0x89, 0xFF, 0x31, 0xF6, 0x31, 0xD2, 0xB8, 0x17, 0x00, 0x00,
    0x00, 0x0F, 0x05, 0x49, 0x89, 0xC4, 0x4C, 0x89, 0xE0, 0x48, 0xC1, 0xE8, 0x20, 0x48, 0x83, 0xF8,
    0x01, 0x0F, 0x85, 0xEB, 0x00, 0x00, 0x00, 0x4C, 0x89, 0xE0, 0x85, 0xC0, 0x0F, 0x85, 0xE0, 0x00,
    0x00, 0x00, 0x44, 0x89, 0xFF, 0xBE, 0x00, 0x2E, 0x40, 0x00, 0xBA, 0x08, 0x00, 0x00, 0x00, 0xB8,
    0x13, 0x00, 0x00, 0x00, 0x0F, 0x05, 0x49, 0x89, 0xC4, 0x4C, 0x89, 0xE0, 0x48, 0xC1, 0xE8, 0x20,
    0x48, 0x83, 0xF8, 0x01, 0x0F, 0x85, 0xC6, 0x00, 0x00, 0x00, 0x4C, 0x89, 0xE0, 0x83, 0xF8, 0x08,
    0x0F, 0x85, 0xBA, 0x00, 0x00, 0x00, 0x48, 0xB9, 0x52, 0x49, 0x4E, 0x47, 0x33, 0x2D, 0x46, 0x53,
    0x48, 0x8B, 0x04, 0x25, 0x00, 0x2E, 0x40, 0x00, 0x48, 0x39, 0xC8, 0x0F, 0x85, 0x9F, 0x00, 0x00,
    0x00, 0xBF, 0x01, 0x00, 0x00, 0x00, 0xB8, 0x18, 0x00, 0x00, 0x00, 0x0F, 0x05, 0x48, 0x85, 0xC0,
    0x0F, 0x85, 0x98, 0x00, 0x00, 0x00, 0x44, 0x89, 0xFF, 0xB8, 0x15, 0x00, 0x00, 0x00, 0x0F, 0x05,
    0x48, 0x85, 0xC0, 0x0F, 0x85, 0x93, 0x00, 0x00, 0x00, 0x44, 0x89, 0xFF, 0xBE, 0x00, 0x2E, 0x40,
    0x00, 0xBA, 0x08, 0x00, 0x00, 0x00, 0xB8, 0x13, 0x00, 0x00, 0x00, 0x0F, 0x05, 0x83, 0xF8, 0x09,
    0x0F, 0x85, 0x92, 0x00, 0x00, 0x00, 0x48, 0x8D, 0x3D, 0xAC, 0x00, 0x00, 0x00, 0xBE, 0x05, 0x00,
    0x00, 0x00, 0xBA, 0x01, 0x00, 0x00, 0x00, 0xB8, 0x12, 0x00, 0x00, 0x00, 0x0F, 0x05, 0x48, 0x83,
    0xF8, 0x02, 0x0F, 0x85, 0x62, 0x00, 0x00, 0x00, 0xBF, 0x5A, 0x00, 0x00, 0x00, 0xB8, 0x01, 0x00,
    0x00, 0x00, 0x0F, 0x05, 0xEB, 0xFE, 0xBF, 0x5C, 0x00, 0x00, 0x00, 0xB8, 0x01, 0x00, 0x00, 0x00,
    0x0F, 0x05, 0xEB, 0xFE, 0xBF, 0x5D, 0x00, 0x00, 0x00, 0xB8, 0x01, 0x00, 0x00, 0x00, 0x0F, 0x05,
    0xEB, 0xFE, 0xBF, 0x5E, 0x00, 0x00, 0x00, 0xB8, 0x01, 0x00, 0x00, 0x00, 0x0F, 0x05, 0xEB, 0xFE,
    0xBF, 0x5F, 0x00, 0x00, 0x00, 0xB8, 0x01, 0x00, 0x00, 0x00, 0x0F, 0x05, 0xEB, 0xFE, 0xBF, 0x60,
    0x00, 0x00, 0x00, 0xB8, 0x01, 0x00, 0x00, 0x00, 0x0F, 0x05, 0xEB, 0xFE, 0xBF, 0x61, 0x00, 0x00,
    0x00, 0xB8, 0x01, 0x00, 0x00, 0x00, 0x0F, 0x05, 0xEB, 0xFE, 0xBF, 0x62, 0x00, 0x00, 0x00, 0xB8,
    0x01, 0x00, 0x00, 0x00, 0x0F, 0x05, 0xEB, 0xFE, 0xBF, 0x63, 0x00, 0x00, 0x00, 0xB8, 0x01, 0x00,
    0x00, 0x00, 0x0F, 0x05, 0xEB, 0xFE, 0x52, 0x49, 0x4E, 0x47, 0x33, 0x2D, 0x46, 0x53, 0x2F, 0x66,
    0x69, 0x6C, 0x65, 0x73, 0x2F, 0x65, 0x63, 0x68, 0x6F, 0x2F, 0x6E, 0x6F, 0x70, 0x65,
];
