//! Lumina VNet —— virtio-net-pci（virtio 1.0 modern）网络驱动面。
//!
//! M23-C1 段：PCI 能力表走查（common/notify/isr/device 四窗定位）→
//! BAR 恒等映射（LFB 同款 [`Walker`] 惯例）→ 设备状态机 bring-up
//! （ACKNOWLEDGE → DRIVER → 特性协商 FEATURES_OK → vring 装配 →
//! DRIVER_OK）→ MAC 读出。t68 自检 = 全链状态断言 + MAC 电气活体
//! （QEMU user-net 默认 52:54:00:12:34:56）。
//!
//! M23-C2 段：数据面活体——RX 预填（单 desc 单缓冲，设备可写）、TX
//! 击发（notify 窗 = 基址 + queue_notify_off × multiplier，u16 队号）、
//! used 环轮询排水、ARP 电气活体（t69：广播请求 who-has 10.0.2.2，
//! QEMU slirp 应答，帧解析 oper/spa/tha 三断言）。中断面不开 MSI-X，
//! 纯轮询（[`pulse`] SPSC 环交接随 C3 段）；ctrl vq（队列 2）仅装配
//! 不驱动。
//!
//! M24-C1 段：RX 排水面水位背压 + ICMP echo reply（t73）。背压滞回：
//! 环占用 ≥ [`RX_HI_WATERMARK`] → 投入（排水 desc 全部停臂入 pending，
//! 设备自由缓冲递减 → 线上级背压；排水面短路）；占用 ≤
//! [`RX_LO_WATERMARK`] → 解除（pending 一揽子重臂，缓冲池复位）。
//! ICMP 面：RFC 1071 反码校验和（[`cksum16`]/[`cksum_ok`]）+ echo
//! request 击发（[`icmp_echo_tx`]，网关 10.0.2.2 回声）+ echo reply
//! 应答器（[`build_icmp_reply`] 纯组帧 + [`icmp_echo_reply`] TX 服务，
//! 消费方对入帧 type8 调用即回——M24 起网络服务契约）。
//!
//! M36-N1 段：TCP 回环面（[`pulse::tcp`] 消费）——端口表 + 全闸分派 +
//! 回环交接 + 外部 TX 电气（t86 活体九相位）。**M37-N1 段：TCP 重传面**
//! ——TSC 纳秒 RTO 臂（[`pulse::tcp::RtoTimer`] 电气承接：合成拍
//! [`tcp_retx_arm_at`]/[`tcp_retx_poll_at`] 确定性驱动 + 外部 SYN 真电
//! 首臂）+ 单流乱序重组窗（[`tcp_reasm_seed`] 播种接管分派链——
//! InOrder 前缀拼接交付，未播种直通槽 = t86 逐位同构回归锚）+ 外部 RX
//! 对接收口（[`tcp_external_inject`] 外部形段直注共享交接环——M27-T1
//! 既登记偏差随本笔收口）；t89 活体六相位（重传拍双击发 + 退避倍增
//! + ACK 清账 + 乱序拼接字节级对账 + 外部 RX 握手对账 + 统计对账）。
//!
//! v0 单流单臂单窗（多连接扩容随服务化批次挂账）。
//!
//! **M38-TCP1 段：TCP 服务化批次（连接表驱动五面承接）**——pulse::tcp
//! 五面（WinScale、RttEst、CongestCtl、PersistTimer、ConnTable——重传
//! 面 v0 简化域收口）的电气承接：**合成拍模板 → 连接表驱动**——定容
//! 8 槽四元组查表 [`TCP_CONNS`]，每槽 RTO 重传臂 [`tcp_conn_retx_tick_at`]
//! 与零窗探测电击发 [`tcp_conn_persist_tick_at`]（重发 una 起 1 字节
//! ——RFC 9293 §3.7.3），交付管线 [`tcp_conn_deliver`]（ACK 滑窗推进、
//! 槽内重组），WS 有效窗解释面 [`tcp_conn_effective_win`]。t91 活体
//! 六相位：双连接并行交付、Karn 窄化、拥塞折叠回升、零窗探测电击发、
//! 窗缩放有效窗、统计清账。M37-N1 单流单臂单窗三件保留作 t89 逐位回
//! 归锚不迁移不删除。
//!
//! unsafe 白名单说明（SPEC 第十七章）：本模块是「框架内核白名单模块」，
//! virtio MMIO 寄存器访问无法以 safe Rust 表达；逐处携带 SAFETY 注释，
//! 访问基址一律来自本模块 probe 成功后的映射窗（界内偏移，无越界路径）。

use core::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use ostd::mm::frame::FrameAllocator;
use ostd::mm::page::{Entry, IdentityAccess, PageError, Walker};
use ostd::sync::spsc::SpscRing;
use pulse::udp::{PortTable, MAX_PAYLOAD, PROTO_UDP};

/// virtio 现代 PCI 供应商 ID。
const VIRTIO_VENDOR: u16 = 0x1AF4;
/// virtio-net modern 设备 ID（0x1040 基 + net=1）。
const VIRTIO_DEV_NET_MODERN: u16 = 0x1041;

/// virtio PCI 能力类型：公共配置窗。
const CAP_COMMON: u8 = 1;
/// virtio PCI 能力类型：通知窗（C2 段使用，本段仅记录）。
const CAP_NOTIFY: u8 = 2;
/// virtio PCI 能力类型：ISR 窗（C2 中断面，本段仅记录）。
const CAP_ISR: u8 = 3;
/// virtio PCI 能力类型：设备配置窗（MAC）。
const CAP_DEVICE: u8 = 4;

/// 设备状态位：已识别。
const S_ACK: u8 = 1;
/// 设备状态位：驱动就绪。
const S_DRIVER: u8 = 2;
/// 设备状态位：驱动可用（队列装配后）。
const S_DRIVER_OK: u8 = 4;
/// 设备状态位：特性协商完成。
const S_FEAT_OK: u8 = 8;

/// VIRTIO_F_VERSION_1 特性位（全局位 32 = 扩展字 1 内 bit 0；初版误记
/// 全局位 38=NOTIFICATION_DATA，QEMU 实测 f_hi=0x101 定案）。
const F_VERSION_1: u32 = 1;

/// common config 窗寄存器偏移（virtio 1.0 §4.1.4.3）。
mod cc {
    /// 设备特性字选择（u32）。
    pub const DEV_FEAT_SEL: usize = 0x00;
    /// 设备特性字（u32）。
    pub const DEV_FEAT: usize = 0x04;
    /// 驱动特性字选择（u32）。
    pub const DRV_FEAT_SEL: usize = 0x08;
    /// 驱动特性字（u32）。
    pub const DRV_FEAT: usize = 0x0C;
    /// 队列总数（u16）。
    pub const NUM_QUEUES: usize = 0x12;
    /// 设备状态（u8）。
    pub const STATUS: usize = 0x14;
    /// 队列选择（u16）。
    pub const Q_SELECT: usize = 0x16;
    /// 队列深度（u16）。
    pub const Q_SIZE: usize = 0x18;
    /// 队列使能（u16）。
    pub const Q_ENABLE: usize = 0x1C;
    /// 队列 notify 槽位（u16；kick 地址 = notify 基址 + 此值 × multiplier）。
    pub const Q_NOTIFY_OFF: usize = 0x1E;
    /// 队列 desc 表物理基址（u64）。
    pub const Q_DESC: usize = 0x20;
    /// 队列 avail 环物理基址（u64）。
    pub const Q_AVAIL: usize = 0x28;
    /// 队列 used 环物理基址（u64）。
    pub const Q_USED: usize = 0x30;
}

/// bring-up 成果：MAC + 队列面（t68 断言域；C2 数据面共用）。
pub struct NetDev {
    /// MAC 地址（device cfg 窗逐字节读出）。
    pub mac: [u8; 6],
    /// 队列总数（rx + tx + ctrl；≥ 2 断言面）。
    pub num_queues: u16,
    /// rx/tx 队列深度（QEMU modern 恒 256）。
    pub queue_size: u16,
    /// 终态设备状态（应 = ACK|DRIVER|FEAT_OK|DRIVER_OK = 0x0F）。
    pub status: u8,
}

/// 已映射 MMIO 窗（恒等映射线性基址 == 物理基址）。
struct Window {
    base: u64,
}

impl Window {
    // SAFETY: 前置条件 —— base 自 probe 成功窗映射（bar+offset+len 界内），
    //          偏移由调用方按 virtio 规范域给出。
    // 不变式 —— volatile 单序读写（防合并/重排）；窗内偏移无越界路径。
    // 并发 —— bring-up 限 kmain 自检段单语境；C2 收发面按 SPSC 纪律扩展。
    // 违反后果 —— 错基址误写映射邻区（PCI 窗相邻设备寄存器）。
    unsafe fn rd8(&self, off: usize) -> u8 {
        // SAFETY: 同函数级四行注释（界内偏移 volatile 单读）。
        unsafe { core::ptr::read_volatile((self.base as usize + off) as *const u8) }
    }
    // SAFETY: 界内断言同 [`Window::rd8`]（同窗同纪律）。
    unsafe fn rd16(&self, off: usize) -> u16 {
        // SAFETY: 同函数级四行注释（界内偏移 volatile 单读）。
        unsafe { core::ptr::read_volatile((self.base as usize + off) as *const u16) }
    }
    // SAFETY: 界内断言同 [`Window::rd8`]（同窗同纪律）。
    unsafe fn rd32(&self, off: usize) -> u32 {
        // SAFETY: 同函数级四行注释（界内偏移 volatile 单读）。
        unsafe { core::ptr::read_volatile((self.base as usize + off) as *const u32) }
    }
    // SAFETY: 界内断言同 [`Window::rd8`]（同窗同纪律）。
    unsafe fn wr8(&self, off: usize, v: u8) {
        // SAFETY: 同函数级四行注释（界内偏移 volatile 单写）。
        unsafe { core::ptr::write_volatile((self.base as usize + off) as *mut u8, v) }
    }
    // SAFETY: 界内断言同 [`Window::rd8`]（同窗同纪律）。
    unsafe fn wr16(&self, off: usize, v: u16) {
        // SAFETY: 同函数级四行注释（界内偏移 volatile 单写）。
        unsafe { core::ptr::write_volatile((self.base as usize + off) as *mut u16, v) }
    }
    // SAFETY: 界内断言同 [`Window::rd8`]（同窗同纪律）。
    unsafe fn wr32(&self, off: usize, v: u32) {
        // SAFETY: 同函数级四行注释（界内偏移 volatile 单写）。
        unsafe { core::ptr::write_volatile((self.base as usize + off) as *mut u32, v) }
    }
    /// u64 寄存器两拍写（低字先行——规范无原子性要求，QEMU 逐字消费）。
    // SAFETY: 界内断言同 [`Window::rd8`]（同窗同纪律）。
    unsafe fn wr64(&self, off: usize, v: u64) {
        // SAFETY: 同函数级四行注释（界内偏移两拍单写）。
        unsafe {
            self.wr32(off, v as u32);
            self.wr32(off + 4, (v >> 32) as u32);
        }
    }
    /// u64 寄存器两拍读（低字先行，与 [`Window::wr64`] 对偶）。
    // SAFETY: 界内断言同 [`Window::rd8`]（同窗同纪律）。
    unsafe fn rd64(&self, off: usize) -> u64 {
        // SAFETY: 同函数级四行注释（界内偏移两拍单读）。
        unsafe {
            let lo = u64::from(self.rd32(off));
            let hi = u64::from(self.rd32(off + 4));
            (hi << 32) | lo
        }
    }
}

/// PCI type-1 配置空间双字读（与 [`crate::fb`] 共用同一打包语义）。
fn pci_read_dword(bus: u8, dev: u8, func: u8, offset: u8) -> u32 {
    let addr = 0x8000_0000u32
        | (u32::from(bus)) << 16
        | (u32::from(dev)) << 11
        | (u32::from(func)) << 8
        | u32::from(offset & 0xFC);
    ostd::hw::ports::write_u32(0xCF8, addr);
    ostd::hw::ports::read_u32(0xCFC)
}

/// PCI type-1 配置空间双字写（CF8 地址窗 + CFC 数据窗，与读对偶）。
fn pci_write_dword(bus: u8, dev: u8, func: u8, offset: u8, val: u32) {
    let addr = 0x8000_0000u32
        | (u32::from(bus)) << 16
        | (u32::from(dev)) << 11
        | (u32::from(func)) << 8
        | u32::from(offset & 0xFC);
    ostd::hw::ports::write_u32(0xCF8, addr);
    ostd::hw::ports::write_u32(0xCFC, val);
}

/// 探测 virtio-net（bus 0 全扫）：vendor 0x1AF4 + device 0x1041。
/// 返回（dev 槽位，BAR 基址表 [6]——0 = 无 BAR）。
fn probe() -> Option<(u8, [u32; 6])> {
    for dev in 0..32u8 {
        let id = pci_read_dword(0, dev, 0, 0x00);
        if id & 0xFFFF == 0xFFFF {
            continue; // 空槽
        }
        if id & 0xFFFF == u32::from(VIRTIO_VENDOR) && id >> 16 == u32::from(VIRTIO_DEV_NET_MODERN) {
            let mut bars = [0u32; 6];
            for (i, bar) in bars.iter_mut().enumerate() {
                *bar = pci_read_dword(0, dev, 0, 0x10 + 4 * i as u8);
            }
            return Some((dev, bars));
        }
    }
    crate::console::serial_log_bytes(b"net: probe miss");
    None
}

/// 能力窗定位三元组：(bar 物理基址, 窗内偏移, 长度)。
type CapWin = (u64, usize, usize);

/// 能力表走查成果：四窗定位（common 必有；notify/isr/device 可缺）。
struct Caps {
    /// 公共配置窗（状态机/队列面）。
    common: CapWin,
    /// 通知窗（C2 数据面队列击发用）。
    notify: Option<CapWin>,
    /// notify_off_multiplier（notify cap 扩展域 dword@16；0 = 缺失）。
    notify_mult: u32,
    /// ISR 窗（C3 中断面，本段仅记录）。
    #[allow(dead_code)] // C3 中断面消费（本段记录面——走查即取证）
    isr: Option<CapWin>,
    /// 设备配置窗（MAC）。
    device: Option<CapWin>,
}

/// 能力表走查：按类型收集。fail-closed：common 缺失 → None（modern
/// 设备必有 common cap）。
fn walk_caps(dev: u8, bars: &[u32; 6]) -> Option<Caps> {
    let mut common = None;
    let mut notify = None;
    let mut notify_mult = 0u32;
    let mut isr = None;
    let mut device = None;
    // 能力表头：BIST 寄存器后 offset 0x34（cap_ptr，小端 dword 低 8 位）
    let first = pci_read_dword(0, dev, 0, 0x34);
    let mut ptr = (first & 0xFF) as u8;
    let mut hops = 0;
    while ptr != 0 && hops < 48 {
        hops += 1;
        // cap 布局（virtio 1.0 §4.1.4.4）：vndr(0) next(1) len(2) type(3)
        // bar(4) idver(5) pad(6..8) offset(8..12) length(12..16)
        let d0 = pci_read_dword(0, dev, 0, ptr);
        let d1 = pci_read_dword(0, dev, 0, ptr + 4);
        let d2 = pci_read_dword(0, dev, 0, ptr + 8);
        let d3 = pci_read_dword(0, dev, 0, ptr + 12);
        // notify cap 扩展域 notify_off_multiplier（virtio 1.0 §4.1.4.4.1：
        // virtio_pci_notify_cap 首 dword 于 cap 基址 +16；其余类型无此域，
        // 读回仅 notify 臂消费）。
        let d4 = pci_read_dword(0, dev, 0, ptr + 16);
        let vndr = d0 & 0xFF;
        let ty = ((d0 >> 24) & 0xFF) as u8;
        let bar = d1 & 0xFF;
        let _ver = ((d1 >> 8) & 0xFF) as u8;
        let off = d2 as u64;
        let len = d3 as u64;
        ptr = ((d0 >> 8) & 0xFF) as u8;
        if vndr != 0x09 {
            continue; // 非 vendor-specific cap（MSI-X 等标准 cap），跳过
        }
        // 判别位记档（实测 QEMU virtio-net-pci 定案）：virtio caps 的
        // cap_vndr = PCI_CAP_ID_VNDR(0x09)——非 virtio 供应商 0x1AF4
        // （初版误用后者，六跳全滤，caps no-common 实录）；cfg_type 域
        // 由下方 match 白名单收口（实测多一 type=5 vendor 附加 cap，
        // 未知类型自然忽略）。
        if bar as usize >= 6 {
            continue;
        }
        let base = u64::from(bars[bar as usize] & 0xFFFF_FFF0);
        if base == 0 {
            continue;
        }
        let win = (base, off as usize, len as usize);
        match ty {
            CAP_COMMON => common = Some(win),
            CAP_NOTIFY => {
                notify = Some(win);
                notify_mult = d4;
            }
            CAP_ISR => isr = Some(win),
            CAP_DEVICE => device = Some(win),
            _ => {}
        }
    }
    Some(Caps {
        common: {
            match common {
                Some(c) => c,
                None => {
                    crate::console::serial_log_bytes(b"net: caps no-common");
                    return None;
                }
            }
        },
        notify,
        notify_mult,
        isr,
        device,
    })
}

/// 恒等映射一段物理窗进引导根（LFB [`crate::fb::map_lfb`] 同款惯例：
/// Walker + IdentityAccess + 帧分配器补中间表，4 KiB 逐页）。窗落在
/// PCI hole（0xC0000000 段）——引导根 PDPT[3] 新分支，与 LAPIC/LFB
/// 同分支共存。
fn map_window(frames: &FrameAllocator, phys: u64, bytes: u64) -> Result<(), PageError> {
    let boot_cr3 = ostd::hw::control::read_cr3() & !0xFFF;
    let pages = bytes.div_ceil(4096);
    let mut walker = Walker {
        mem: &mut IdentityAccess,
        alloc_table: || frames.alloc(),
    };
    for i in 0..pages {
        let p = phys + i * 4096;
        walker.map(boot_cr3, p, p, Entry::WRITABLE)?;
    }
    Ok(())
}

/// 连续物理帧申请（vring 表面：desc/used 表物理连续为规范硬约束）：
/// 申请 k 帧并校验相邻（双向——LIFO 空闲表弹出序可升可降，初版单升
/// 序实测必败）；断链即回收已拿帧重试（dealloc LIFO 回流，上限 8 轮）。
/// 返回段最低帧地址（表基址语义）。
fn alloc_contig(frames: &FrameAllocator, k: usize) -> Option<u64> {
    for _attempt in 0..8 {
        let mut got = [0u64; 4];
        let mut ok = true;
        for i in 0..k {
            match frames.alloc() {
                Some(f) if i == 0 => got[0] = f,
                Some(f) if got[i - 1].abs_diff(f) == 4096 => got[i] = f,
                Some(f) => {
                    frames.dealloc(f);
                    for &g in &got[..i] {
                        frames.dealloc(g);
                    }
                    ok = false;
                    break;
                }
                None => {
                    for &g in &got[..i] {
                        frames.dealloc(g);
                    }
                    ok = false;
                    break;
                }
            }
        }
        if ok {
            let mut base = got[0];
            for &g in &got[1..k] {
                if g < base {
                    base = g;
                }
            }
            return Some(base);
        }
    }
    None
}

/// 队列装配成果：深度 + 三表物理基址 + notify 槽位（C2 数据面共用）。
struct SetupQ {
    /// 队列深度（设备读回）。
    num: u16,
    /// desc 表物理基址。
    desc: u64,
    /// avail 环物理基址。
    avail: u64,
    /// used 环物理基址。
    used: u64,
    /// queue_notify_off（kick 地址槽位）。
    notify_off: u16,
}

/// vring 装配（split 布局，队列深度 N）：desc = N*16 连续帧；avail =
/// 6+2N（单帧）；used = 4+8N+2（连续帧）。QEMU modern net 队列深度
/// 1024（实测 qsz=0x400）→ desc 4 帧 / used 3 帧。写回三表物理基址
/// 与 queue_enable，读回使能位复验。队列选择后读 queue_notify_off
/// （C2 击发地址槽位）。
fn setup_queue(cc_win: &Window, q: u16, frames: &FrameAllocator) -> Option<SetupQ> {
    // SAFETY: 前置条件 —— cc_win 自 probe 映射窗（common cfg 界内偏移）。
    // 不变式 —— 队列选择先行，深度读回后按规范装配三表。
    // 并发 —— bring-up 单语境（kmain 自检段），无并发驱动者。
    // 违反后果 —— 错队列选择错配 vring（断言面 queue_size 恒等拦截）。
    unsafe {
        cc_win.wr16(cc::Q_SELECT, q);
        let n = cc_win.rd16(cc::Q_SIZE);
        let notify_off = cc_win.rd16(cc::Q_NOTIFY_OFF);
        if n == 0 || n > 4096 {
            return None;
        }
        let nu = u64::from(n);
        let desc = alloc_contig(frames, (nu * 16).div_ceil(4096) as usize)?;
        let avail = frames.alloc()?;
        let used = alloc_contig(frames, ((4 + nu * 8 + 2).div_ceil(4096)) as usize)?;
        // 帧内清零（alloc 不保证零页——avail/used 的 flags/idx 与 desc
        // flag 域必须零起步；三表逐帧清扫）
        let desc_frames = (nu * 16).div_ceil(4096);
        let used_frames = (4 + nu * 8 + 2).div_ceil(4096);
        for i in 0..desc_frames {
            ostd::hw::phys::write_zero(desc + i * 4096, 4096);
        }
        ostd::hw::phys::write_zero(avail, 4096);
        for i in 0..used_frames {
            ostd::hw::phys::write_zero(used + i * 4096, 4096);
        }
        cc_win.wr64(cc::Q_DESC, desc);
        cc_win.wr64(cc::Q_AVAIL, avail);
        cc_win.wr64(cc::Q_USED, used);
        cc_win.wr16(cc::Q_ENABLE, 1);
        let _en = cc_win.rd16(cc::Q_ENABLE);
        // 寄存器回读 fail-closed（编程对账面常态化：设备实收 ≠ 本地基址
        // 即装配面破——后续数据面 DMA 全盲，不再推进）。
        cc_win.wr16(cc::Q_SELECT, q);
        if cc_win.rd64(cc::Q_DESC) != desc
            || cc_win.rd64(cc::Q_AVAIL) != avail
            || cc_win.rd64(cc::Q_USED) != used
        {
            crate::console::serial_log_bytes(b"net: vring rb-mismatch");
            return None;
        }
        Some(SetupQ {
            num: n,
            desc,
            avail,
            used,
            notify_off,
        })
    }
}

// ======================================================================
// M23-C2 数据面：vring 表面 + ARP 电气活体（t69）
// ======================================================================

/// desc 标志：设备可写（RX 缓冲语义；TX 侧 0 = 设备只读）。
const DFLAG_WRITE: u16 = 2;

/// virtio_net_hdr 尺寸（MRG_RXBUF 未协商恒 12 B——收发帧首 12 字节零头，
/// 本驱动 GSO/校验和全零即「无卸载」语义）。
const VNET_HDR: usize = 12;

/// ARP 线上帧长（以太网 14 + ARP 28 = 42 → 零垫至 60 最小以太帧）。
const ARP_TX_LEN: usize = 60;

/// RX 预填缓冲数（单 desc 单缓冲，各 4096 B；slirp 应答单帧即收，
/// 余量吸收噪声帧如 IPv6 RA）。M24-C1 起 8：水位背压占用域扩容
/// （4 → 8，HI/LO 滞回域拉宽，ARP 突发相位可观测）。
const RX_POST: u16 = 8;

/// RX 背压高水位（pulse 环占用 ≥ HI → 投入：停臂 + 排水面短路）。
/// 占用域 0..[`RX_POST`]，HI 取 6/8：ARP 突发相位 6 轮内必越限，
/// 同时预置 2 槽噪声余量。
const RX_HI_WATERMARK: usize = 6;
/// RX 背压低水位（占用 ≤ LO → 解除：pending 一揽子重臂）。滞回带宽
/// 4 槽：解除后满预填池复位，避免 HI 临界抖动（占用水位半开域）。
const RX_LO_WATERMARK: usize = 2;

/// QEMU user-net 地址面：网关 10.0.2.2 / 本机 10.0.2.15（DHCP 默认域）。
const GW_IP: [u8; 4] = [10, 0, 2, 2];
const MY_IP: [u8; 4] = [10, 0, 2, 15];

/// t69 轮询预算（TCG 下 ~0.5 s 量级上限；slirp 应答实测量级微秒，
/// 预算纯为最坏情况兜底）。
const ARP_SPIN_BUDGET: u64 = 40_000_000;
/// t69 命中后 TX 回执收讫预算（M37-⓪）：应答已达前提下回执落环只差
/// 设备侧账面一步——同量级短预算足额（回执真丢失即 t73 B 面，如实败）。
const ARP_SETTLE_BUDGET: u64 = 1_000_000;

/// vring 句柄：三表物理基址 + 双游标（驱动侧 avail 发布位 / used 影子）。
struct Vring {
    /// desc 表物理基址。
    desc: u64,
    /// avail 环物理基址。
    avail: u64,
    /// used 环物理基址。
    used: u64,
    /// 队列深度（环槽取模域）。
    num: u16,
    /// queue_notify_off（kick 地址槽位）。
    notify_off: u16,
    /// 驱动侧 avail.idx 游标（下一发布槽位）。
    next_idx: u16,
    /// 驱动侧 used.idx 影子（下一消费完成项）。
    last_used: u16,
}

/// C2 全局驱动态：bring_up 末尾登记，arp_roundtrip 消费。
struct NetState {
    /// notify 窗基址（cap offset 窗内基址，kick 地址 = 此值 + 槽位 × multiplier）。
    notify_base: u64,
    /// notify_off_multiplier（cap 扩展域）。
    notify_mult: u32,
    /// rx 队列（队列 0）。
    rx: Vring,
    /// tx 队列（队列 1）。
    tx: Vring,
    /// 本机 MAC（bring-up 读出；帧源址 + 应答寻我断言共用）。
    mac: [u8; 6],
    /// RX 预填缓冲物理地址（desc id 即下标）。
    rx_bufs: [u64; RX_POST as usize],
    /// TX 帧缓冲物理地址（单帧复用）。
    tx_buf: u64,
    /// C1 背压 pending 域：已排水待重臂的 desc 下标（投入态停臂集，
    /// 解除时一揽子重臂——缓冲池零泄漏的关键账本）。
    rx_pending: [bool; RX_POST as usize],
}

/// 全局驱动态登记位（单语境纪律：kmain 自检段串行访问，&raw 手法）。
static mut NET_STATE: Option<NetState> = None;

/// 态句柄（登记读出；None = bring-up 未达 C2 数据面）。
fn net_state_mut() -> Option<&'static mut NetState> {
    // SAFETY: 单语境（kmain 自检串行段）独占访问；&raw 手法不建立
    //         static 引用（static_mut_refs 免疫），Option 判空先行。
    unsafe { (&raw mut NET_STATE).as_mut()?.as_mut() }
}

/// used 环完成项（split 布局 elem：desc 链头 id + 设备写入字节数）。
#[derive(Clone, Copy)]
struct Done {
    /// desc 链头 id（rx = 缓冲下标；tx = 帧槽位）。
    id: u32,
    /// 设备写入字节数（RX 面帧长守卫：短于 ARP 整帧即噪声拒收）。
    len: u32,
}

// ---- vring 表面原语（全部 volatile 单拍访问；x86 TSO 承载发布序） ----

/// SAFETY: 前置 —— desc 表物理基址自 setup_queue 连续帧；i < num
///         （调用方界内保证：rx 0..RX_POST，tx 单 desc）。
/// 不变式 —— 16 B 步距逐字段写入；next = 0（单 desc 链契约）。
/// 违反后果 —— 越界写邻表（i < num 由调用方守卫）。
unsafe fn set_desc(desc_base: u64, i: u16, addr: u64, len: u32, flags: u16) {
    let d = desc_base + 16 * u64::from(i);
    // SAFETY: 界内 16 B 槽位逐字段 volatile 单写（同函数级注释）。
    unsafe {
        core::ptr::write_volatile(d as *mut u64, addr);
        core::ptr::write_volatile((d + 8) as *mut u32, len);
        core::ptr::write_volatile((d + 12) as *mut u16, flags);
        core::ptr::write_volatile((d + 14) as *mut u16, 0);
    }
}

/// avail 环发布：环项先行，idx 后拍（设备观察序 = 发布序；x86 TSO
/// store-store 单向保证 + volatile 编译序屏障）。
/// SAFETY: avail 表自 setup_queue 单帧；槽位 = next_idx % num 界内。
unsafe fn push_avail(vr: &mut Vring, head: u16) {
    let slot = vr.avail + 4 + 2 * u64::from(vr.next_idx % vr.num);
    // SAFETY: 环槽 + idx 域 volatile 单写（同函数级注释）。
    unsafe {
        core::ptr::write_volatile(slot as *mut u16, head);
        core::ptr::write_volatile((vr.avail + 2) as *mut u16, vr.next_idx.wrapping_add(1));
    }
    vr.next_idx = vr.next_idx.wrapping_add(1);
}

/// 队列击发：notify 地址 = 窗基址 + queue_notify_off × multiplier
/// （virtio 1.0 §4.1.4.4），写 u16 = 队号。
/// SAFETY: notify 窗自 cap 走查映射（span 已含 notify 段）。
unsafe fn kick(notify_base: u64, mult: u32, q: u16, vr: &Vring) {
    let addr = notify_base + u64::from(vr.notify_off) * u64::from(mult);
    // SAFETY: notify 寄存器 volatile 单写（同函数级注释）。
    unsafe { core::ptr::write_volatile(addr as *mut u16, q) }
}

/// used 环排水：影子游标 → 设备 idx 逐项搬入栈缓冲（容量由调用方给定，
/// 满即断流余项下轮重扫）。返回项数。
/// SAFETY: used 表自 setup_queue 连续帧；环槽 = 影子 % num 界内。
unsafe fn drain_used(vr: &mut Vring, out: &mut [Done]) -> usize {
    let target = unsafe { core::ptr::read_volatile((vr.used + 2) as *const u16) };
    let mut n = 0usize;
    while vr.last_used != target && n < out.len() {
        let e = vr.used + 4 + 8 * u64::from(vr.last_used % vr.num);
        // SAFETY: 完成项 8 B 逐字段 volatile 单读（同函数级注释）。
        out[n] = unsafe {
            Done {
                id: core::ptr::read_volatile(e as *const u32),
                len: core::ptr::read_volatile((e + 4) as *const u32),
            }
        };
        n += 1;
        vr.last_used = vr.last_used.wrapping_add(1);
    }
    n
}

/// 帧缓冲逐字节 volatile 写（72 B 量级，突发面足够）。
/// SAFETY: buf 自帧分配器单帧（恒等映射）；off+len ≤ 帧长（调用方域）。
unsafe fn poke(buf: u64, off: usize, bytes: &[u8]) {
    // SAFETY: 界内逐字节 volatile 单写（同函数级注释）。
    unsafe {
        for (i, b) in bytes.iter().enumerate() {
            core::ptr::write_volatile((buf + off as u64 + i as u64) as *mut u8, *b);
        }
    }
}

/// 帧缓冲大端 u16 读（以太网/ARP 全部多字节域为大端序）。
/// SAFETY: buf 恒等映射帧内偏移（调用方域）；两拍单读。
unsafe fn peek16(buf: u64, off: usize) -> u16 {
    // SAFETY: 界内两字节 volatile 单读 + 大端拼装（同函数级注释）。
    unsafe {
        let hi = u16::from(core::ptr::read_volatile((buf + off as u64) as *const u8));
        let lo = u16::from(core::ptr::read_volatile(
            (buf + off as u64 + 1) as *const u8,
        ));
        (hi << 8) | lo
    }
}

/// 帧缓冲单字节读。
/// SAFETY: buf 恒等映射帧内偏移（调用方域）。
unsafe fn peek8(buf: u64, off: usize) -> u8 {
    // SAFETY: 界内 volatile 单读（同函数级注释）。
    unsafe { core::ptr::read_volatile((buf + off as u64) as *const u8) }
}

/// 诊断面（t69 失败域）：vring 关键态直读——avail/used idx 双环、
/// desc[0] 回读、notify 面参数、TX 缓冲首 20 B、RX 缓冲 0 首 20 B。
/// 逐行 LUMINA-NETDIAG 前缀（宿主断言面同源）。
pub fn diag(w: &mut impl core::fmt::Write) {
    let Some(st) = net_state_mut() else {
        let _ = writeln!(w, "LUMINA-NETDIAG no-state");
        return;
    };
    // SAFETY: 态自 bring_up 登记；下述全部恒等映射界内 volatile 单读
    //         （诊断只读，无发布序要求）。
    unsafe {
        let tx_avail_idx = core::ptr::read_volatile((st.tx.avail + 2) as *const u16);
        let rx_avail_idx = core::ptr::read_volatile((st.rx.avail + 2) as *const u16);
        let tx_used_idx = core::ptr::read_volatile((st.tx.used + 2) as *const u16);
        let rx_used_idx = core::ptr::read_volatile((st.rx.used + 2) as *const u16);
        let _ = writeln!(
            w,
            "LUMINA-NETDIAG notify={:#x} mult={} rx_off={} tx_off={} avail(tx={},rx={}) used(tx={},rx={}) shadow(tx={},rx={})",
            st.notify_base,
            st.notify_mult,
            st.rx.notify_off,
            st.tx.notify_off,
            tx_avail_idx,
            rx_avail_idx,
            tx_used_idx,
            rx_used_idx,
            st.tx.last_used,
            st.rx.last_used,
        );
        // 表地址对账面（与 QMP vring-{desc,avail,used} 逐项对照；rb_* =
        // Q_DESC/Q_AVAIL/Q_USED 寄存器回读——设备实收 vs 本地基址）
        let _ = writeln!(
            w,
            "LUMINA-NETDIAG rx desc={:#x} avail={:#x} used={:#x} num={} / tx desc={:#x} avail={:#x} used={:#x} num={}",
            st.rx.desc,
            st.rx.avail,
            st.rx.used,
            st.rx.num,
            st.tx.desc,
            st.tx.avail,
            st.tx.used,
            st.tx.num,
        );
        // desc[0] 回读（tx 队列）：addr/len/flags/next 四字段
        let d = st.tx.desc;
        let a0 = core::ptr::read_volatile(d as *const u64);
        let l0 = core::ptr::read_volatile((d + 8) as *const u32);
        let f0 = core::ptr::read_volatile((d + 12) as *const u16);
        let n0 = core::ptr::read_volatile((d + 14) as *const u16);
        let _ = writeln!(
            w,
            "LUMINA-NETDIAG txdesc0 addr={a0:#x} len={l0} flags={f0:#x} next={n0}"
        );
        let mut buf = [0u8; 20];
        for (i, b) in buf.iter_mut().enumerate() {
            *b = peek8(st.tx_buf, i);
        }
        let _ = writeln!(w, "LUMINA-NETDIAG txbuf {buf:02x?}");
        for (i, b) in buf.iter_mut().enumerate() {
            *b = peek8(st.rx_bufs[0], i);
        }
        let _ = writeln!(w, "LUMINA-NETDIAG rxbuf0 {buf:02x?}");
        let _ = writeln!(
            w,
            "LUMINA-NETDIAG pulse pushed={} popped={} miss={} short={}",
            PULSE_PUSHED.load(Ordering::Relaxed),
            PULSE_POPPED.load(Ordering::Relaxed),
            PULSE_MISS.load(Ordering::Relaxed),
            RX_SHORT.load(Ordering::Relaxed),
        );
        let _ = writeln!(
            w,
            "LUMINA-NETDIAG bp active={} enters={} exits={} rearmed={}",
            RX_BP_ACTIVE.load(Ordering::Relaxed),
            RX_BP_ENTERS.load(Ordering::Relaxed),
            RX_BP_EXITS.load(Ordering::Relaxed),
            RX_REARMED.load(Ordering::Relaxed),
        );
        let _ = writeln!(
            w,
            "LUMINA-NETDIAG icmp req_tx={} replies={}",
            ICMP_REQ_TX.load(Ordering::Relaxed),
            ICMP_REPLIES.load(Ordering::Relaxed),
        );
    }
}

// ===================== C3：pulse 环交接面 =====================
//
// RX 帧「出内核」语义：设备 DMA 写 RX 缓冲 → 排水面喂 SPSC 环 →
// 消费者出队。环交接把「轮询排水」与「帧消费」解耦——M24 起消费者
// 为用户态网络服务（任务语境），本段消费者 = 自检 t71（单语境纪律
// 承载 SPSC 契约：kmain 自检串行段，恰一生产者恰一消费者）。

/// pulse 环容量（2 的幂；[`SpscRing`] 取模域契约）。
const PULSE_CAP: usize = 8;

/// pulse 槽帧数据域上限（以太 v2 最大帧 1514 → 1520 取整域）。
pub const PULSE_FRAME_MAX: usize = 1520;

/// ICMP echo 标识（"LM"——t73 网关/自环双相位恒值）。
pub const ICMP_ECHO_ID: u16 = 0x4C4D;

/// t73 轮询预算（与 [`ARP_SPIN_BUDGET`] 同源；多相位各相位独立预算）。
pub const NET_SPIN_BUDGET: u64 = ARP_SPIN_BUDGET;
/// t73 网关回声窗（M28-K1 搭车件）：100 Hz tick 死线（50 拍 = 0.5 s/发）。
/// slirp 反射延迟是**宿主时间量**——拍数预算（spin loop count）在慢宿主
/// 上系统性失准（回声帧晚于整个预算落地）；tick 窗随宿主墙钟推进
/// （hostlink 联测 `READ_TIMEOUT_TICKS` 同款纪律），宿主速度无关。
pub const GW_ECHO_TICKS: u64 = 50;

/// pulse 环槽：单帧值语义（`Copy` 搬运、无堆无引用——环槽契约定式）。
#[derive(Clone, Copy)]
struct FrameSlot {
    /// 有效帧长（VNET_HDR 已剥；≤ [`PULSE_FRAME_MAX`]）。
    len: u16,
    /// 保留域（data 起始 8 B 对齐）。
    _pad: [u8; 6],
    /// 帧数据（以太帧头起）。
    data: [u8; PULSE_FRAME_MAX],
}

/// RX 交接环（内核 RX 面 = 唯一生产者；t71/未来网络服务 = 唯一消费者）。
static PULSE_RX: SpscRing<FrameSlot, PULSE_CAP> = SpscRing::new();

/// pulse 交接统计（累计口径；diag 与 t71 证据行同源）。
static PULSE_PUSHED: AtomicU64 = AtomicU64::new(0);
/// pulse 消费统计。
static PULSE_POPPED: AtomicU64 = AtomicU64::new(0);
/// 环满丢弃计数（M27-R1 限流后为结构违背显形信号：headroom 前置约束
/// 下 send 恒 Ok，非零即限流不变式被破——fail-visible 不静默）。
static PULSE_MISS: AtomicU64 = AtomicU64::new(0);

/// 残帧拒收计数（M27-R1 显形面：M28 取证「长度闸拒短帧」形态的观测
/// 口——长度闸拒收从静默转 fail-visible，diag 行同源）。
static RX_SHORT: AtomicU64 = AtomicU64::new(0);

/// C1 背压投入态（滞回标志；[`rx_service`] 单语境读写，原子面仅为
/// diag/快照可读）。
static RX_BP_ACTIVE: AtomicBool = AtomicBool::new(false);
/// 背压投入次数（占用越 HI 计一次；t73 证据行同源）。
static RX_BP_ENTERS: AtomicU64 = AtomicU64::new(0);
/// 背压解除次数（占用回 LO 计一次）。
static RX_BP_EXITS: AtomicU64 = AtomicU64::new(0);
/// 累计重臂数（pending 归位 desc 计数；投入态冻结 = 停臂证据）。
static RX_REARMED: AtomicU64 = AtomicU64::new(0);

/// ICMP echo request 击发计数（[`icmp_echo_tx`] 同源）。
static ICMP_REQ_TX: AtomicU64 = AtomicU64::new(0);
/// echo reply 应答器服务次数（[`icmp_echo_reply`] 同源）。
static ICMP_REPLIES: AtomicU64 = AtomicU64::new(0);

/// 消费者出队：帧拷入调用方缓冲，返回帧长（None = 环空）。
pub fn pulse_rx_pop(out: &mut [u8]) -> Option<usize> {
    let slot = PULSE_RX.recv()?;
    let fl = slot.len as usize;
    let n = fl.min(out.len());
    out[..n].copy_from_slice(&slot.data[..n]);
    PULSE_POPPED.fetch_add(1, Ordering::Relaxed);
    Some(fl)
}

/// 帧缓冲 bulk volatile 读（peek8 逐字节的批量形）。
/// SAFETY: 前置 —— buf 恒等映射帧内；off + out.len() ≤ 帧长（调用方域）。
unsafe fn peek_bytes(buf: u64, off: usize, out: &mut [u8]) {
    // SAFETY: 界内逐字节 volatile 单读（同函数级注释）。
    unsafe {
        for (i, b) in out.iter_mut().enumerate() {
            *b = core::ptr::read_volatile((buf + off as u64 + i as u64) as *const u8);
        }
    }
}

/// RX 排水面：used 环排水 → 帧喂 pulse 环 → 水位重臂（M24-C1 背压）。
///
/// **M27-R1 排水限流（t73 丢帧类收口）**：drain 批量受环余量约束
/// （headroom = 环容量 − 占用，上限 [`RX_POST`]）——余项滞留 used 环
/// 下拍续排，交接面**零丢弃**（丢帧变延迟，fail-preserve；M28 取证
/// 定案：环满 miss 形态根因 = 旧结构「先全量排水后喂环、环满即丢」）。
/// 余量耗尽即自然停排：used 完成项滞留 = desc 不归还 = 设备自由缓冲
/// 赤字 = 线级背压（与滞回投入态同构，语义升级无新增机制）。
///
/// 背压滞回（[`RX_HI_WATERMARK`]/[`RX_LO_WATERMARK`]）：占用 ≥ HI →
/// 投入——后续拍短路（不排水不重臂）；占用 ≤ LO → 解除——pending
/// 一揽子重臂（缓冲池复位，零泄漏账本）。残帧/越界 id 拒收
/// （fail-closed）且计数显形（[`RX_SHORT`]，M27-R1 起禁静默）。
/// SAFETY: 前置 —— vring 三表/rx_bufs 自 bring_up 装配（界内）；单语境
///         串行（kmain 自检段）。返回喂环成功数。
unsafe fn rx_service(st: &mut NetState) -> usize {
    // 投入态先查解除：消费面已 pop → 占用回 LO → 解除并落入正常排水
    if RX_BP_ACTIVE.load(Ordering::Relaxed) {
        if PULSE_RX.len() <= RX_LO_WATERMARK {
            RX_BP_ACTIVE.store(false, Ordering::Relaxed);
            RX_BP_EXITS.fetch_add(1, Ordering::Relaxed);
        } else {
            return 0; // 仍投入：不排水不重臂（设备侧背压保持）
        }
    }
    // M27-R1 限流：本拍排水量 ≤ 环余量——喂环必成功（容量约束前置），
    // 余项滞留 used 环下拍续排。残帧消耗排水名额但不喂环（批内余量
    // 虚占 → 好帧至多延迟一拍，语义登记）。
    let headroom = PULSE_CAP
        .saturating_sub(PULSE_RX.len())
        .min(RX_POST as usize);
    let mut elems = [Done { id: 0, len: 0 }; RX_POST as usize];
    let n = unsafe { drain_used(&mut st.rx, &mut elems[..headroom]) };
    let mut fed = 0usize;
    for e in elems.iter().take(n) {
        let idx = e.id as usize;
        if idx >= RX_POST as usize {
            continue; // 越界 id 拒收（fail-closed；无缓冲可归还）
        }
        // C1：消费即入 pending（重臂权移交水位面——残帧同权统一归还口）
        st.rx_pending[idx] = true;
        let full = e.len as usize;
        if !(VNET_HDR + 14..=4096).contains(&full) {
            // M27-R1：残帧显形（M28 取证「长度闸拒短帧」形态的观测口）
            RX_SHORT.fetch_add(1, Ordering::Relaxed);
            continue; // 残帧（以太头不足）/ 设备写长越界拒收
        }
        let flen = full - VNET_HDR;
        if flen > PULSE_FRAME_MAX {
            continue;
        }
        let mut slot = FrameSlot {
            len: flen as u16,
            _pad: [0; 6],
            data: [0; PULSE_FRAME_MAX],
        };
        // SAFETY: rx_bufs[idx] 恒等映射帧内（VNET_HDR + flen ≤ 4096 界内）。
        unsafe { peek_bytes(st.rx_bufs[idx], VNET_HDR, &mut slot.data[..flen]) };
        // headroom 前置约束下 send 恒 Ok；Err 分支保留为结构违背显形
        // 信号（命中即限流不变式被破，fail-visible 不静默）。
        match PULSE_RX.send(slot) {
            Ok(()) => {
                PULSE_PUSHED.fetch_add(1, Ordering::Relaxed);
                fed += 1;
            }
            Err(_) => {
                PULSE_MISS.fetch_add(1, Ordering::Relaxed);
            }
        }
    }
    // 水位重臂面：占用 ≥ HI → 投入（pending 停臂 = 设备缓冲赤字，线级
    // 背压）；否则 pending 一揽子归位（缓冲池复位）。
    if PULSE_RX.len() >= RX_HI_WATERMARK {
        if !RX_BP_ACTIVE.swap(true, Ordering::Relaxed) {
            RX_BP_ENTERS.fetch_add(1, Ordering::Relaxed);
        }
    } else {
        let mut rearmed = 0usize;
        for i in 0..RX_POST as usize {
            if st.rx_pending[i] {
                // SAFETY: i < RX_POST 界内（pending 域守卫）；单语境发布序。
                unsafe {
                    set_desc(st.rx.desc, i as u16, st.rx_bufs[i], 4096, DFLAG_WRITE);
                    push_avail(&mut st.rx, i as u16);
                }
                st.rx_pending[i] = false;
                rearmed += 1;
            }
        }
        RX_REARMED.fetch_add(rearmed as u64, Ordering::Relaxed);
    }
    fed
}

/// pulse 环交接活体成果（t71 断言域）。
pub struct PulseEcho {
    /// 应答源 MAC（slirp 网关域）。
    pub sha: [u8; 6],
    /// 应答源 IP（应为 10.0.2.2）。
    pub spa: [u8; 4],
    /// 应答目标 MAC（命中闸内建断言，此处留证）。
    pub tha: [u8; 6],
    /// 交接统计快照（累计口径）。
    pub pushed: u64,
    /// 消费统计快照。
    pub popped: u64,
}

/// ARP 请求击发面（t69/t71 共用组帧）：TX 零垫 + 12 B 头 + ARP 请求域
/// + desc 发布 + 击发（队列 1）。
///
/// SAFETY: 前置 —— tx_buf 单帧恒等映射；vring 三表自 setup_queue；
///   单语境串行。
unsafe fn tx_arp_request(st: &mut NetState) {
    // SAFETY: 积压排空（前拍帧已读才许重写 tx_buf，同 tx_settle 注释）。
    unsafe { tx_settle(st) };
    // SAFETY: 同函数级注释（组帧域界内，发布序 desc → avail → kick）。
    unsafe {
        ostd::hw::phys::write_zero(st.tx_buf, 4096);
        let f = st.tx_buf + VNET_HDR as u64;
        poke(f, 0, &[0xFF; 6]); // dst 广播
        poke(f, 6, &st.mac); // src 本机
        poke(f, 12, &[0x08, 0x06]); // ethertype ARP
        poke(f, 14, &[0x00, 0x01]); // htype 以太网
        poke(f, 16, &[0x08, 0x00]); // ptype IPv4
        poke(f, 18, &[6, 4]); // hlen/plen
        poke(f, 20, &[0x00, 0x01]); // oper 请求
        poke(f, 22, &st.mac); // sha
        poke(f, 28, &MY_IP); // spa
        poke(f, 32, &[0u8; 6]); // tha 未知全零
        poke(f, 38, &GW_IP); // tpa 网关
        set_desc(st.tx.desc, 0, st.tx_buf, (VNET_HDR + ARP_TX_LEN) as u32, 0);
        push_avail(&mut st.tx, 0);
        kick(st.notify_base, st.notify_mult, 1, &st.tx);
    }
}

/// pulse 环交接活体（t71）：ARP 请求击发 → 轮询 [`rx_service`] 喂环 →
/// [`pulse_rx_pop`] 出队消费 → 应答五条闸（帧长足额 / 0806 / oper=2 /
/// tpa 寻我 / tha 寻我 MAC）。交接链「设备 → RX 缓冲 → pulse 环 →
/// 消费者」全活体；预算耗尽 / 态缺失返回 None（fail-closed）。
pub fn pulse_roundtrip() -> Option<PulseEcho> {
    let st = net_state_mut()?;
    // SAFETY: 态自 bring_up 登记；组帧/排水/重填全部界内（单语境）。
    unsafe { tx_arp_request(st) };
    let mut buf = [0u8; PULSE_FRAME_MAX];
    let mut spin = 0u64;
    while spin < ARP_SPIN_BUDGET {
        // SAFETY: 同上（排水 + 重填单语境界内）。
        unsafe { rx_service(st) };
        while let Some(fl) = pulse_rx_pop(&mut buf) {
            if fl < 42 {
                continue; // ARP 整帧 42 B 足额闸
            }
            let ethertype = u16::from_be_bytes([buf[12], buf[13]]);
            if ethertype != 0x0806 {
                continue; // 非 ARP（噪声帧）
            }
            let oper = u16::from_be_bytes([buf[20], buf[21]]);
            if oper != 2 {
                continue; // 非 ARP 应答
            }
            let mut sha = [0u8; 6];
            let mut spa = [0u8; 4];
            let mut tha = [0u8; 6];
            let mut tpa = [0u8; 4];
            sha.copy_from_slice(&buf[22..28]);
            spa.copy_from_slice(&buf[28..32]);
            tha.copy_from_slice(&buf[32..38]);
            tpa.copy_from_slice(&buf[38..42]);
            // 应答寻我 + 问我本机地址 → 命中（与 t69 命中闸同源）
            if tpa == MY_IP && tha == st.mac {
                return Some(PulseEcho {
                    sha,
                    spa,
                    tha,
                    pushed: PULSE_PUSHED.load(Ordering::Relaxed),
                    popped: PULSE_POPPED.load(Ordering::Relaxed),
                });
            }
        }
        spin += 1;
        core::hint::spin_loop();
    }
    None
}

// ===================== M24-C1：水位背压 + ICMP echo 面 =====================

/// 背压/水位快照（t73 证据行同源；累计口径）。
pub struct BpSnapshot {
    /// 背压投入次数（占用越 HI 计一次）。
    pub enters: u64,
    /// 背压解除次数（占用回 LO 计一次）。
    pub exits: u64,
    /// 累计重臂数（pending 归位 desc；投入态冻结 = 停臂证据）。
    pub rearmed: u64,
    /// 投入态现值。
    pub active: bool,
    /// pulse 环占用现值（`SpscRing::len`）。
    pub occ: usize,
}

/// 背压/水位面快照读出（单语境纪律下与 [`rx_service`] 无竞争）。
pub fn bp_snapshot() -> BpSnapshot {
    BpSnapshot {
        enters: RX_BP_ENTERS.load(Ordering::Relaxed),
        exits: RX_BP_EXITS.load(Ordering::Relaxed),
        rearmed: RX_REARMED.load(Ordering::Relaxed),
        active: RX_BP_ACTIVE.load(Ordering::Relaxed),
        occ: PULSE_RX.len(),
    }
}

/// ICMP 面快照（t73 证据行同源；累计口径）。
pub struct IcmpSnapshot {
    /// echo request 击发数。
    pub req_tx: u64,
    /// echo reply 应答器服务数。
    pub replies: u64,
}

/// ICMP 面快照读出。
pub fn icmp_snapshot() -> IcmpSnapshot {
    IcmpSnapshot {
        req_tx: ICMP_REQ_TX.load(Ordering::Relaxed),
        replies: ICMP_REPLIES.load(Ordering::Relaxed),
    }
}

/// RX 排水面单拍（安全封装）：背压语义内建（见 [`rx_service`] 文档）。
/// 返回本拍喂环成功数；投入态拍返回 0（短路）。单语境纪律同自检段
/// （SPSC 契约：本面 = 恰一生产者，[`pulse_rx_pop`] = 恰一消费者）。
pub fn rx_pump() -> usize {
    let Some(st) = net_state_mut() else {
        return 0;
    };
    // SAFETY: 态自 bring_up 登记；排水/重臂界内（单语境）。
    unsafe { rx_service(st) }
}

/// ARP 请求单拍击发（t73 背压突发相位用：逐发逐排，占用爬坡）。
/// 返回 false = 态缺失（fail-closed）。
pub fn arp_tx() -> bool {
    let Some(st) = net_state_mut() else {
        return false;
    };
    // SAFETY: 组帧/发布/击发界内（单语境）。
    unsafe { tx_arp_request(st) };
    true
}

/// TX 完成排水（安全封装）：used 环消费完成项数（击发收讫电气证据）。
pub fn tx_drain() -> usize {
    let Some(st) = net_state_mut() else {
        return 0;
    };
    let mut elems = [Done { id: 0, len: 0 }; 4];
    // SAFETY: tx used 环排水界内（单语境）。
    unsafe { drain_used(&mut st.tx, &mut elems) }
}

/// ARP 应答服务（C1 搭车面——入站可达前提）：who-has 我（oper 1 且
/// tpa == MY_IP）→ is-at 应答（sha=本机 MAC / spa=MY_IP / tha=请求方
/// sha / tpa=请求方 spa 原样回填）。slirp 反射回包对 10.0.2.15 的 ARP
/// 解析缓存未命中时会排队回包并发 who-has——本面应答即解阻塞。
/// 消费方对入帧调用即回；false = 非寻我请求或帧闸不过（fail-closed）。
pub fn arp_respond(request: &[u8]) -> bool {
    let Some(st) = net_state_mut() else {
        return false;
    };
    if request.len() < 42
        || u16::from_be_bytes([request[12], request[13]]) != 0x0806
        || u16::from_be_bytes([request[20], request[21]]) != 1
        || request[38..42] != MY_IP
    {
        return false;
    }
    let mut f = [0u8; ARP_TX_LEN];
    f[0..6].copy_from_slice(&request[6..12]); // eth dst = 请求方
    f[6..12].copy_from_slice(&st.mac);
    f[12..14].copy_from_slice(&0x0806u16.to_be_bytes());
    f[14..16].copy_from_slice(&0x0001u16.to_be_bytes()); // htype 以太网
    f[16..18].copy_from_slice(&0x0800u16.to_be_bytes()); // ptype IPv4
    f[18] = 6; // hlen
    f[19] = 4; // plen
    f[20..22].copy_from_slice(&0x0002u16.to_be_bytes()); // oper 应答
    f[22..28].copy_from_slice(&st.mac); // sha
    f[28..32].copy_from_slice(&MY_IP); // spa
    f[32..38].copy_from_slice(&request[22..28]); // tha = 请求方 sha
    f[38..42].copy_from_slice(&request[28..32]); // tpa = 请求方 spa
                                                 // SAFETY: 态自 bring_up 登记；ARP_TX_LEN = 60 零垫先例（单语境）。
    unsafe { tx_frame(st, &f, ARP_TX_LEN) };
    true
}

/// 16 位反码求和折叠（RFC 1071；大端字序——IP/ICMP 校验域同源）。
fn cksum_fold(data: &[u8]) -> u16 {
    let mut sum = 0u32;
    let mut i = 0;
    while i + 1 < data.len() {
        sum += u32::from(u16::from_be_bytes([data[i], data[i + 1]]));
        i += 2;
    }
    if i < data.len() {
        sum += u32::from(data[i]) << 8; // 尾奇字节按高字节补位
    }
    while sum >> 16 != 0 {
        sum = (sum & 0xFFFF) + (sum >> 16);
    }
    sum as u16
}

/// 校验和生成：反码求和后取反（`data` 中校验域须先置零）。
pub fn cksum16(data: &[u8]) -> u16 {
    !cksum_fold(data)
}

/// 校验和验证：含校验域的整段折叠求和应为全一（0xFFFF）。
pub fn cksum_ok(data: &[u8]) -> bool {
    cksum_fold(data) == 0xFFFF
}

/// C1 击发收讫闸：排空 tx used 环积压（前拍帧全部被设备消费）才允许
/// 重写 tx_buf。MTTCG 下 QEMU virtio-net TX 走 BH 异步读缓冲，单缓冲
/// 复用域乱入写即帧撕裂（实测双峰：同构突发帧免疫、异构首帧中招，
/// slirp 收残帧转 forward 路径 → 回包消失）。预算耗尽放行（fail-
/// open 仅限病态调度，正常域 MTTCG 主线程并行执行 BH 即时收讫）。
/// SAFETY: tx used 环排水界内（单语境）。
unsafe fn tx_settle(st: &mut NetState) {
    let mut spin = 0u64;
    while spin < ARP_SPIN_BUDGET {
        let mut done = [Done { id: 0, len: 0 }; 8];
        // SAFETY: tx used 环排水界内（同函数级注释）。
        if unsafe { drain_used(&mut st.tx, &mut done) } < done.len() {
            break; // 积压已清（返回数 < 容量 = 无余项）
        }
        spin += 1;
        core::hint::spin_loop();
    }
}

/// 通用帧击发面（C1：ICMP 同用）：收讫闸 → tx_buf 帧域零化 → 组帧
/// （VNET_HDR 垫头）→ desc 发布 → 击发（队列 1）。`frame` 为以太帧
/// 头起；`wire_len` ≥ frame.len()（差值域为零垫，ARP 最小帧先例）。
/// SAFETY: 前置 —— tx_buf 单帧恒等映射；frame.len() ≤ wire_len ≤
///   4096 - VNET_HDR（调用方契约）；vring 三表自 setup_queue；单语境
///   串行（收讫闸保证前拍帧已读，写域独占）。
/// 不变式 —— 发布序 desc → avail 环项 → avail.idx → kick。
unsafe fn tx_frame(st: &mut NetState, frame: &[u8], wire_len: usize) {
    // SAFETY: 积压排空（同函数级注释）。
    unsafe { tx_settle(st) };
    // 帧域界内零化（write_zero 自持安全契约；wire_len ≤ 4096 - VNET_HDR）
    ostd::hw::phys::write_zero(st.tx_buf, 4096);
    // SAFETY: 组帧界内（VNET_HDR + frame.len() ≤ 4096）。
    unsafe { poke(st.tx_buf + VNET_HDR as u64, 0, frame) };
    // SAFETY: desc 0 单帧发布 + 击发（发布序同 tx_arp_request）。
    unsafe {
        set_desc(st.tx.desc, 0, st.tx_buf, (VNET_HDR + wire_len) as u32, 0);
        push_avail(&mut st.tx, 0);
        kick(st.notify_base, st.notify_mult, 1, &st.tx);
    }
    // M25-C1-a 发后收讫（撕裂窗口关闭闸）：tx_settle 只能排空「已回写」
    // 积压，无法感知 BH 尚未回写的在途帧——MTTCG 下设备 BH 异步读
    // tx_buf 的窗口仍然敞开（t73 三连丢实证：同构异构混杂时前拍帧
    // 被后拍零化覆盖前未读完）。发后等本帧 used 回写（设备读走 tx_buf
    // 后才回写 used——virtio 消费契约），回写即窗口关闭，TX 面同步化。
    // 尽力域：预算内未回写放行（不堵 fail 面）；settle 保证 kick
    // 前 used 环空 → 首个回写项即本帧。预算 1M 轮（回写正常毫秒级；
    // ARP_SPIN_BUDGET 级 40M 轮在 TCG 下实为数十秒，撞 S8 看门狗）。
    const TX_SETTLE_SPIN: u64 = 1_000_000;
    let mut spin = 0u64;
    while spin < TX_SETTLE_SPIN {
        let mut done = [Done { id: 0, len: 0 }; 8];
        // SAFETY: tx used 环排水界内（同函数级注释）。
        if unsafe { drain_used(&mut st.tx, &mut done) } > 0 {
            break;
        }
        spin += 1;
        core::hint::spin_loop();
    }
}

/// ICMP echo request 击发（t73 相位面）：组帧（以太 + IPv4 + ICMP
/// echo，头部校验和自算）→ [`tx_frame`]。返回 false = 态缺失或组帧
/// 越界（fail-closed）。帧长上限 = [`PULSE_FRAME_MAX`]。
pub fn icmp_echo_tx(dst_mac: [u8; 6], dst_ip: [u8; 4], id: u16, seq: u16, payload: &[u8]) -> bool {
    let Some(st) = net_state_mut() else {
        return false;
    };
    let ip_total = 20 + 8 + payload.len();
    let flen = 14 + ip_total;
    if flen > PULSE_FRAME_MAX {
        return false;
    }
    let mut f = [0u8; PULSE_FRAME_MAX];
    f[0..6].copy_from_slice(&dst_mac);
    f[6..12].copy_from_slice(&st.mac);
    f[12..14].copy_from_slice(&0x0800u16.to_be_bytes());
    f[14] = 0x45; // v4 / IHL 5
    f[16..18].copy_from_slice(&(ip_total as u16).to_be_bytes());
    f[22] = 64; // TTL
    f[23] = 1; // proto = ICMP
    f[26..30].copy_from_slice(&MY_IP);
    f[30..34].copy_from_slice(&dst_ip);
    let ip_ck = cksum16(&f[14..34]);
    f[24..26].copy_from_slice(&ip_ck.to_be_bytes());
    f[34] = 8; // type = echo request
    f[38..40].copy_from_slice(&id.to_be_bytes());
    f[40..42].copy_from_slice(&seq.to_be_bytes());
    f[42..flen].copy_from_slice(payload);
    let icmp_ck = cksum16(&f[34..flen]);
    f[36..38].copy_from_slice(&icmp_ck.to_be_bytes());
    ICMP_REQ_TX.fetch_add(1, Ordering::Relaxed);
    // SAFETY: 态自 bring_up 登记；flen ≤ PULSE_FRAME_MAX 界内（单语境）。
    unsafe { tx_frame(st, &f[..flen], flen) };
    true
}

/// ICMP echo 应答组帧（纯函数，无 TX 无计数——字节级断言面与
/// [`icmp_echo_reply`] 同源）：echo request → echo reply（以太/IP 双
/// 交换，id/seq/payload 保真，IP/ICMP 校验和重算）。返回写入长度。
/// 请求闸（0800 / IPv4 IHL 足额 / proto 1 / 寻我 / type 8 / IP 总长
/// 对账 / 双校验和验证）不过 → None（fail-closed）。
pub fn build_icmp_reply(req: &[u8], out: &mut [u8]) -> Option<usize> {
    if req.len() < 14 + 20 + 8 {
        return None;
    }
    if u16::from_be_bytes([req[12], req[13]]) != 0x0800 {
        return None;
    }
    if req[14] >> 4 != 4 {
        return None;
    }
    let ihl = usize::from(req[14] & 0x0F) * 4;
    if ihl < 20 || req.len() < 14 + ihl + 8 {
        return None;
    }
    if req[23] != 1 {
        return None; // proto 非 ICMP
    }
    if u16::from_be_bytes([req[16], req[17]]) as usize != req.len() - 14 {
        return None; // IP 总长与帧长对账
    }
    if !cksum_ok(&req[14..14 + ihl]) {
        return None; // IP 校验和
    }
    let ic = 14 + ihl;
    if req[ic] != 8 || req[ic + 1] != 0 {
        return None; // 非 echo request
    }
    if req[30..34] != MY_IP {
        return None; // 不寻我（不应答他人 ping）
    }
    if !cksum_ok(&req[ic..]) {
        return None; // ICMP 校验和
    }
    let icmp_len = req.len() - ic;
    let out_len = ic + icmp_len;
    if out.len() < out_len {
        return None;
    }
    out[6..12].copy_from_slice(&req[0..6]); // eth dst = 请求方
    out[0..6].copy_from_slice(&req[6..12]); // eth src = 本机（请求 dst）
    out[12..14].copy_from_slice(&0x0800u16.to_be_bytes());
    out[14..14 + ihl].copy_from_slice(&req[14..14 + ihl]);
    out[26..30].copy_from_slice(&req[30..34]); // IP src = 我
    out[30..34].copy_from_slice(&req[26..30]); // IP dst = 请求方
    out[24..26].copy_from_slice(&[0, 0]); // 旧校验域清零后重算
    let ip_ck = cksum16(&out[14..14 + ihl]);
    out[24..26].copy_from_slice(&ip_ck.to_be_bytes());
    out[ic..out_len].copy_from_slice(&req[ic..out_len]);
    out[ic] = 0; // type = echo reply
    out[ic + 2..ic + 4].copy_from_slice(&[0, 0]); // 旧校验域清零后重算
    let ic_ck = cksum16(&out[ic..out_len]);
    out[ic + 2..ic + 4].copy_from_slice(&ic_ck.to_be_bytes());
    Some(out_len)
}

/// ICMP echo reply 应答服务（C1 交付面）：echo request 帧 →
/// [`build_icmp_reply`] → [`tx_frame`] 击发。消费方（自检 / M24 起网络
/// 服务）对入帧 type8 调用即回；None = 请求闸不过或态缺失。
pub fn icmp_echo_reply(request: &[u8]) -> Option<usize> {
    let st = net_state_mut()?;
    let mut out = [0u8; PULSE_FRAME_MAX];
    let n = build_icmp_reply(request, &mut out)?;
    // SAFETY: 态自 bring_up 登记；n ≤ PULSE_FRAME_MAX 界内（单语境）。
    unsafe { tx_frame(st, &out[..n], n) };
    ICMP_REPLIES.fetch_add(1, Ordering::Relaxed);
    Some(n)
}

// ===================== M27-N2：UDP 回环面（pulse::udp 消费） =====================

/// 端口绑定表容量（t78 活体 + 未来网络服务预留域）。
const UDP_PORT_CAP: usize = 16;

/// 端口绑定表（单语境 static；[`PortTable::new`] 为 const——无 init 序
/// 问题。访问纪律同 [`NET_STATE`]：kmain 自检串行段 + &raw 手法）。
static mut UDP_PORTS: PortTable<UDP_PORT_CAP> = PortTable::new();

/// 端口表句柄（&raw 手法统一入口；static 直挂无缺失态——None 结构性
/// 不可达，match 保 fail-visible 形状）。
fn udp_ports_mut() -> Option<&'static mut PortTable<UDP_PORT_CAP>> {
    // SAFETY: 单语境（kmain 自检串行段）独占访问；&raw 手法不建立
    //         static 引用（static_mut_refs 免疫）。
    unsafe { (&raw mut UDP_PORTS).as_mut() }
}

/// UDP 接收槽（v0 单槽最近报——多报队列扩容挂账偏差登记，M27-T1 后
/// 随服务化批次重审）。t78 单发单收语义恰好承载。
struct UdpRxSlot {
    /// 源端口（回环发方）。
    src_port: u16,
    /// 载荷长。
    len: usize,
    /// 载荷（UDP 段 data 域原样）。
    data: [u8; MAX_PAYLOAD],
}

/// 接收槽（单语境 static；None = 空）。
static mut UDP_RX_SLOT: Option<UdpRxSlot> = None;

/// 接收槽句柄（&raw 手法同款纪律）。
fn udp_slot_take() -> Option<UdpRxSlot> {
    // SAFETY: 单语境独占；&raw 手法不建立 static 引用。
    unsafe { (&raw mut UDP_RX_SLOT).as_mut()?.take() }
}

/// 回环注入计数（交接环 send 成功）。
static UDP_INJECTED: AtomicU64 = AtomicU64::new(0);
/// 分派采纳计数（全闸通过 + 端口命中 + 槽写入）。
static UDP_ACCEPTED: AtomicU64 = AtomicU64::new(0);
/// 校验和拒收计数（fail-visible：伪头验证不过）。
static UDP_BAD_CS: AtomicU64 = AtomicU64::new(0);
/// 未绑定端口拒投计数（fail-visible：路由失败不静默）。
static UDP_NO_PORT: AtomicU64 = AtomicU64::new(0);

/// UDP 面统计快照（t78 证据行同源；累计口径）。
#[derive(Debug, Clone, Copy)]
pub struct UdpStats {
    /// 回环注入数。
    pub injected: u64,
    /// 分派采纳数。
    pub accepted: u64,
    /// 校验和拒收数。
    pub bad_cs: u64,
    /// 未绑定端口拒投数。
    pub no_port: u64,
}

/// UDP 面统计读出。
pub fn udp_stats() -> UdpStats {
    UdpStats {
        injected: UDP_INJECTED.load(Ordering::Relaxed),
        accepted: UDP_ACCEPTED.load(Ordering::Relaxed),
        bad_cs: UDP_BAD_CS.load(Ordering::Relaxed),
        no_port: UDP_NO_PORT.load(Ordering::Relaxed),
    }
}

/// 绑定 UDP 端口（pulse [`PortTable`] 消费面）。
pub fn udp_bind(port: u16) -> Result<(), pulse::udp::BindError> {
    match udp_ports_mut() {
        Some(t) => t.bind(port),
        // 结构性不可达（static 直挂）；形状保 fail-visible
        None => Err(pulse::udp::BindError::Reserved),
    }
}

/// 解绑 UDP 端口。
pub fn udp_unbind(port: u16) -> Result<(), pulse::udp::BindError> {
    match udp_ports_mut() {
        Some(t) => t.unbind(port),
        None => Err(pulse::udp::BindError::Reserved),
    }
}

/// UDP 帧级分派（接收路径同构逻辑，t78 回环消费者调用）：闸链
/// 0800 / IPv4 / IHL / proto 17 / IP 总长对账 / IP 校验和 / 寻我 →
/// pulse 段解析 + 伪头校验和验证 → 端口表路由 → 接收槽写入。
/// 返回采纳载荷长；任一闸不过 None（计数分域 fail-visible）。
pub fn udp_dispatch(frame: &[u8]) -> Option<usize> {
    if frame.len() < 14 + 20 + 8 {
        return None;
    }
    if u16::from_be_bytes([frame[12], frame[13]]) != 0x0800 {
        return None;
    }
    if frame[14] >> 4 != 4 {
        return None;
    }
    let ihl = usize::from(frame[14] & 0x0F) * 4;
    if ihl < 20 || frame.len() < 14 + ihl + 8 {
        return None;
    }
    if frame[23] != PROTO_UDP {
        return None;
    }
    if u16::from_be_bytes([frame[16], frame[17]]) as usize != frame.len() - 14 {
        return None; // IP 总长与帧长对账
    }
    if !cksum_ok(&frame[14..14 + ihl]) {
        return None; // IP 校验和
    }
    if frame[30..34] != MY_IP {
        return None; // 不寻我
    }
    let src_ip = [frame[26], frame[27], frame[28], frame[29]];
    let seg = &frame[14 + ihl..];
    let (h, payload) = pulse::udp::UdpHdr::parse(seg)?;
    if !pulse::udp::verify(src_ip, MY_IP, seg) {
        UDP_BAD_CS.fetch_add(1, Ordering::Relaxed);
        return None;
    }
    let bound = udp_ports_mut().is_some_and(|t| t.is_bound(h.dst_port));
    if !bound {
        UDP_NO_PORT.fetch_add(1, Ordering::Relaxed);
        return None;
    }
    // 槽写入（v0 单槽最近报；越界载荷已被 parse 的 length 对账闸拒）
    let mut slot = UdpRxSlot {
        src_port: h.src_port,
        len: payload.len(),
        data: [0; MAX_PAYLOAD],
    };
    slot.data[..payload.len()].copy_from_slice(payload);
    // SAFETY: 单语境独占；&raw 手法不建立 static 引用。
    unsafe {
        if let Some(s) = (&raw mut UDP_RX_SLOT).as_mut() {
            *s = Some(slot);
        }
    }
    UDP_ACCEPTED.fetch_add(1, Ordering::Relaxed);
    Some(payload.len())
}

/// UDP 回环击发（t78 相位面）：pulse 段组帧 + 伪头校验和 → 完整以太帧
/// （以太 + IPv4，dst MAC/IP = 本机自环）→ 交接环直注（回环注入点 =
/// [`PULSE_RX`]——与真实 RX 通路共享交接段，设备 DMA 之外的完全同构；
/// R1 限流后真实通路结构零丢弃，回环面 send Err 同为结构违背显形）。
/// 返回 false = 态缺失/组帧越界/环满（fail-closed）。
pub fn udp_loopback_tx(src_port: u16, dst_port: u16, payload: &[u8]) -> bool {
    if net_state_mut().is_none() {
        return false;
    }
    let mut seg = [0u8; MAX_PAYLOAD + 8];
    let Some(seg_len) = pulse::udp::UdpHdr::encode(src_port, dst_port, payload, &mut seg) else {
        return false;
    };
    let cs = pulse::udp::checksum(MY_IP, MY_IP, &seg[..seg_len]);
    seg[6..8].copy_from_slice(&cs.to_be_bytes());
    let ip_total = 20 + seg_len;
    let flen = 14 + ip_total;
    if flen > PULSE_FRAME_MAX {
        return false;
    }
    let mut f = [0u8; PULSE_FRAME_MAX];
    let st_mac = net_state_mut().map(|st| st.mac).unwrap_or([0; 6]);
    f[0..6].copy_from_slice(&st_mac); // 回环：dst = 本机
    f[6..12].copy_from_slice(&st_mac); // src = 本机
    f[12..14].copy_from_slice(&0x0800u16.to_be_bytes());
    f[14] = 0x45;
    f[16..18].copy_from_slice(&(ip_total as u16).to_be_bytes());
    f[22] = 64;
    f[23] = PROTO_UDP;
    f[26..30].copy_from_slice(&MY_IP);
    f[30..34].copy_from_slice(&MY_IP); // 回环：dst IP = 本机
    let ip_ck = cksum16(&f[14..34]);
    f[24..26].copy_from_slice(&ip_ck.to_be_bytes());
    f[34..34 + seg_len].copy_from_slice(&seg[..seg_len]);
    let slot = FrameSlot {
        len: flen as u16,
        _pad: [0; 6],
        data: {
            let mut d = [0u8; PULSE_FRAME_MAX];
            d[..flen].copy_from_slice(&f[..flen]);
            d
        },
    };
    match PULSE_RX.send(slot) {
        Ok(()) => {
            UDP_INJECTED.fetch_add(1, Ordering::Relaxed);
            true
        }
        Err(_) => false,
    }
}

/// UDP 接收（消费面）：取接收槽（take 语义，逐报消费）——载荷拷入
/// `out`，返回 (源端口, 载荷长)；None = 槽空。
pub fn udp_recv(out: &mut [u8]) -> Option<(u16, usize)> {
    let slot = udp_slot_take()?;
    let n = slot.len.min(out.len());
    out[..n].copy_from_slice(&slot.data[..n]);
    Some((slot.src_port, slot.len))
}

// ===================== M36-N1：TCP 回环面（pulse::tcp 消费） =====================

/// TCP 段载荷上限（t86 单段对话面 + t89 重组窗域；pulse [`pulse::tcp::ReasmBuf`]
/// 实例化同径——M37-N1 重传面本笔落位）。
pub const TCP_SEG_MAX: usize = 512;

/// 端口绑定表容量（t86 活体 + 未来 TCP 服务预留域）。
const TCP_PORT_CAP: usize = 16;

/// 端口绑定表（单语境 static；访问纪律同 [`UDP_PORTS`]）。
static mut TCP_PORTS: PortTable<TCP_PORT_CAP> = PortTable::new();

/// 端口表句柄（&raw 手法同 [`udp_ports_mut`] 纪律）。
fn tcp_ports_mut() -> Option<&'static mut PortTable<TCP_PORT_CAP>> {
    // SAFETY: 单语境（kmain 自检串行段）独占访问；&raw 手法不建立
    //         static 引用（static_mut_refs 免疫）。
    unsafe { (&raw mut TCP_PORTS).as_mut() }
}

/// TCP 接收段槽（v0 单槽最近段——头域 + 载荷原样；多连接队列扩容随
/// 服务化批次挂账，UDP 单槽先例同构）。
pub struct TcpRxSeg {
    /// 源端口。
    pub src_port: u16,
    /// 目的端口。
    pub dst_port: u16,
    /// 发送序号。
    pub seq: u32,
    /// 确认序号。
    pub ack_seq: u32,
    /// 控制位。
    pub flags: u16,
    /// 接收窗口。
    pub window: u16,
    /// 载荷长。
    pub len: usize,
    /// 载荷（段 data 域原样）。
    pub data: [u8; TCP_SEG_MAX],
}

/// 接收槽（单语境 static；None = 空）。
static mut TCP_RX_SLOT: Option<TcpRxSeg> = None;

/// 接收槽句柄（&raw 手法同款纪律）。
fn tcp_slot_take() -> Option<TcpRxSeg> {
    // SAFETY: 单语境独占；&raw 手法不建立 static 引用。
    unsafe { (&raw mut TCP_RX_SLOT).as_mut()?.take() }
}

/// TCP 回环注入计数（交接环 send 成功）。
static TCP_INJECTED: AtomicU64 = AtomicU64::new(0);
/// 分派采纳计数（全闸通过 + 端口命中 + 槽写入）。
static TCP_ACCEPTED: AtomicU64 = AtomicU64::new(0);
/// 校验和拒收计数（fail-visible：伪头验证不过）。
static TCP_BAD_CS: AtomicU64 = AtomicU64::new(0);
/// 未绑定端口拒投计数（fail-visible：路由失败不静默）。
static TCP_NO_PORT: AtomicU64 = AtomicU64::new(0);
/// 外部 TX 计数（ARP 解析 + virtio 击发成功）。
static TCP_EXT_TX: AtomicU64 = AtomicU64::new(0);
/// M37-N1 重传拍计数（RTO 到期电重发实际击发——回环通路）。
static TCP_RETX: AtomicU64 = AtomicU64::new(0);
/// M37-N1 重发击发失败计数（环满/态缺失——fail-visible 不静默）。
static TCP_RETX_MISS: AtomicU64 = AtomicU64::new(0);
/// M37-N1 乱序重组缓存计数（Queued 受理——段进窗待洞）。
static TCP_REASM_QUEUED: AtomicU64 = AtomicU64::new(0);
/// M37-N1 外部 RX 对接收口计数（外部形段注入共享交接环成功——
/// M27-T1 既登记「外部 RX 对接面」随本笔收口）。
static TCP_EXT_RX: AtomicU64 = AtomicU64::new(0);

/// TCP 面统计快照（t86/t89 证据行同源；累计口径）。
#[derive(Debug, Clone, Copy)]
pub struct TcpStats {
    /// 回环注入数。
    pub injected: u64,
    /// 分派采纳数。
    pub accepted: u64,
    /// 校验和拒收数。
    pub bad_cs: u64,
    /// 未绑定端口拒投数。
    pub no_port: u64,
    /// 外部 TX 击发数。
    pub ext_tx: u64,
    /// M37-N1 重传拍击发数（RTO 到期电重发——回环通路）。
    pub retx: u64,
    /// M37-N1 重发击发失败数（fail-visible）。
    pub retx_miss: u64,
    /// M37-N1 乱序重组缓存数（Queued 受理）。
    pub reasm_queued: u64,
    /// M37-N1 外部 RX 形段注入数（对接收口）。
    pub ext_rx: u64,
    /// M38-TCP1 零窗探测拍电击发数（Probe 回环击发——una 起 1 字节）。
    pub probe: u64,
}

/// TCP 面统计读出。
pub fn tcp_stats() -> TcpStats {
    TcpStats {
        injected: TCP_INJECTED.load(Ordering::Relaxed),
        accepted: TCP_ACCEPTED.load(Ordering::Relaxed),
        bad_cs: TCP_BAD_CS.load(Ordering::Relaxed),
        no_port: TCP_NO_PORT.load(Ordering::Relaxed),
        ext_tx: TCP_EXT_TX.load(Ordering::Relaxed),
        retx: TCP_RETX.load(Ordering::Relaxed),
        retx_miss: TCP_RETX_MISS.load(Ordering::Relaxed),
        reasm_queued: TCP_REASM_QUEUED.load(Ordering::Relaxed),
        ext_rx: TCP_EXT_RX.load(Ordering::Relaxed),
        probe: TCP_PROBE.load(Ordering::Relaxed),
    }
}

/// 绑定 TCP 端口（pulse [`PortTable`] 消费面）。
pub fn tcp_bind(port: u16) -> Result<(), pulse::udp::BindError> {
    match tcp_ports_mut() {
        Some(t) => t.bind(port),
        None => Err(pulse::udp::BindError::Reserved),
    }
}

/// 解绑 TCP 端口。
pub fn tcp_unbind(port: u16) -> Result<(), pulse::udp::BindError> {
    match tcp_ports_mut() {
        Some(t) => t.unbind(port),
        None => Err(pulse::udp::BindError::Reserved),
    }
}

/// TCP 帧级分派（接收路径全闸链，t86 回环消费者 + 真实 RX proto 6
/// 分流共用）：0800 / IPv4 / IHL / proto 6 / IP 总长对账 / IP 校验和 /
/// 寻我 → pulse 段解析 + 伪头校验和验证 → 端口表路由 → **重组或槽写入**
/// （M37-N1：播种态非空载荷走 [`TCP_REASM`] 乱序重组——InOrder 前缀
/// 连通即拼接交付；未播种/空载荷直通单槽 = t86 语义逐位保持）。
/// 返回采纳载荷长（段自身域——重组拼接交付可超该值，证据行显形）；
/// 任一闸不过 None（计数分域 fail-visible）。
pub fn tcp_dispatch(frame: &[u8]) -> Option<usize> {
    if frame.len() < 14 + 20 + 20 {
        return None;
    }
    if u16::from_be_bytes([frame[12], frame[13]]) != 0x0800 {
        return None;
    }
    if frame[14] >> 4 != 4 {
        return None;
    }
    let ihl = usize::from(frame[14] & 0x0F) * 4;
    if ihl < 20 || frame.len() < 14 + ihl + 20 {
        return None;
    }
    if frame[23] != pulse::tcp::PROTO_TCP {
        return None;
    }
    if u16::from_be_bytes([frame[16], frame[17]]) as usize != frame.len() - 14 {
        return None; // IP 总长与帧长对账
    }
    if !cksum_ok(&frame[14..14 + ihl]) {
        return None; // IP 校验和
    }
    if frame[30..34] != MY_IP {
        return None; // 不寻我
    }
    let src_ip = [frame[26], frame[27], frame[28], frame[29]];
    let seg = &frame[14 + ihl..];
    let (h, payload) = pulse::tcp::TcpHdr::parse(seg)?;
    if !pulse::tcp::verify(src_ip, MY_IP, seg) {
        TCP_BAD_CS.fetch_add(1, Ordering::Relaxed);
        return None;
    }
    let bound = tcp_ports_mut().is_some_and(|t| t.is_bound(h.dst_port));
    if !bound {
        TCP_NO_PORT.fetch_add(1, Ordering::Relaxed);
        return None;
    }
    let n = payload.len().min(TCP_SEG_MAX);
    // M37-N1 播种态非空载荷：乱序重组面接管（四态判定——InOrder 前缀
    // 连通即 drain 拼接交付；Queued 缓存待洞；Old/Overflow 段级拒收
    // ——v0 整段拒偏差登记）。未播种/空载荷直通槽 = t86 逐位同构
    // 回归锚；重组账面缺失（结构性不可达）同域回退直通槽。
    let reasm_hit = tcp_reasm_is_seeded() && !payload.is_empty();
    if reasm_hit {
        if let Some(outcome) = tcp_reasm_with(|q| q.insert(h.seq, payload)) {
            TCP_ACCEPTED.fetch_add(1, Ordering::Relaxed);
            return match outcome {
                pulse::tcp::ReasmOutcome::InOrder => {
                    // 前缀连通：拼接交付（可含此前 Queued 段——字节级
                    // 对账域；触发段头域随槽取证，载荷长为段自身域）。
                    // 零交付 = 结构性不可达（防御面：不写空槽）。
                    let mut slot = TcpRxSeg {
                        src_port: h.src_port,
                        dst_port: h.dst_port,
                        seq: h.seq,
                        ack_seq: h.ack_seq,
                        flags: h.flags,
                        window: h.window,
                        len: 0,
                        data: [0; TCP_SEG_MAX],
                    };
                    match tcp_reasm_with(|q| q.drain(&mut slot.data)) {
                        Some(d) if d > 0 => {
                            slot.len = d;
                            write_rx_slot(slot);
                        }
                        _ => {}
                    }
                    Some(payload.len())
                }
                pulse::tcp::ReasmOutcome::Queued => {
                    TCP_REASM_QUEUED.fetch_add(1, Ordering::Relaxed);
                    Some(payload.len())
                }
                pulse::tcp::ReasmOutcome::Old | pulse::tcp::ReasmOutcome::Overflow => {
                    Some(payload.len())
                }
            };
        }
    }
    let mut slot = TcpRxSeg {
        src_port: h.src_port,
        dst_port: h.dst_port,
        seq: h.seq,
        ack_seq: h.ack_seq,
        flags: h.flags,
        window: h.window,
        len: n,
        data: [0; TCP_SEG_MAX],
    };
    slot.data[..n].copy_from_slice(&payload[..n]);
    write_rx_slot(slot);
    TCP_ACCEPTED.fetch_add(1, Ordering::Relaxed);
    Some(payload.len())
}

/// TCP 回环击发（t86 相位面）：pulse 段编码 + 伪头校验和（[`pulse::tcp::checksum`]
/// ——与 UDP 共用折叠核心的 proto 6 参数化面）→ 完整以太帧（以太 + IPv4，
/// dst MAC/IP = 本机自环）→ 交接环直注（回环注入点 = [`PULSE_RX`]——与真实
/// RX 通路共享交接段，设备 DMA 之外的完全同构；UDP 回环先例同款）。
/// 返回 false = 态缺失/组帧越界/环满（fail-closed）。
#[allow(clippy::too_many_arguments)]
pub fn tcp_loopback_tx(
    src_port: u16,
    dst_port: u16,
    seq: u32,
    ack_seq: u32,
    flags: u16,
    window: u16,
    payload: &[u8],
) -> bool {
    if net_state_mut().is_none() {
        return false;
    }
    let mut seg = [0u8; 20 + TCP_SEG_MAX];
    let Some(seg_len) = pulse::tcp::TcpHdr::encode(
        src_port, dst_port, seq, ack_seq, flags, window, payload, &mut seg,
    ) else {
        return false;
    };
    let cs = pulse::tcp::checksum(MY_IP, MY_IP, &seg[..seg_len]);
    seg[16..18].copy_from_slice(&cs.to_be_bytes());
    let ip_total = 20 + seg_len;
    let flen = 14 + ip_total;
    if flen > PULSE_FRAME_MAX {
        return false;
    }
    let mut f = [0u8; PULSE_FRAME_MAX];
    let st_mac = net_state_mut().map(|st| st.mac).unwrap_or([0; 6]);
    f[0..6].copy_from_slice(&st_mac); // 回环：dst = 本机
    f[6..12].copy_from_slice(&st_mac); // src = 本机
    f[12..14].copy_from_slice(&0x0800u16.to_be_bytes());
    f[14] = 0x45;
    f[16..18].copy_from_slice(&(ip_total as u16).to_be_bytes());
    f[22] = 64;
    f[23] = pulse::tcp::PROTO_TCP;
    f[26..30].copy_from_slice(&MY_IP);
    f[30..34].copy_from_slice(&MY_IP); // 回环：dst IP = 本机
    let ip_ck = cksum16(&f[14..34]);
    f[24..26].copy_from_slice(&ip_ck.to_be_bytes());
    f[34..34 + seg_len].copy_from_slice(&seg[..seg_len]);
    let slot = FrameSlot {
        len: flen as u16,
        _pad: [0; 6],
        data: {
            let mut d = [0u8; PULSE_FRAME_MAX];
            d[..flen].copy_from_slice(&f[..flen]);
            d
        },
    };
    match PULSE_RX.send(slot) {
        Ok(()) => {
            TCP_INJECTED.fetch_add(1, Ordering::Relaxed);
            true
        }
        Err(_) => false,
    }
}

/// TCP 接收（消费面）：取接收段槽（take 语义，逐段消费）。
pub fn tcp_recv() -> Option<TcpRxSeg> {
    tcp_slot_take()
}

/// 接收槽写入（&raw 手法同 [`tcp_slot_take`] 纪律）。
fn write_rx_slot(slot: TcpRxSeg) {
    // SAFETY: 单语境独占；&raw 手法不建立 static 引用。
    unsafe {
        if let Some(s) = (&raw mut TCP_RX_SLOT).as_mut() {
            *s = Some(slot);
        }
    }
}

// ===================== M37-N1：TCP 重传面（TSC 纳秒定时器 + 滑窗 + 重组电气） =====================
//
// pulse::tcp 协议机纵深（[`pulse::tcp::RtoTimer`]/[`pulse::tcp::SendWindow`]/
// [`pulse::tcp::ReasmBuf`] 纯函数面）的 kernel::vnet 电气承接：重传臂
// 模板电重发（回环通路）+ 乱序重组窗播种接管（分派链 InOrder 前缀拼接
// 交付）+ 外部 RX 对接收口（外部形段直注共享交接环——M27-T1 既登记
// 「外部 RX 对接面」随本笔收口）。v0 单流单臂单窗（多连接扩容随服务化
// 批次挂账——M36-N1 单段槽先例同构口径）。

/// 单流乱序重组窗（t89 播种域；未播种分派直通槽 = t86 逐位同构回归锚）。
static mut TCP_REASM: pulse::tcp::ReasmBuf<TCP_SEG_MAX> = pulse::tcp::ReasmBuf::new(0);
/// 重组窗播种旗（false = 分派直通槽）。
static mut TCP_REASM_SEED: bool = false;
/// RTO 重传臂（TSC 纳秒域——[`crate::timer::mononow_ns`] 同源单调面；
/// 合成时刻面 `*_at` 版本供 t89 确定性驱动）。
static mut TCP_RTO: pulse::tcp::RtoTimer = pulse::tcp::RtoTimer::new();
/// 重传臂模板段（电重发载体——组帧参数原样定格；None = 无臂）。
struct RetxTpl {
    src_port: u16,
    dst_port: u16,
    seq: u32,
    ack_seq: u32,
    flags: u16,
    window: u16,
    payload: [u8; TCP_SEG_MAX],
    len: usize,
}
static mut TCP_RETX_TPL: Option<RetxTpl> = None;

/// 重组窗账面访问（&raw 手法同款纪律；闭包承载 pulse 面操作）。
fn tcp_reasm_with<R>(f: impl FnOnce(&mut pulse::tcp::ReasmBuf<TCP_SEG_MAX>) -> R) -> Option<R> {
    // SAFETY: 单语境独占（kmain 自检串行段）；&raw 手法不建立 static 引用。
    unsafe { (&raw mut TCP_REASM).as_mut().map(f) }
}

/// 重组窗播种旗读出。
fn tcp_reasm_is_seeded() -> bool {
    // SAFETY: 单语境独占；&raw 手法不建立 static 引用。
    unsafe { (&raw mut TCP_REASM_SEED).as_ref().is_some_and(|s| *s) }
}

/// 重组窗播种（接收基线 rcv_nxt 定格——单流 v0；重复播种 = 重置窗口
/// 新基线，t89 相位间隔离用）。
pub fn tcp_reasm_seed(rcv_nxt: u32) {
    // SAFETY: 单语境独占；&raw 手法不建立 static 引用。
    unsafe {
        if let Some(q) = (&raw mut TCP_REASM).as_mut() {
            *q = pulse::tcp::ReasmBuf::new(rcv_nxt);
        }
        if let Some(s) = (&raw mut TCP_REASM_SEED).as_mut() {
            *s = true;
        }
    }
}

/// 重组窗停用（回退直通槽语义——t86 回归锚复位）。
pub fn tcp_reasm_unseed() {
    // SAFETY: 单语境独占；&raw 手法不建立 static 引用。
    unsafe {
        if let Some(s) = (&raw mut TCP_REASM_SEED).as_mut() {
            *s = false;
        }
    }
}

/// 重组窗读数：Some((基线 rcv_nxt, 在窗缓存字节))；未播种 None。
pub fn tcp_reasm_state() -> Option<(u32, usize)> {
    if !tcp_reasm_is_seeded() {
        return None;
    }
    tcp_reasm_with(|q| (q.rcv_nxt(), q.pending()))
}

/// 重传臂武装（合成时刻版——t89 确定性驱动面）：模板定格 + RTO 首臂。
/// payload > [`TCP_SEG_MAX`] 时 fail-visible 拒臂（模板载荷定容域）。
/// 返回 true = 臂成（模板定格 + 定时器武装）。
#[allow(clippy::too_many_arguments)]
pub fn tcp_retx_arm_at(
    now_ns: u64,
    src_port: u16,
    dst_port: u16,
    seq: u32,
    ack_seq: u32,
    flags: u16,
    window: u16,
    payload: &[u8],
) -> bool {
    if payload.len() > TCP_SEG_MAX {
        return false;
    }
    let tpl = RetxTpl {
        src_port,
        dst_port,
        seq,
        ack_seq,
        flags,
        window,
        payload: {
            let mut d = [0u8; TCP_SEG_MAX];
            d[..payload.len()].copy_from_slice(payload);
            d
        },
        len: payload.len(),
    };
    // SAFETY: 单语境独占；&raw 手法不建立 static 引用。
    unsafe {
        if let Some(t) = (&raw mut TCP_RETX_TPL).as_mut() {
            *t = Some(tpl);
        }
        if let Some(r) = (&raw mut TCP_RTO).as_mut() {
            r.arm(now_ns, seq);
        }
    }
    true
}

/// 重传拍（合成时刻版）：RTO 到期判定 → Due 时模板电重发（回环通路——
/// [`tcp_loopback_tx`] 同构组帧，段参数原样定格）→ [`TCP_RETX`] 计数
/// 显形；击发失败（环满/态缺失）[`TCP_RETX_MISS`] 计数 fail-visible。
/// Exhausted 时同步弃模板（拆除判定交消费方）。
pub fn tcp_retx_poll_at(now_ns: u64) -> pulse::tcp::RtoDecision {
    let decision = {
        // SAFETY: 单语境独占；&raw 手法不建立 static 引用。
        unsafe { (&raw mut TCP_RTO).as_mut() }
            .map(|r| r.poll(now_ns))
            .unwrap_or(pulse::tcp::RtoDecision::Idle)
    };
    if decision == pulse::tcp::RtoDecision::Due {
        let fired = {
            // SAFETY: 单语境独占；&raw 手法不建立 static 引用。
            unsafe { (&raw mut TCP_RETX_TPL).as_ref() }
                .and_then(|t| t.as_ref())
                .is_some_and(|t| {
                    tcp_loopback_tx(
                        t.src_port,
                        t.dst_port,
                        t.seq,
                        t.ack_seq,
                        t.flags,
                        t.window,
                        &t.payload[..t.len],
                    )
                })
        };
        if fired {
            TCP_RETX.fetch_add(1, Ordering::Relaxed);
        } else {
            TCP_RETX_MISS.fetch_add(1, Ordering::Relaxed);
        }
    } else if decision == pulse::tcp::RtoDecision::Exhausted {
        // 耗尽弃模板（fail-visible——消费方拆除判定随行）
        // SAFETY: 单语境独占；&raw 手法不建立 static 引用。
        unsafe {
            if let Some(t) = (&raw mut TCP_RETX_TPL).as_mut() {
                *t = None;
            }
        }
    }
    decision
}

/// 重传臂 ACK 清账：`ack` 越过武装段首序号 → 解除武装 + 退避复位 +
/// 模板弃置。返回 true = 本臂已清。
pub fn tcp_retx_clear(ack_seq: u32) -> bool {
    let cleared = {
        // SAFETY: 单语境独占；&raw 手法不建立 static 引用。
        unsafe { (&raw mut TCP_RTO).as_mut() }
            .map(|r| r.on_ack(ack_seq))
            .unwrap_or(false)
    };
    if cleared {
        // SAFETY: 单语境独占；&raw 手法不建立 static 引用。
        unsafe {
            if let Some(t) = (&raw mut TCP_RETX_TPL).as_mut() {
                *t = None;
            }
        }
    }
    cleared
}

/// 重传臂取证读出：Some((armed_seq, retries))；未武装 None。
pub fn tcp_retx_armed() -> Option<(u32, u32)> {
    // SAFETY: 单语境独占；&raw 手法不建立 static 引用。
    unsafe { (&raw mut TCP_RTO).as_ref() }
        .and_then(|r| r.is_armed().then_some((r.armed_seq(), r.retries())))
}

/// 重传臂无条件复位（跨自检隔离面——[`crate::timer::reset_evidence`]
/// 同款纪律：真电臂随 tcp_external_syn 跨自检存活〔t86-g 武装 → t89
/// 合成拍被 arm 幂等闸吞没的实录揭雷〕，自检相位入口先复位）。
pub fn tcp_retx_reset() {
    // SAFETY: 单语境独占；&raw 手法不建立 static 引用。
    unsafe {
        if let Some(r) = (&raw mut TCP_RTO).as_mut() {
            *r = pulse::tcp::RtoTimer::new();
        }
        if let Some(t) = (&raw mut TCP_RETX_TPL).as_mut() {
            *t = None;
        }
    }
}

/// 外部 RX 对接收口（M27-T1 既登记「外部 RX 对接面」随本笔收口）：
/// 外部形段组帧（src_ip 外部域 + 伪头校验和 src→本机）→ [`PULSE_RX`]
/// 共享交接环直注（与真实 RX 通路同构电段——分派全闸链照常把关）。
/// 返回 false = 态缺失/组帧越界/环满（fail-closed）。
#[allow(clippy::too_many_arguments)]
pub fn tcp_external_inject(
    src_ip: [u8; 4],
    src_port: u16,
    dst_port: u16,
    seq: u32,
    ack_seq: u32,
    flags: u16,
    payload: &[u8],
) -> bool {
    if net_state_mut().is_none() {
        return false;
    }
    let mut seg = [0u8; 20 + TCP_SEG_MAX];
    let Some(seg_len) = pulse::tcp::TcpHdr::encode(
        src_port, dst_port, seq, ack_seq, flags, 8192, payload, &mut seg,
    ) else {
        return false;
    };
    let cs = pulse::tcp::checksum(src_ip, MY_IP, &seg[..seg_len]);
    seg[16..18].copy_from_slice(&cs.to_be_bytes());
    let ip_total = 20 + seg_len;
    let flen = 14 + ip_total;
    if flen > PULSE_FRAME_MAX {
        return false;
    }
    let mut f = [0u8; PULSE_FRAME_MAX];
    let st_mac = net_state_mut().map(|st| st.mac).unwrap_or([0; 6]);
    f[0..6].copy_from_slice(&st_mac); // dst = 本机（分派链寻我闸域）
    f[6..12].copy_from_slice(&st_mac); // src MAC 不入闸（t86 回环先例同域）
    f[12..14].copy_from_slice(&0x0800u16.to_be_bytes());
    f[14] = 0x45;
    f[16..18].copy_from_slice(&(ip_total as u16).to_be_bytes());
    f[22] = 64;
    f[23] = pulse::tcp::PROTO_TCP;
    f[26..30].copy_from_slice(&src_ip); // 外部源 IP（对接收口本体域）
    f[30..34].copy_from_slice(&MY_IP);
    let ip_ck = cksum16(&f[14..34]);
    f[24..26].copy_from_slice(&ip_ck.to_be_bytes());
    f[34..34 + seg_len].copy_from_slice(&seg[..seg_len]);
    let slot = FrameSlot {
        len: flen as u16,
        _pad: [0; 6],
        data: {
            let mut d = [0u8; PULSE_FRAME_MAX];
            d[..flen].copy_from_slice(&f[..flen]);
            d
        },
    };
    match PULSE_RX.send(slot) {
        Ok(()) => {
            TCP_EXT_RX.fetch_add(1, Ordering::Relaxed);
            true
        }
        Err(_) => false,
    }
}

/// 外部 TX 电气击发（t86 相位面——真实 virtio 通路）：IPv4/TCP SYN 组帧
/// （[`icmp_echo_tx`] 同款模板 + [`pulse::tcp`] 段编码 + 伪头校验和）→
/// [`tx_frame`] 击发（发后收讫闸内建）。`dst_mac` 由调用方先经 ARP 解析
/// （t72/t73 先例——相位域 ARP roundtrip 捕获网关 MAC）。M37-N1 起
/// SYN 重传臂随击发武装（RTO 首臂 = [`crate::timer::mononow_ns`] 真电
/// 时刻，TSC 未校准防御面跳过武装——不立虚时基）；重发执行 = 消费方
/// 同参重击本面（重发容忍域 ≤3 拍先例），`ack` 清账经 [`tcp_retx_clear`]。
pub fn tcp_external_syn(
    dst_mac: [u8; 6],
    dst_ip: [u8; 4],
    dst_port: u16,
    src_port: u16,
    seq: u32,
) -> bool {
    let Some(st) = net_state_mut() else {
        return false;
    };
    let mut seg = [0u8; 20 + TCP_SEG_MAX];
    let Some(seg_len) = pulse::tcp::TcpHdr::encode(
        src_port,
        dst_port,
        seq,
        0,
        pulse::tcp::FLAG_SYN,
        8192,
        &[],
        &mut seg,
    ) else {
        return false;
    };
    let cs = pulse::tcp::checksum(MY_IP, dst_ip, &seg[..seg_len]);
    seg[16..18].copy_from_slice(&cs.to_be_bytes());
    let ip_total = 20 + seg_len;
    let flen = 14 + ip_total;
    if flen > PULSE_FRAME_MAX {
        return false;
    }
    let mut f = [0u8; PULSE_FRAME_MAX];
    f[0..6].copy_from_slice(&dst_mac);
    f[6..12].copy_from_slice(&st.mac);
    f[12..14].copy_from_slice(&0x0800u16.to_be_bytes());
    f[14] = 0x45;
    f[16..18].copy_from_slice(&(ip_total as u16).to_be_bytes());
    f[22] = 64;
    f[23] = pulse::tcp::PROTO_TCP;
    f[26..30].copy_from_slice(&MY_IP);
    f[30..34].copy_from_slice(&dst_ip);
    let ip_ck = cksum16(&f[14..34]);
    f[24..26].copy_from_slice(&ip_ck.to_be_bytes());
    f[34..34 + seg_len].copy_from_slice(&seg[..seg_len]);
    // SAFETY: 态自 bring_up 登记；flen ≤ PULSE_FRAME_MAX 界内（单语境）。
    unsafe { tx_frame(st, &f[..flen], flen) };
    TCP_EXT_TX.fetch_add(1, Ordering::Relaxed);
    // M37-N1：SYN 重传臂武装（RTO 真电首臂——TSC 未校准跳过，不立虚时基）
    if let Some(now) = ostd::time::tsc_clock::now_ns() {
        // SAFETY: 单语境独占；&raw 手法不建立 static 引用。
        unsafe {
            if let Some(r) = (&raw mut TCP_RTO).as_mut() {
                r.arm(now, seq);
            }
        }
    }
    true
}

// ===================== M38-TCP1：TCP 服务化批次（连接表驱动五面承接） =====================
//
// pulse::tcp 五面（WinScale / RttEst / CongestCtl / PersistTimer /
// ConnTable——重传面 v0 简化域收口）的 kernel::vnet 电气承接：**合成拍
// 模板 → 连接表驱动**（每槽 RTO 重传臂 + 零窗探测电击发 + 交付管线，
// 模板阵与 WS 旁账随槽一一对应）。M37-N1 单流单臂单窗（[`TCP_REASM`]/
// [`TCP_RTO`]/[`TCP_RETX_TPL`] 静态三件）保留作 t89 逐位回归锚——不迁
// 移不删除（旧 encode 路径未缩放回归锚同款纪律）。

/// 连接表容量（定容 8 槽——[`pulse::tcp::ConnTable`] N 实参；PU-P06
/// 预算内固定布局，单槽 ≈ 1.1 KiB、8 槽表 ≈ 9 KiB 量级 .bss 定容）。
pub const TCP_CONN_SLOTS: usize = 8;

/// 连接表（四元组键 → [`pulse::tcp::TcpConn`] 槽体；单语境 static——
/// 访问纪律同 [`TCP_PORTS`]）。
static mut TCP_CONNS: pulse::tcp::ConnTable<TCP_CONN_SLOTS, pulse::tcp::TcpConn> =
    pulse::tcp::ConnTable::new();

/// 每槽重传/探测模板（电重发载体——与槽位一一对应；close 随行弃置）。
static mut TCP_CONN_TPL: [Option<RetxTpl>; TCP_CONN_SLOTS] = [const { None }; TCP_CONN_SLOTS];

/// 每槽 WS 协商移位（旁账——v0 槽体定式不扩域，有效窗解释面；
/// [`pulse::tcp::ws_negotiate`] 生效值落位域）。
static mut TCP_CONN_WS: [u8; TCP_CONN_SLOTS] = [0; TCP_CONN_SLOTS];

/// 零窗探测拍电击发计数（Probe 回环击发——t91 证据域）。
static TCP_PROBE: AtomicU64 = AtomicU64::new(0);

/// 连接表句柄（&raw 手法同 [`tcp_ports_mut`] 纪律）。
fn tcp_conns_mut() -> Option<&'static mut pulse::tcp::ConnTable<TCP_CONN_SLOTS, pulse::tcp::TcpConn>>
{
    // SAFETY: 单语境（kmain 自检串行段）独占访问；&raw 手法不建立
    //         static 引用（static_mut_refs 免疫）。
    unsafe { (&raw mut TCP_CONNS).as_mut() }
}

/// 连接表驱动开连接：四元组键 → [`pulse::tcp::TcpConn`] 建槽入表
/// （重组基线 = 对端 ISN + 1，发送窗自本端 ISN 起，拥塞账 IW =
/// 2·SMSS）。槽满/重复键 fail-visible（[`pulse::tcp::ConnTableError`]）。
pub fn tcp_conn_open(
    key: pulse::tcp::TcpKey,
    state: pulse::tcp::ConnState,
    isn: u32,
    peer_isn: u32,
    peer_win: u16,
    smss: u32,
) -> Result<usize, pulse::tcp::ConnTableError> {
    let conn = pulse::tcp::TcpConn::new(state, isn, peer_isn, peer_win, smss);
    match tcp_conns_mut() {
        Some(t) => t.alloc(key, conn),
        // 结构性不可达（static const 初始化）——防御面 NotFound
        None => Err(pulse::tcp::ConnTableError::NotFound),
    }
}

/// 在册连接数。
pub fn tcp_conn_count() -> usize {
    tcp_conns_mut().map_or(0, |t| t.live())
}

/// 槽位键读出（None = 空槽/越界）。
pub fn tcp_conn_key_at(idx: usize) -> Option<pulse::tcp::TcpKey> {
    tcp_conns_mut()?.key_at(idx).copied()
}

/// 槽位连接状态读出。
pub fn tcp_conn_state(idx: usize) -> Option<pulse::tcp::ConnState> {
    tcp_conns_mut()?.slot(idx).map(|c| c.state)
}

/// 槽位重组窗读数：Some((基线 rcv_nxt, 在窗缓存字节))。
pub fn tcp_conn_reasm_state(idx: usize) -> Option<(u32, usize)> {
    tcp_conns_mut()?
        .slot(idx)
        .map(|c| (c.reasm.rcv_nxt(), c.reasm.pending()))
}

/// 连接表驱动接收管线（交付域）：ACK 滑窗推进（陈旧/越域 ACK 零动作
/// ——M37-N1 语义逐位保持）+ 非空载荷乱序重组（槽内 reasm——InOrder
/// 前缀拼接交付 / Queued 缓存待洞 / Old/Overflow 段级拒收 v0 偏差同
/// 源）。拼接交付字节写 `out`，返回交付数（None = 槽位缺失
/// fail-visible；0 = 纯旗段/基线有洞/段级拒收）。
#[allow(clippy::too_many_arguments)]
pub fn tcp_conn_deliver(
    idx: usize,
    seq: u32,
    ack_seq: u32,
    flags: u16,
    window: u16,
    payload: &[u8],
    out: &mut [u8],
) -> Option<usize> {
    let conn = tcp_conns_mut()?.slot_mut(idx)?;
    if flags & pulse::tcp::FLAG_ACK != 0 {
        conn.swnd.on_ack(ack_seq, window); // 陈旧/越域 ACK 零动作（显形域）
    }
    if payload.is_empty() {
        return Some(0);
    }
    match conn.reasm.insert(seq, payload) {
        pulse::tcp::ReasmOutcome::InOrder => Some(conn.reasm.drain(out)),
        _ => Some(0), // Queued/Old/Overflow：零交付（缓存/拒收域）
    }
}

/// 槽位重传臂武装（合成时刻版——t91 确定性驱动面）：模板定格 + 槽内
/// RTO 首臂（幂等——已武装不重置，最早未确认段主导）。payload 越域
/// fail-visible 拒臂。
#[allow(clippy::too_many_arguments)]
pub fn tcp_conn_retx_arm_at(
    idx: usize,
    now_ns: u64,
    src_port: u16,
    dst_port: u16,
    seq: u32,
    ack_seq: u32,
    flags: u16,
    window: u16,
    payload: &[u8],
) -> bool {
    if payload.len() > TCP_SEG_MAX {
        return false;
    }
    let tpl = RetxTpl {
        src_port,
        dst_port,
        seq,
        ack_seq,
        flags,
        window,
        payload: {
            let mut d = [0u8; TCP_SEG_MAX];
            d[..payload.len()].copy_from_slice(payload);
            d
        },
        len: payload.len(),
    };
    // SAFETY: 单语境独占；&raw 手法不建立 static 引用。
    unsafe {
        if idx >= TCP_CONN_SLOTS {
            return false;
        }
        if let Some(arr) = (&raw mut TCP_CONN_TPL).as_mut() {
            arr[idx] = Some(tpl);
        }
    }
    tcp_conns_mut()
        .and_then(|t| t.slot_mut(idx))
        .map(|c| {
            c.rto.arm(now_ns, seq);
            true
        })
        .unwrap_or(false)
}

/// 槽位重传拍（合成时刻版）：槽内 RTO 到期判定 → Due 时槽模板电重发
/// （回环通路——[`tcp_loopback_tx`] 同构组帧，段参数原样定格）→
/// [`TCP_RETX`] 计数显形；Exhausted 弃槽模板（拆除判定交消费方）。
pub fn tcp_conn_retx_tick_at(idx: usize, now_ns: u64) -> pulse::tcp::RtoDecision {
    let decision = tcp_conns_mut()
        .and_then(|t| t.slot_mut(idx))
        .map(|c| c.rto.poll(now_ns))
        .unwrap_or(pulse::tcp::RtoDecision::Idle);
    if decision == pulse::tcp::RtoDecision::Due {
        let fired = {
            // SAFETY: 单语境独占；&raw 手法不建立 static 引用。
            unsafe { (&raw mut TCP_CONN_TPL).as_ref() }
                .and_then(|arr| arr.get(idx))
                .and_then(|t| t.as_ref())
                .is_some_and(|t| {
                    tcp_loopback_tx(
                        t.src_port,
                        t.dst_port,
                        t.seq,
                        t.ack_seq,
                        t.flags,
                        t.window,
                        &t.payload[..t.len],
                    )
                })
        };
        if fired {
            TCP_RETX.fetch_add(1, Ordering::Relaxed);
        } else {
            TCP_RETX_MISS.fetch_add(1, Ordering::Relaxed);
        }
    } else if decision == pulse::tcp::RtoDecision::Exhausted {
        // SAFETY: 单语境独占；&raw 手法不建立 static 引用。
        unsafe {
            if let Some(arr) = (&raw mut TCP_CONN_TPL).as_mut() {
                if idx < TCP_CONN_SLOTS {
                    arr[idx] = None;
                }
            }
        }
    }
    decision
}

/// 槽位重传臂取证读出：Some((armed_seq, retries))；未武装/槽缺失 None。
pub fn tcp_conn_retx_armed(idx: usize) -> Option<(u32, u32)> {
    tcp_conns_mut()?.slot(idx).and_then(|c| {
        c.rto
            .is_armed()
            .then_some((c.rto.armed_seq(), c.rto.retries()))
    })
}

/// 槽位重传臂 ACK 清账：`ack` 越过武装段首序号 → 解除武装、退避复位、
/// 槽模板弃置（[`tcp_retx_clear`] 同构——连接表驱动域）。返回 true =
/// 本臂已清（false = 陈旧/重复 ACK 或未武装——零动作）。
pub fn tcp_conn_retx_clear(idx: usize, ack_seq: u32) -> bool {
    let cleared = tcp_conns_mut()
        .and_then(|t| t.slot_mut(idx))
        .map(|c| c.rto.on_ack(ack_seq))
        .unwrap_or(false);
    if cleared {
        // SAFETY: 单语境独占；&raw 手法不建立 static 引用。
        unsafe {
            if let Some(arr) = (&raw mut TCP_CONN_TPL).as_mut() {
                if idx < TCP_CONN_SLOTS {
                    arr[idx] = None;
                }
            }
        }
    }
    cleared
}

/// 槽位零窗探测臂武装（幂等——已武装不重置不换基）。
pub fn tcp_conn_persist_arm(idx: usize, now_ns: u64, rto_ns: u64) -> bool {
    tcp_conns_mut()
        .and_then(|t| t.slot_mut(idx))
        .map(|c| {
            c.persist.arm(now_ns, rto_ns);
            true
        })
        .unwrap_or(false)
}

/// 槽位零窗探测解除（对端窗重开——幂等，未武装 false）。
pub fn tcp_conn_persist_release(idx: usize) -> bool {
    tcp_conns_mut()
        .and_then(|t| t.slot_mut(idx))
        .map(|c| c.persist.release())
        .unwrap_or(false)
}

/// 槽位探测拍（合成时刻版）：到期判定 → Probe 时探测段电击发——
/// **重发 una 起 1 字节**（RFC 9293 §3.7.3；槽模板域内按
/// `una − 模板 seq` 取偏移字节，回环通路 1 字节段）→ [`TCP_PROBE`]
/// 计数显形；Broken 时同步解除武装（拆除判定交消费方，fail-visible）。
pub fn tcp_conn_persist_tick_at(idx: usize, now_ns: u64) -> pulse::tcp::PersistDecision {
    let decision = tcp_conns_mut()
        .and_then(|t| t.slot_mut(idx))
        .map(|c| c.persist.poll(now_ns))
        .unwrap_or(pulse::tcp::PersistDecision::Idle);
    if decision == pulse::tcp::PersistDecision::Probe {
        let probe_src: Option<(u32, &RetxTpl)> = {
            // SAFETY: 单语境独占；&raw 手法不建立 static 引用。
            unsafe { (&raw mut TCP_CONN_TPL).as_ref() }.and_then(|arr| {
                arr.get(idx).and_then(|t| {
                    t.as_ref().map(|tpl| {
                        let una = tcp_conns_mut()
                            .and_then(|tab| tab.slot(idx))
                            .map(|c| c.swnd.una())
                            .unwrap_or(tpl.seq);
                        (una, tpl)
                    })
                })
            })
        };
        let fired = probe_src.is_some_and(|(una, t)| {
            let off = una.wrapping_sub(t.seq) as usize;
            if off < t.len {
                tcp_loopback_tx(
                    t.src_port,
                    t.dst_port,
                    una,
                    t.ack_seq,
                    t.flags,
                    t.window,
                    &t.payload[off..off + pulse::tcp::PROBE_SEG_LEN],
                )
            } else {
                false
            }
        });
        if fired {
            TCP_PROBE.fetch_add(1, Ordering::Relaxed);
        } else {
            TCP_RETX_MISS.fetch_add(1, Ordering::Relaxed);
        }
    } else if decision == pulse::tcp::PersistDecision::Broken {
        // Broken：解除武装已由槽内 poll 承担（fail-visible——拆除判定
        // 交消费方；模板同步弃置）
        // SAFETY: 单语境独占；&raw 手法不建立 static 引用。
        unsafe {
            if let Some(arr) = (&raw mut TCP_CONN_TPL).as_mut() {
                if idx < TCP_CONN_SLOTS {
                    arr[idx] = None;
                }
            }
        }
    }
    decision
}

/// 零窗探测拍计数读出（t91 证据域）。
pub fn tcp_probe_count() -> u64 {
    TCP_PROBE.load(Ordering::Relaxed)
}

/// 槽位 RTT 采样（首样/滑动自动分域——未 primed 走首样、已 primed 走
/// 滑动；Karn 窄化 = `from_retx` 拒采双域通行）。返回 Some(true) = 采
/// 样入账；Some(false) = 拒采（窄化/退化域——fail-visible）；None = 槽
/// 位缺失。
pub fn tcp_conn_rtt_sample(idx: usize, r_ns: u64, from_retx: bool) -> Option<bool> {
    tcp_conns_mut().and_then(|t| t.slot_mut(idx)).map(|c| {
        if c.rttest.primed() {
            c.rttest.sample(r_ns, from_retx)
        } else {
            !from_retx && c.rttest.first_sample(r_ns)
        }
    })
}

/// 槽位 RTT 估计读数：Some((srtt, rttvar, rto))——rto 为 RFC 6298
/// 导出夹逼域值（证据面）。
pub fn tcp_conn_rtt_state(idx: usize) -> Option<(u64, u64, u64)> {
    tcp_conns_mut()?.slot(idx).map(|c| {
        let e = &c.rttest;
        (e.srtt(), e.rttvar(), e.rto())
    })
}

/// 槽位拥塞 ACK 拍：返回 Some((cwnd, ssthresh)) 后读数。
pub fn tcp_conn_cc_ack(idx: usize, acked_bytes: u32) -> Option<(u32, u32)> {
    tcp_conns_mut().and_then(|t| t.slot_mut(idx)).map(|c| {
        c.cwnd.on_ack(acked_bytes);
        (c.cwnd.cwnd(), c.cwnd.ssthresh())
    })
}

/// 槽位拥塞 RTO 折叠拍：返回 Some((cwnd, ssthresh)) 后读数。
pub fn tcp_conn_cc_rto(idx: usize, flight: u32) -> Option<(u32, u32)> {
    tcp_conns_mut().and_then(|t| t.slot_mut(idx)).map(|c| {
        c.cwnd.on_rto(flight);
        (c.cwnd.cwnd(), c.cwnd.ssthresh())
    })
}

/// 槽位发送资格（拥塞域门控）：min(avail_window, cwnd)。
pub fn tcp_conn_send_credit(idx: usize, avail_window: u32) -> Option<u32> {
    tcp_conns_mut()?
        .slot(idx)
        .map(|c| c.cwnd.send_credit(avail_window))
}

/// 槽位 WS 协商落账：生效移位（双方 SYN 域）写 WS 旁账并回读。
pub fn tcp_conn_ws_negotiate(
    idx: usize,
    local_syn: bool,
    local_shift: u8,
    peer_syn: bool,
    peer_shift: Option<u8>,
) -> Option<u8> {
    let shift = pulse::tcp::ws_negotiate(local_syn, local_shift, peer_syn, peer_shift);
    // SAFETY: 单语境独占；&raw 手法不建立 static 引用。
    unsafe {
        if let Some(arr) = (&raw mut TCP_CONN_WS).as_mut() {
            if idx < TCP_CONN_SLOTS {
                arr[idx] = shift;
                return Some(shift);
            }
        }
    }
    None
}

/// 槽位有效窗读出：`wire << 协商移位`（[`pulse::tcp::ws_effective_window`]
/// ——未协商槽移位 0 = 未缩放直通回归锚）。
pub fn tcp_conn_effective_win(idx: usize) -> Option<u32> {
    let c = tcp_conns_mut()?.slot(idx)?;
    // SAFETY: 单语境独占；&raw 手法不建立 static 引用。
    let shift = unsafe {
        (&raw mut TCP_CONN_WS)
            .as_ref()
            .and_then(|arr| arr.get(idx))
            .copied()
            .unwrap_or(0)
    };
    Some(pulse::tcp::ws_effective_window(c.swnd.window(), shift))
}

/// 槽位发送窗读数：Some((una, nxt, peer_win))。
pub fn tcp_conn_swnd_state(idx: usize) -> Option<(u32, u32, u16)> {
    tcp_conns_mut()?
        .slot(idx)
        .map(|c| (c.swnd.una(), c.swnd.nxt(), c.swnd.window()))
}

/// 槽位发出记账：`nxt` 前进 `len`，返回新 nxt（None = 槽位缺失）。
pub fn tcp_conn_sent(idx: usize, len: u32) -> Option<u32> {
    tcp_conns_mut().and_then(|t| t.slot_mut(idx)).map(|c| {
        c.swnd.sent(len);
        c.swnd.nxt()
    })
}

/// 槽位关闭：连接表释放复用 + 槽模板弃置 + WS 旁账清零（零残留域）。
pub fn tcp_conn_close(idx: usize) -> Result<pulse::tcp::TcpConn, pulse::tcp::ConnTableError> {
    // SAFETY: 单语境独占；&raw 手法不建立 static 引用。
    unsafe {
        if let Some(arr) = (&raw mut TCP_CONN_TPL).as_mut() {
            if idx < TCP_CONN_SLOTS {
                arr[idx] = None;
            }
        }
        if let Some(ws) = (&raw mut TCP_CONN_WS).as_mut() {
            if idx < TCP_CONN_SLOTS {
                ws[idx] = 0;
            }
        }
    }
    match tcp_conns_mut() {
        Some(t) => t.close(idx),
        None => Err(pulse::tcp::ConnTableError::NotFound),
    }
}

/// 连接面跨自检隔离（[`tcp_retx_reset`] 同款纪律——表/模板/WS 旁账/
/// 探测计数全清）。
pub fn tcp_conn_reset_all() {
    // SAFETY: 单语境独占；&raw 手法不建立 static 引用。
    unsafe {
        if let Some(t) = (&raw mut TCP_CONNS).as_mut() {
            *t = pulse::tcp::ConnTable::new();
        }
        if let Some(arr) = (&raw mut TCP_CONN_TPL).as_mut() {
            *arr = [const { None }; TCP_CONN_SLOTS];
        }
        if let Some(ws) = (&raw mut TCP_CONN_WS).as_mut() {
            *ws = [0; TCP_CONN_SLOTS];
        }
    }
    TCP_PROBE.store(0, Ordering::Relaxed);
}

/// ARP 回声活体成果（t69 断言域）。
pub struct ArpEcho {
    /// 应答源 MAC（slirp 虚拟网关域）。
    pub sha: [u8; 6],
    /// 应答源 IP（应为 10.0.2.2）。
    pub spa: [u8; 4],
    /// 应答目标 MAC（应为本机 MAC——命中闸已断言，此处留证）。
    pub tha: [u8; 6],
    /// TX 完成消费数。
    pub tx_used: usize,
    /// RX 收帧审视数（含非 ARP 噪声）。
    pub rx_seen: usize,
}

/// ARP 电气活体：广播请求（who-has 10.0.2.2 tell 10.0.2.15），slirp
/// 应答，used 双环轮询排水，帧解析。命中闸内建（ethertype 0806、
/// oper 2、tpa 本机、tha 本机 MAC、帧长足额五条同验）；预算耗尽 /
/// 态缺失返回 None（fail-closed）。
pub fn arp_roundtrip() -> Option<ArpEcho> {
    let st = net_state_mut()?;
    // SAFETY: 前置 —— tx_buf/rx_bufs 单帧物理地址（恒等映射界内），
    //         vring 三表自 setup_queue 装配；desc/环槽 % num 界内。
    // 不变式 —— 发布序（desc → avail 环项 → avail.idx → kick）；
    //           used 影子游标单调推进；应答解析只读。
    // 并发 —— 自检语境单线程串行；设备侧 DMA 写 used/RX 缓冲。
    // 违反后果 —— 环槽越界写邻表（num 模运算拦截）/ 游标错位丢帧
    //             （预算内重扫兜底）。
    unsafe {
        // 1+2) TX 组帧 + 发布 + 击发（共用面：C3 抽 [`tx_arp_request`]）
        tx_arp_request(st);
        // 3) 轮询：tx/rx used 双环排水 + 应答扫描
        let mut tx_used = 0usize;
        let mut rx_seen = 0usize;
        let mut spin = 0u64;
        while spin < ARP_SPIN_BUDGET {
            let mut elems = [Done { id: 0, len: 0 }; 8];
            tx_used += drain_used(&mut st.tx, &mut elems);
            let mut relems = [Done { id: 0, len: 0 }; 8];
            let rn = drain_used(&mut st.rx, &mut relems);
            for e in relems.iter().take(rn) {
                let idx = e.id as usize;
                if idx >= RX_POST as usize {
                    continue; // 越界 id 拒收（fail-closed）
                }
                if e.len < (VNET_HDR + 42) as u32 {
                    continue; // 短帧噪声拒收（ARP 整帧 42 B 足额闸）
                }
                rx_seen += 1;
                let rf = st.rx_bufs[idx] + VNET_HDR as u64;
                if peek16(rf, 12) != 0x0806 {
                    continue; // 非 ARP（噪声帧如实计数）
                }
                if peek16(rf, 20) != 2 {
                    continue; // 非 ARP 应答
                }
                let mut sha = [0u8; 6];
                let mut spa = [0u8; 4];
                let mut tha = [0u8; 6];
                let mut tpa = [0u8; 4];
                for (i, b) in sha.iter_mut().enumerate() {
                    *b = peek8(rf, 22 + i);
                }
                for (i, b) in spa.iter_mut().enumerate() {
                    *b = peek8(rf, 28 + i);
                }
                for (i, b) in tha.iter_mut().enumerate() {
                    *b = peek8(rf, 32 + i);
                }
                for (i, b) in tpa.iter_mut().enumerate() {
                    *b = peek8(rf, 38 + i);
                }
                // 应答寻我 + 问我本机地址 → 命中
                if tpa == MY_IP && tha == st.mac {
                    // M37-⓪ 收讫对账：应答命中即证 TX 已被设备消费——
                    // used 回执仅异步迟到（MTTCG TX BH，M24-C1 实录
                    // 同族）。命中后小预算排水等待回执落环，账实对齐
                    // 再返回：三闸 tx_used≥1 不再与回执到达序竞速
                    // （本宿主 4/4 确定性击发：rx_seen=1 + tx_used=0）。
                    // 预算耗尽仍如实返回现值（回执真丢失 = t73 B 面
                    // 家族，fail-visible 不掩）。
                    let mut settle = 0u64;
                    while tx_used == 0 && settle < ARP_SETTLE_BUDGET {
                        let mut telems = [Done { id: 0, len: 0 }; 8];
                        tx_used += drain_used(&mut st.tx, &mut telems);
                        settle += 1;
                        core::hint::spin_loop();
                    }
                    return Some(ArpEcho {
                        sha,
                        spa,
                        tha,
                        tx_used,
                        rx_seen,
                    });
                }
            }
            spin += 1;
            core::hint::spin_loop();
        }
        None
    }
}

/// 上电状态机：探测 → cap 走查 → 窗映射 → ACK/DRIVER → 特性协商
/// （VERSION_1 必选，其余全弃——v0 最小驱动面）→ FEATURES_OK 复验 →
/// rx/tx 双队列装配 → DRIVER_OK → MAC 读出 → C2 数据面装配（RX 预填、
/// RX 击发、态登记）。任一步失败返回 None（fail-closed；QEMU 参考
/// 环境恒有 virtio-net-pci）。
pub fn bring_up(frames: &FrameAllocator) -> Option<NetDev> {
    let (dev, bars) = probe()?;
    // PCI 命令字使能：MEMORY SPACE(0x02) + BUS MASTER(0x04)——设备 DMA 前提。
    // bus master 关闭时设备侧地址空间（bus_master_as 别名）恒指 unassigned：
    // vring region cache 读全零/写静默丢弃——数据面全盲（C2 首轮实录：
    // 状态机/MAC 全活而 last_avail 恒 0、线包零包，host 侧 pc.ram 直读帧全在）。
    // 代价域：dword 写回覆盖 status 高 16 位（RW1C 误差位清零，无害）。
    let cmd = pci_read_dword(0, dev, 0, 0x04);
    pci_write_dword(0, dev, 0, 0x04, cmd | 0x0006);
    let caps = walk_caps(dev, &bars)?;
    let (cbase, coff, clen) = caps.common;
    // C2 数据面硬依赖 notify 窗（击发面）——缺失即 fail-closed。
    let Some((nbase, noff, nlen)) = caps.notify else {
        crate::console::serial_log_bytes(b"net: caps no-notify");
        return None;
    };
    if caps.notify_mult == 0 {
        crate::console::serial_log_bytes(b"net: notify mult-zero");
        return None;
    }
    // 同 BAR 多窗一次映射（common/device 共用 BAR4——初版双 map_window
    // 重叠页 AlreadyMapped 实录）；范围取三窗最远末端（notify 窗在
    // QEMU modern 布局位于 common/device 之后，C1 版 span 未覆盖——
    // 击发写窗即越界，C2 起扩容）。
    let mut span = (coff + clen) as u64;
    if let Some((_, doff, dlen)) = caps.device {
        span = span.max((doff + dlen) as u64);
    }
    if nbase == cbase {
        span = span.max((noff + nlen) as u64);
    }
    if map_window(frames, cbase, span).is_err() {
        crate::console::serial_log_bytes(b"net: map fail");
        return None;
    }
    if nbase != cbase && map_window(frames, nbase, (noff + nlen) as u64).is_err() {
        crate::console::serial_log_bytes(b"net: map notify fail");
        return None;
    }
    let cc_win = Window {
        base: cbase + coff as u64,
    };
    // 设备配置窗（MAC；与 common 同 BAR，同一映射覆盖）
    let dev_win = caps.device.map(|(_, doff, _)| Window {
        base: cbase + doff as u64,
    });
    // SAFETY: 前置条件 —— cc_win 映射窗界内（common cfg 规范域偏移）。
    // 不变式 —— 状态机单调推进：ACK → DRIVER → 协商 → FEAT_OK 复验 →
    //           队列 → DRIVER_OK；每步读回验证，失败即 fail-closed。
    // 并发 —— bring-up 单语境；设备无并发驱动者。
    // 违反后果 —— 状态机错序设备拒答（status 复验拦截）。
    unsafe {
        cc_win.wr8(cc::STATUS, S_ACK);
        cc_win.wr8(cc::STATUS, S_ACK | S_DRIVER);
        // 特性协商：扩展字 1 必须 VIRTIO_F_VERSION_1；驱动接受面 = 仅
        // VERSION_1（字 0 全弃——CSUM/GUEST_CSUM/MAC 等可选特性 v0 不用）
        cc_win.wr32(cc::DEV_FEAT_SEL, 1);
        let f_hi = cc_win.rd32(cc::DEV_FEAT);
        cc_win.wr32(cc::DEV_FEAT_SEL, 0);
        let _f_lo = cc_win.rd32(cc::DEV_FEAT);
        if f_hi & F_VERSION_1 == 0 {
            crate::console::serial_log_bytes(b"net: feat no-version1");
            return None;
        }
        cc_win.wr32(cc::DRV_FEAT_SEL, 0);
        cc_win.wr32(cc::DRV_FEAT, 0);
        cc_win.wr32(cc::DRV_FEAT_SEL, 1);
        cc_win.wr32(cc::DRV_FEAT, F_VERSION_1);
        cc_win.wr8(cc::STATUS, S_ACK | S_DRIVER | S_FEAT_OK);
        if cc_win.rd8(cc::STATUS) & S_FEAT_OK == 0 {
            crate::console::serial_log_bytes(b"net: feat-ok rejected");
            return None;
        }
        let num_queues = cc_win.rd16(cc::NUM_QUEUES);
        if num_queues < 2 {
            crate::console::serial_log_bytes(b"net: queues too-few");
            return None;
        }
        let Some(sq0) = setup_queue(&cc_win, 0, frames) else {
            crate::console::serial_log_bytes(b"net: vring rx fail");
            return None;
        };
        let Some(sq1) = setup_queue(&cc_win, 1, frames) else {
            crate::console::serial_log_bytes(b"net: vring tx fail");
            return None;
        };
        if sq0.num != sq1.num {
            return None;
        }
        cc_win.wr8(cc::STATUS, S_ACK | S_DRIVER | S_FEAT_OK | S_DRIVER_OK);
        let status = cc_win.rd8(cc::STATUS);
        if status & S_DRIVER_OK == 0 {
            crate::console::serial_log_bytes(b"net: driver-ok rejected");
            return None;
        }
        // MAC 读出（device cfg 窗偏移 0 起 6 字节；无 device cap → 全零
        // 哨兵，t68 断言拦截）
        let mut mac = [0u8; 6];
        if let Some(dw) = &dev_win {
            for (i, m) in mac.iter_mut().enumerate() {
                *m = dw.rd8(i);
            }
        }
        // ---- C2 数据面装配：RX 预填 → RX 击发 → 态登记 ----
        let mut rx_vr = Vring {
            desc: sq0.desc,
            avail: sq0.avail,
            used: sq0.used,
            num: sq0.num,
            notify_off: sq0.notify_off,
            next_idx: 0,
            last_used: 0,
        };
        let tx_vr = Vring {
            desc: sq1.desc,
            avail: sq1.avail,
            used: sq1.used,
            num: sq1.num,
            notify_off: sq1.notify_off,
            next_idx: 0,
            last_used: 0,
        };
        // RX 缓冲（单 desc 单缓冲 ×RX_POST，desc 槽 = 下标）
        let mut rx_bufs = [0u64; RX_POST as usize];
        for (i, rb) in rx_bufs.iter_mut().enumerate() {
            let Some(b) = frames.alloc() else {
                crate::console::serial_log_bytes(b"net: rx buf fail");
                return None;
            };
            ostd::hw::phys::write_zero(b, 4096);
            *rb = b;
            set_desc(sq0.desc, i as u16, b, 4096, DFLAG_WRITE);
        }
        for i in 0..RX_POST {
            push_avail(&mut rx_vr, i);
        }
        let Some(tx_buf) = frames.alloc() else {
            crate::console::serial_log_bytes(b"net: tx buf fail");
            return None;
        };
        ostd::hw::phys::write_zero(tx_buf, 4096);
        let st = NetState {
            notify_base: nbase + noff as u64,
            notify_mult: caps.notify_mult,
            rx: rx_vr,
            tx: tx_vr,
            mac,
            rx_bufs,
            tx_buf,
            rx_pending: [false; RX_POST as usize],
        };
        // RX 击发（队列 0）——预填缓冲对设备可见（slirp 噪声帧即收）
        // SAFETY: notify 窗自 cap 走查映射（span 已含 notify 段）。
        kick(st.notify_base, st.notify_mult, 0, &st.rx);
        // SAFETY: 单语境登记（kmain 自检串行段）；&raw 手法无引用建立。
        (&raw mut NET_STATE).write(Some(st));
        Some(NetDev {
            mac,
            num_queues,
            queue_size: sq0.num,
            status,
        })
    }
}
