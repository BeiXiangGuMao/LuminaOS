//! 文件面（M13-②）：统一句柄面上的文件对象与 SYS_OPEN/READ/WRITE 落点。
//!
//! **fd ≡ 句柄（fd 表 ↔ 句柄表融合定案）**：文件与 IPC 通道共享同一任务
//! 句柄命名空间（`handle ∈ 1..HANDLE_MAX`，M9 语义不变），靠两层正交区分：
//! 1. **对象 id 段位**：文件对象 id = [`FILE_OBJECT_BASE`]（0xF11E_…）单调
//!    铸造；通道对象 = 0xC0DE_… 段（M12-A）。解析链
//!    `句柄 → 全局能力槽 → 能力.object → 段位判定 → FILES 注册表按对象反查`
//!    ——与 ipc 的通道反查同构；
//! 2. **权限位**：文件能力 = `Right::READ | Right::WRITE`（通用对象位，
//!    bit0/bit1）；通道 = `IPC_SEND | IPC_RECV`（bit4/5）。SYS_HANDLE_
//!    QUERY/ENUM 天然透出文件句柄（权限位可辨）——统一句柄面的查询/
//!    枚举零改动即成立；跨任务授予（SYS_CAP_GRANT 权限子集派生）对文件
//!    句柄自动可用（架构允许，v0 未专门设检，记档）。
//!
//! **OFD 语义**：内核 [`FileObject`] 复刻 M13-① `FdTable::OpenFileDescription`
//! 的骨架语义——私有偏移推进、访问位强制（读句柄写 → EBADF）、seek 三基准
//! 与负偏移拒绝。M13-① `meridian::vfs::FdTable` 保持宿主面参照实现地位
//! （其代际槽 ABA 防护留在数据结构面）；内核面 fd 号复用 = Linux 同款
//! 语义（close 后旧句柄失效，v0 不做代际槽，与通道面一致，如实记档）。
//!
//! **错误域分立**：本面全部错误返回 Linux 5.15 errno（Conduit 口径，经
//! [`meridian::vfs::FsError::errno`] 折叠 + 本模块本地 errno）；进程/能力
//! 面错误域（1–10，procs 文档）不受影响。注册表满 = ENFILE(23)、调用方
//! 句柄表满 = EMFILE(24)（Linux 语义正分，不与 ERR_TABLE(7) 混用）。
//!
//! 锁序契约：NAMESPACE/FILES → 各 FileSystem 内部锁（单向嵌套；任何
//! FileSystem 实现不回调本模块——RamFs 纯数据结构）；本面不取 SCHED
//! （全同步语义，零阻塞）。M15 扩展单向链：**FILES → CAPS**（孤儿
//! 回收面 [`reap_orphaned_files`]；全局纪律 = SCHED 最外层，无反向边）。
//!
//! **M15-① 目录面**：SYS_MKDIR/REMOVE（父走查 + 叶子操作，[`PathBuf::
//! parent`]/[`PathBuf::name`] 切片）+ SYS_READDIR（**分页化**——OFD
//! 偏移兼任目录项游标，[`meridian::vfs::pack_dir_page`] 纯函数打包）+
//! SYS_MOUNT/UMOUNT（v0 仅 RamFs 挂载：内核侧新建空实例，mount 契约
//! M13-① 已备）。错误域同文件面 errno。
//!
//! **M15-② 句柄面深化**：SYS_DUP/FCNTL（开放文件描述跨句柄共享——
//! 引用计数承载，dup/grant 每槽 +1、close/revoke 递减、归零回收）+
//! CLOEXEC（per-handle 旗标存 TCB `hflags`，[`crate::task::
//! close_cloexec_handles`] 在 EXEC 成功路径消费）+ **通道句柄关闭
//! 落点**（v0 bind 存续语义补全：通道句柄可关——句柄/能力回收，
//! 通道对象在注册表存续）。
//!
//! **M16-① 文件创建面**：SYS_OPEN 模式域扩展 O_CREAT（缺失经父走查
//! 新建常规文件）+ O_TRUNC（可写打开后截零，[`FileSystem::truncate`]
//! 承载）——文件面从「只读播种」走向 ring3 自主创建。
//!
//! unsafe 面：零（用户缓冲校验复用 `crate::syscall::validate_user_slice*`）。

use alloc::sync::Arc;
use alloc::vec::Vec;
use core::sync::atomic::{AtomicU64, AtomicUsize, Ordering};

use meridian::vfs::{FileSystem, FsError, Namespace, NodeKind, OpenFlags, PathBuf, RamFs, VnodeId};
use ostd::sync::SpinLock;
use vanguard::{Capability, Right};

use crate::syscall::{validate_user_slice, validate_user_slice_mut};
use crate::task;

/// 内核文件注册表容量（M14-② 首审：16 → 32；与 MAX_CHANNELS=32 同档，
/// 统一句柄面叠加后同量级工作集首次过线）。
const MAX_FILES: usize = 32;
/// 文件对象 id 铸造基（与通道 0xC0DE_… 段隔离；高 32 位即段判定位）。
const FILE_OBJECT_BASE: u64 = 0xF11E_0000_0000_0000;
/// 管道对象 id 基址（M35-BBa——独立段位 0xF19E，与文件/通道段位互斥；
/// 读端/写端各占一个 object id，共享同一 [`Pipe`] 环核）。
const PIPE_OBJECT_BASE: u64 = 0xF19E_0000_0000_0000;

// ---- 本地 errno（Conduit 口径；FsError 未覆盖的语义） ----
/// 句柄无效 / 未以所需访问方式打开 / 非文件对象。
const EBADF: u64 = 9;
/// 内核文件对象槽 / 全局能力槽耗尽。
const ENOMEM: u64 = 12;
/// 用户缓冲不可达（校验失败）。
const EFAULT: u64 = 14;
/// 零模式 / whence 越界 / seek 结果为负 / 路径非 UTF-8。
const EINVAL: u64 = 22;
/// 权限拒绝（M40-CRYSTAL chown/chmod 门禁域）。
const EPERM: u64 = 1;
/// 节点缺席（M40-CRYSTAL chown/chmod 车道域）。
const ENOENT: u64 = 2;
/// 内核文件注册表满。
const ENFILE: u64 = 23;
/// 调用方句柄表满。
const EMFILE: u64 = 24;
/// 资源暂不可用（管道空环/满环——M35-BBa 非阻塞语义登记）。
const EAGAIN: u64 = 11;
/// 管道断裂（读端引用归零后写——SIGPIPE 递送面挂账）。
const EPIPE: u64 = 32;

/// M19-① ENFILE 现场快照：bit63..40 = FILES used，bit15..8 = CAPS 存活
/// 槽数，bit0 = 有效旗。ENFILE 返回点锁内采样（reap 补扫会修复现场，
/// 调用方侧事后采样恒 0——round-223 files-used=0/32 教训）。
static ENFILE_SNAP: AtomicU64 = AtomicU64::new(0);
/// M19-① ENFILE 快照读取（t45 取证面；v2 位段见 ENFILE_SNAP 文档）。
pub fn enfile_snapshot() -> u64 {
    ENFILE_SNAP.load(Ordering::Acquire)
}
/// 对非目录句柄请求目录语义（READDIR on 文件）。
const ENOTDIR: u64 = 20;
/// STAT 尺寸域（31 位）溢出（ramfs 不可达，防御性）。
const EOVERFLOW: u64 = 75;

/// 成功标记位：返回值 `(1 << 32) | payload`（与错误域隔离）。
const OK_BIT: u64 = 1 << 32;

/// 内核文件对象：M13-① OFD 语义的内核承载。
struct FileObject {
    /// 对象 id（铸造时落位；注册表反查键）。
    object: u64,
    fs: Arc<dyn FileSystem>,
    vnode: VnodeId,
    pos: u64,
    readable: bool,
    writable: bool,
}

/// 挂载命名空间（init 播种 ramfs 根；挂载/卸载落点属后续块）。
static NAMESPACE: SpinLock<Option<Namespace>> = SpinLock::new(None);
/// 内核文件注册表：槽位按对象 id 反查（与 CHANNELS 同构）。
static FILES: SpinLock<Vec<Option<FileObject>>> = SpinLock::new(alloc::vec::Vec::new());
/// 文件对象 id 铸造计数（单调，fetch_add）。
static NEXT_OBJECT: AtomicU64 = AtomicU64::new(FILE_OBJECT_BASE);

// ---- 取证面（t44/t45 断言） ----
static OPEN_RESULT: AtomicU64 = AtomicU64::new(u64::MAX);
static OPEN_HANDLE: AtomicU64 = AtomicU64::new(u64::MAX);
static READ_RESULT: AtomicU64 = AtomicU64::new(u64::MAX);
static WRITE_RESULT: AtomicU64 = AtomicU64::new(u64::MAX);
static CLOSE_RESULT: AtomicU64 = AtomicU64::new(u64::MAX);
static STAT_RESULT: AtomicU64 = AtomicU64::new(u64::MAX);
static SEEK_RESULT: AtomicU64 = AtomicU64::new(u64::MAX);

/// 文件面取证复位（跨自检隔离）。
pub fn reset_evidence() {
    OPEN_RESULT.store(u64::MAX, Ordering::Release);
    OPEN_HANDLE.store(u64::MAX, Ordering::Release);
    READ_RESULT.store(u64::MAX, Ordering::Release);
    WRITE_RESULT.store(u64::MAX, Ordering::Release);
    CLOSE_RESULT.store(u64::MAX, Ordering::Release);
    STAT_RESULT.store(u64::MAX, Ordering::Release);
    SEEK_RESULT.store(u64::MAX, Ordering::Release);
}

// ---- 目录面取证（t50 断言面） ----
static MKDIR_RESULT: AtomicU64 = AtomicU64::new(u64::MAX);
static REMOVE_RESULT: AtomicU64 = AtomicU64::new(u64::MAX);
static READDIR_RESULT: AtomicU64 = AtomicU64::new(u64::MAX);
static MOUNT_RESULT: AtomicU64 = AtomicU64::new(u64::MAX);
static UMOUNT_RESULT: AtomicU64 = AtomicU64::new(u64::MAX);

// ---- 句柄深化取证（t51 断言面） ----
static DUP_RESULT: AtomicU64 = AtomicU64::new(u64::MAX);
static FCNTL_RESULT: AtomicU64 = AtomicU64::new(u64::MAX);

/// 目录面 + 句柄深化取证复位（跨自检隔离）。
pub fn reset_dir_evidence() {
    MKDIR_RESULT.store(u64::MAX, Ordering::Release);
    REMOVE_RESULT.store(u64::MAX, Ordering::Release);
    READDIR_RESULT.store(u64::MAX, Ordering::Release);
    MOUNT_RESULT.store(u64::MAX, Ordering::Release);
    UMOUNT_RESULT.store(u64::MAX, Ordering::Release);
    DUP_RESULT.store(u64::MAX, Ordering::Release);
    FCNTL_RESULT.store(u64::MAX, Ordering::Release);
}

/// 目录面取证快照：(MKDIR, REMOVE, READDIR, MOUNT, UMOUNT)。
pub fn dir_stamps() -> (u64, u64, u64, u64, u64) {
    (
        MKDIR_RESULT.load(Ordering::Acquire),
        REMOVE_RESULT.load(Ordering::Acquire),
        READDIR_RESULT.load(Ordering::Acquire),
        MOUNT_RESULT.load(Ordering::Acquire),
        UMOUNT_RESULT.load(Ordering::Acquire),
    )
}

/// 句柄深化取证快照：(DUP, FCNTL)。
pub fn hdeep_stamps() -> (u64, u64) {
    (
        DUP_RESULT.load(Ordering::Acquire),
        FCNTL_RESULT.load(Ordering::Acquire),
    )
}

/// 文件面取证快照：(OPEN 码, OPEN 句柄, READ 码, WRITE 码, CLOSE 码,
/// STAT 码, SEEK 码)。
pub fn stamps() -> (u64, u64, u64, u64, u64, u64, u64) {
    (
        OPEN_RESULT.load(Ordering::Acquire),
        OPEN_HANDLE.load(Ordering::Acquire),
        READ_RESULT.load(Ordering::Acquire),
        WRITE_RESULT.load(Ordering::Acquire),
        CLOSE_RESULT.load(Ordering::Acquire),
        STAT_RESULT.load(Ordering::Acquire),
        SEEK_RESULT.load(Ordering::Acquire),
    )
}

/// 文件面子系统初始化：根 ramfs 播种 + 注册表定容。
///
/// 播种面（自检与 ring3 程序的确定性基座）：
/// - `/files/hello` = "lumina-fs"（t44 读面种子）；
/// - `/files/echo` = 空（t45 环三写读回种子）；
/// - `/files/dir` = 目录（t44 EISDIR 负探针）；
/// - `/files/selftest.lxe` = [`crate::user::USER_PROGRAM`] 的 LXE1
///   运行时包装（t42 exec(0) 经 VFS 装载——行为等价、来源换 VFS）；
/// - `/files/prog.lxe` = 双段映像（t47）；
/// - `/files/grow.lxe` = 增长栈映像（t48）；
/// - `/bin/busybox` = 制备介质（M33-F1：multiboot module → 暂存面 →
///   播种；t82 busybox 活体 + execve("/bin/busybox") 路径可达基座）。
pub fn init() {
    let fs = Arc::new(RamFs::new());
    // 播种失败即初始化失败（确定性种子，容错无意义）：防御式跳过而非 panic。
    let files = fs.root_vnode();
    let _ = fs.create(files, "files", NodeKind::Dir).map(|dir| {
        let _ = fs.create(dir, "hello", NodeKind::File).map(|h| {
            let _ = fs.write_at(h, 0, b"lumina-fs");
        });
        let _ = fs.create(dir, "echo", NodeKind::File);
        let _ = fs.create(dir, "dir", NodeKind::Dir);
        // LXE1 映像播种（M14-①）：selftest 运行时包装 + 双段/增长栈生成产物
        let selftest = bedrock::exec::encode(
            crate::user::USER_CODE_VIRT,
            0,
            &[bedrock::exec::SegSpec {
                vaddr: crate::user::USER_CODE_VIRT,
                flags: bedrock::exec::FLAG_X,
                data: &crate::user::USER_PROGRAM,
                mem_len: 0x1000,
            }],
        );
        if let Ok(blob) = selftest {
            let _ = fs.create(dir, "selftest.lxe", NodeKind::File).map(|h| {
                let _ = fs.write_at(h, 0, &blob);
            });
        }
        let _ = fs.create(dir, "prog.lxe", NodeKind::File).map(|h| {
            let _ = fs.write_at(h, 0, &crate::user::PROG_LXE);
        });
        let _ = fs.create(dir, "grow.lxe", NodeKind::File).map(|h| {
            let _ = fs.write_at(h, 0, &crate::user::GROW_LXE);
        });
        // M16-② Weave 包源映像播种：prog.lxe 载荷经 LWP1 包装
        // （EXEC 第 2+ 消费者；解包策略归 sys_exec，结构面归 weave::pkg）
        if let Ok(lwp) = weave::pkg::encode(
            "org.lumina.prog",
            weave::Version {
                major: 1,
                minor: 0,
                patch: 0,
            },
            &crate::user::PROG_LXE,
        ) {
            let _ = fs.create(dir, "prog.lwp", NodeKind::File).map(|h| {
                let _ = fs.write_at(h, 0, &lwp);
            });
        }
        // M16-③ 增长栈动态扩容映像播种（触页 40/70 各触发扩窗一次）
        let _ = fs.create(dir, "deep.lxe", NodeKind::File).map(|h| {
            let _ = fs.write_at(h, 0, &crate::user::DEEP_LXE);
        });
    });
    // M33-F1：制备介质播种——/bin/busybox（module 暂存面 → 媒体文件；
    // 播种失败防御式跳过，t82 活体路径探针 fail-visible 兜底）
    if let Some(media) = take_media() {
        let _ = fs.create(files, "bin", NodeKind::Dir).map(|bin| {
            let _ = fs.create(bin, "busybox", NodeKind::File).map(|h| {
                let _ = fs.write_at(h, 0, &media);
            });
        });
    }
    let mut ns = NAMESPACE.lock();
    *ns = Some(Namespace::new(fs));
    let mut tab = FILES.lock();
    tab.clear();
    for _ in 0..MAX_FILES {
        tab.push(None);
    }
}

/// 内核侧映像整读（M14-① EXEC 装载器专用，**VFS 第二消费者**）：
/// 不走句柄面（零能力铸造、零注册表占用），路径 → 命名空间解析 →
/// `read_at` 循环至 EOF；超出 [`crate::user::EXEC_IMAGE_MAX`] 预算
/// 拒绝（None）。锁序：NAMESPACE → FileSystem 内部锁（既有单向嵌套）。
pub fn read_image(path: &str) -> Option<alloc::vec::Vec<u8>> {
    let path = PathBuf::normalize(path).ok()?;
    let (resolved, size) = {
        let ns = NAMESPACE.lock();
        let ns = ns.as_ref()?;
        let resolved = ns.resolve(&path).ok()?;
        // M33-F1：元数据预容量（busybox ~1 MiB 介质面——几何扩容峰值
        // 2× 在账避免；metadata 缺失降级空容量走旧几何路径）
        let size = resolved
            .fs
            .metadata(resolved.vnode)
            .map(|m| m.size as usize)
            .unwrap_or(0);
        (resolved, size)
    };
    let mut out = alloc::vec::Vec::with_capacity(size);
    let mut chunk = [0u8; 256];
    loop {
        let n = resolved
            .fs
            .read_at(resolved.vnode, out.len() as u64, &mut chunk)
            .ok()?;
        if n == 0 {
            break;
        }
        out.extend_from_slice(&chunk[..n]);
        if out.len() > crate::user::EXEC_IMAGE_MAX {
            return None;
        }
    }
    Some(out)
}

/// 文件注册表用量快照（M14-② SYS_QUOTA kind 1 断言面）：(used, MAX_FILES)。
pub fn files_usage() -> (usize, usize) {
    let files = FILES.lock();
    let used = files.iter().filter(|f| f.is_some()).count();
    (used, MAX_FILES)
}

// ---- M33-F1：制备介质通道（multiboot module → ramfs 媒体面） ----

/// 制备介质暂存：kmain 引导期把 module 字节域拷贝落此（帧分配器就绪
/// 后、[`init`] 前），[`init`] 一次性取走播种 `/bin/busybox`。
static STAGED_MEDIA: ostd::sync::SpinLock<Option<alloc::vec::Vec<u8>>> =
    ostd::sync::SpinLock::new(None);

/// 暂存制备介质（multiboot module 字节域拷贝产物；init 播种消费）。
pub fn stage_media(bytes: alloc::vec::Vec<u8>) {
    *STAGED_MEDIA.lock() = Some(bytes);
}

/// 取走暂存介质（[`init`] 一次性消费；None = 引导期无 module 介质）。
fn take_media() -> Option<alloc::vec::Vec<u8>> {
    STAGED_MEDIA.lock().take()
}

/// M33-F1：Linux dirent64 页打包（kernel::linux getdents64 消费面）。
///
/// 布局：d_ino(8) + d_off(8) + d_reclen(2) + d_type(1) + name + NUL，
/// 8 字节对齐收尾（Linux x86_64 同构；d_off = 稳定 cookie，v0 口径
/// 如实记档——offset 语义本为 telldir 回锚，cookie 即稳定锚）。逐项
/// 试装（半项不落盘纪律同 native 面）；成功交付项推进 OFD cookie
/// 游标。d_ino = vnode 号（免二次 lookup），d_type 映射见 [`dt_type64`]。
/// 返回交付字节数（0 = 枚举尽——Linux 语义返回 0 非错误）。
pub fn readdir64_page(handle: u64, buf: &mut [u8]) -> Result<usize, u64> {
    const DT_HDR: usize = 19; // 8 + 8 + 2 + 1
    let Some((_slot, cap, idx)) = resolve_file_object(handle) else {
        return Err(EBADF);
    };
    if cap.rights() & Right::READ.bits() == 0 {
        return Err(EBADF); // 目录枚举对齐 read：须以读方式打开
    }
    let mut files = FILES.lock();
    let f = files[idx].as_mut().ok_or(EBADF)?;
    let meta = f.fs.metadata(f.vnode).map_err(|e| e.errno())?;
    if !meta.kind.is_dir() {
        return Err(ENOTDIR);
    }
    let items = f.fs.readdir_from(f.vnode, f.pos).map_err(|e| e.errno())?;
    let mut off = 0usize;
    let mut last_cookie: Option<u64> = None;
    for it in &items {
        let name = it.entry.name.as_bytes();
        if name.len() > 255 {
            continue; // d_reclen 16 位域 + 名字单字节域防御（ramfs 单段名）
        }
        let reclen = (DT_HDR + name.len() + 1).div_ceil(8) * 8;
        if off + reclen > buf.len() {
            break; // 半项不落盘
        }
        buf[off..off + 8].copy_from_slice(&it.entry.vnode.0.to_le_bytes());
        buf[off + 8..off + 16].copy_from_slice(&it.cookie.to_le_bytes());
        buf[off + 16..off + 18].copy_from_slice(&(reclen as u16).to_le_bytes());
        buf[off + 18] = dt_type64(&it.entry.kind);
        buf[off + DT_HDR..off + DT_HDR + name.len()].copy_from_slice(name);
        buf[off + DT_HDR + name.len()] = 0;
        for b in &mut buf[off + DT_HDR + name.len() + 1..off + reclen] {
            *b = 0;
        }
        off += reclen;
        last_cookie = Some(it.cookie);
    }
    if let Some(c) = last_cookie {
        f.pos = c;
    }
    Ok(off)
}

/// NodeKind → Linux d_type（DT_*：FIFO 1/CHR 2/DIR 4/REG 8/LNK 7）。
fn dt_type64(kind: &NodeKind) -> u8 {
    match kind {
        NodeKind::File => 8,
        NodeKind::Dir => 4,
        NodeKind::CharDev { .. } => 2,
        NodeKind::Pipe => 1,
        NodeKind::Symlink => 7,
    }
}

/// 节点类型编码（SYS_STAT kind 域）：委托 bedrock 单一事实源
/// （READDIR 项首字节同一映射，宿主测试交叉钉值）。
const fn kind_code(kind: NodeKind) -> u64 {
    meridian::vfs::dir_entry_abi_code(kind) as u64
}

/// 段位判定：对象 id 是否属于文件段。
fn is_file_object(object: u64) -> bool {
    (object >> 32) == (FILE_OBJECT_BASE >> 32)
}

/// 能力表存活引用计数（M15-② 句柄面深化）：扫描全局能力表统计
/// `object` 的存活引用槽数（open 铸造 = 1，dup/跨任务授予各 +1，
/// close/revoke/EXEC-CLOEXEC 撤销后递减）。O(CAPACITY)=64 单向扫描
/// ——内核规模下常数可忽略；**引用计数即存活槽数**（零簿记、对
/// dup/grant/revoke 三条路径一致成立）。
fn caps_refcount(object: u64) -> usize {
    let t = crate::caps::table().lock();
    (0..vanguard::CAPACITY)
        .filter(|&s| t.get(s).map(|c| c.object()) == Ok(object))
        .count()
}

/// 回收孤儿文件对象（M15-②）：任务终结清算 / EXEC CLOEXEC 消费 /
/// SYS_CAP_REVOKE 撤销能力槽后，注册表中已无任何能力引用的文件对象
/// 就地回收（引用计数收敛面；close 路径的即时判定之外的补扫）。
/// 锁序：FILES → CAPS（本模块新墢单向链，无反向边）。
pub fn reap_orphaned_files() {
    let mut files = FILES.lock();
    for slot in files.iter_mut() {
        let Some(f) = slot.as_ref() else {
            continue;
        };
        if caps_refcount(f.object) == 0 {
            *slot = None;
        }
    }
}

/// 句柄解析共用切片（M13-②）：调用方句柄 → (全局槽, 能力, 文件槽)。
/// NULL/越界/未持有/全局槽失效/非文件段/注册表无此对象 → None（对外
/// 同面 EBADF——与通道面「无效句柄同面不泄拓扑」纪律一致）。
/// M35-BBb：句柄 0 解禁（stdio 重定向接线域——接线铸槽可装句柄 0，
/// 解析面与文件/管道域同面；句柄 0 既有路径恒空，仅接线域可非空）。
fn resolve_file_object(handle: u64) -> Option<(usize, Capability, usize)> {
    let caller = task::current_task_id();
    let h = handle as usize;
    if h >= task::HANDLE_MAX {
        return None;
    }
    let slot = task::with_task_handles(caller, |t| t[h]).and_then(|s| s)?;
    let cap = crate::caps::table().lock().get(slot).ok()?;
    if !is_file_object(cap.object()) {
        return None;
    }
    let object = cap.object();
    let idx = {
        let files = FILES.lock();
        files
            .iter()
            .position(|f| f.as_ref().is_some_and(|f| f.object == object))?
    };
    Some((slot, cap, idx))
}

/// SYS_OPEN 主体（M13-② 立；**M16-① 文件创建面**）：路径解析 →
/// 文件对象铸造 → 统一句柄面安装。
///
/// 全链（调用方任务上下文，串行）：
/// 1. 参数面：mode 访问位（低 2 位）非零且 ≤ [`bedrock::abi::
///    OPEN_MODE_MASK`]（否则 EINVAL）；路径切片校验（EFAULT）；
///    UTF-8（EINVAL）；[`PathBuf::normalize`] + 命名空间解析（FsError
///    → Conduit 口径 errno）；**O_CREAT**：目标缺失时经父走查新建
///    常规文件（中间缺失 → ENOENT；已存在直接打开——v0 无 O_EXCL）；
/// 2. **O_TRUNC**：以可写方式打开成功后将节点截零（只读不截——
///    v0 简化语义，目录 → EISDIR）；
/// 3. 调用方句柄表首空闲位预检（满 → EMFILE，先验免泄漏）；
/// 4. 注册表槽位 + 对象 id 铸造（满 → ENFILE）；
/// 5. 能力铸造（READ|WRITE 按访问位子集）入全局表（满 → 回滚注册
///    表槽 → ENOMEM）+ 安装调用方句柄表。
///
/// 成功返回 `(1 << 32) | handle`。目录可以打开（读目录 → EISDIR，
/// M13-① fd 表同款语义）。取证面：OPEN_RESULT/OPEN_HANDLE。
pub fn sys_open(path_ptr: u64, len: u64, mode: u64) -> u64 {
    // 1) 参数面：访问位非零 + 保留位拒收（结构域细节见 abi SYS_OPEN 文档）
    if mode & 0b11 == 0 || mode & !bedrock::abi::OPEN_MODE_MASK != 0 || len == 0 {
        OPEN_RESULT.store(EINVAL, Ordering::Release);
        return EINVAL;
    }
    let Some(path_bytes) = validate_user_slice(path_ptr, len) else {
        OPEN_RESULT.store(EFAULT, Ordering::Release);
        return EFAULT;
    };
    sys_open_bytes(path_bytes, mode)
}

/// OPEN 字节面内核入口（M34-B1）：路径字节串由调用方持有（Linux 面相对
/// 路径 cwd join 后的内核侧字节域——[`crate::linux::lin_path_bytes`]）；
/// 参数域校验 + 取证面与 [`sys_open`] 同源。
pub fn sys_open_bytes(path_bytes: &[u8], mode: u64) -> u64 {
    if mode & 0b11 == 0 || mode & !bedrock::abi::OPEN_MODE_MASK != 0 || path_bytes.is_empty() {
        OPEN_RESULT.store(EINVAL, Ordering::Release);
        return EINVAL;
    }
    let r = open_impl(path_bytes, mode);
    if r >> 32 == 1 {
        OPEN_RESULT.store(0, Ordering::Release);
        OPEN_HANDLE.store(r & 0xFFFF_FFFF, Ordering::Release);
    } else {
        OPEN_RESULT.store(r, Ordering::Release);
    }
    r
}

/// OPEN 内聚链（取证外的纯逻辑；错误域 = errno）。M16-①：O_CREAT
/// 缺失创建 + O_TRUNC 可写截断。
fn open_impl(path_bytes: &[u8], mode: u64) -> u64 {
    let Ok(path_str) = core::str::from_utf8(path_bytes) else {
        return FsError::InvalidPath.errno();
    };
    let Ok(path) = PathBuf::normalize(path_str) else {
        return FsError::InvalidPath.errno();
    };
    let o_creat = mode & bedrock::abi::O_CREAT != 0;
    let o_trunc = mode & bedrock::abi::O_TRUNC != 0;
    let o_excl = mode & bedrock::abi::O_EXCL != 0;
    // 首次解析（守卫块内自持：锁不可重入，父走查前必须释放）
    let pre = {
        let ns = NAMESPACE.lock();
        let Some(ns) = ns.as_ref() else {
            return EBADF; // 未初始化：防御路径（自检序保证不达）
        };
        match ns.resolve(&path) {
            Ok(r) => {
                // M18-③ O_EXCL：O_CREAT|O_EXCL 且目标已存在 → EEXIST
                // 原子拒开（fs create 自身检查在锁内，无插队窗口）。
                if o_creat && o_excl {
                    return FsError::AlreadyExists.errno();
                }
                Some(r)
            }
            Err(FsError::NotFound) if o_creat => None, // M16-①：走创建链
            Err(e) => return e.errno(),
        }
    };
    let resolved = match pre {
        Some(r) => r,
        // M16-① O_CREAT：目标缺失 → 父走查新建常规文件后重解析
        None => {
            let (fs, dir, leaf) = match resolve_parent(&path) {
                Ok(r) => r,
                Err(e) => return e,
            };
            match fs.create(dir, &leaf, NodeKind::File) {
                Ok(_) => {}
                // M18-③ O_EXCL：创建竞窗内他者抢先落位 → EEXIST 拒开
                //（fs create 检查在 fs 锁内——排他语义原子面收口）。
                Err(FsError::AlreadyExists) if o_excl => {
                    return FsError::AlreadyExists.errno();
                }
                Err(FsError::AlreadyExists) => {} // 已存在：直接打开
                Err(e) => return e.errno(),
            }
            let ns = NAMESPACE.lock();
            let Some(ns) = ns.as_ref() else {
                return EBADF;
            };
            match ns.resolve(&path) {
                Ok(r) => r,
                Err(e) => return e.errno(),
            }
        }
    };
    // M39-MU 权限域门禁（登记制——未登记路径零扰动；O_TRUNC 前置——
    // 拒绝域不得截断）：登记路径对当前任务凭据判定，拒绝 EACCES。
    // M40-CRYSTAL 双车道：未登记路径 → 盘上属主回源判定（disk_perm_
    // lookup——resolve 节点 metadata 真面；解析失败维持既有口径）。
    {
        let want = if mode & 0b10 != 0 {
            PERM_WANT_READ | PERM_WANT_WRITE
        } else {
            PERM_WANT_READ
        };
        if let Some((owner, pmode)) = perm_lookup(path.as_str()) {
            if !perm_check(owner, 0, pmode, want) {
                return EACCES;
            }
        } else if let Some((owner, gid, pmode)) = disk_perm_lookup(path.as_str()) {
            if !perm_check(owner, gid, pmode, want) {
                return EACCES;
            }
        }
    }
    // M16-① O_TRUNC：可写打开成功后截零（只读不截；目录 → EISDIR）。
    // 截断在对象安装前执行，失败路径不铸能力/不占注册表槽。
    if o_trunc && mode & 0b10 != 0 {
        if let Err(e) = resolved.fs.truncate(resolved.vnode) {
            return e.errno();
        }
    }
    // 2) 调用方句柄表空闲位预检（满 → EMFILE，先验免泄漏）。
    // M39-BBLS stdio 保留域：lin_abi 任务 fd 0/1/2 = stdio 虚拟控制台
    // 保留域（Linux 进程语义——open 槽搜索自 3 起；与 fstat fd<3 字符
    // 设备合成 / lin_write fd 1/2 控制台回退同源语义的搜索面收口）。
    // 揭雷回溯：本缺口下 applet「先开后写」stdout 全数被首开句柄互踩
    // 吞没（t92 ls 实录——opendir 拾 fd 1 → stdio_redirect_active(1)
    // → writev(1) 写目录 EBADF raw=0x9，95 B 输出域蒸发；t83 wc 计数
    // 行同伤回溯在案——仅因内容级断言缺席而隐匿）；dup2/接线域不受
    // 此限（直接写槽——sh 管道 dup2 等价面语义保持）。原生任务搜索
    // 面 skip(1) 不变（句柄 0 = NULL 保留，M9-A）。
    let caller = task::current_task_id();
    let stdio_reserved = task::task_is_lin_abi(caller);
    let search_from = if stdio_reserved { 3 } else { 1 };
    let free = task::with_task_handles(caller, |t| {
        t.iter()
            .enumerate()
            .skip(search_from)
            .find_map(|(h, s)| s.is_none().then_some(h))
    });
    let Some(Some(free_handle)) = free else {
        return EMFILE;
    };
    // 3) 注册表槽位 + 对象 id
    let object = NEXT_OBJECT.fetch_add(1, Ordering::AcqRel);
    let Some(flags) = OpenFlags::from_bits((mode & 0b11) as u8) else {
        // M16-① 模式域扩展：from_bits 只收访问位（低 2 位）；O_CREAT/
        // O_TRUNC 修饰位不参与访问位判定（保留位已在参数面拒收）
        return FsError::InvalidPath.errno(); // 结构面已验；防御分支
    };
    let file = FileObject {
        object,
        fs: resolved.fs.clone(),
        vnode: resolved.vnode,
        pos: 0,
        readable: flags.readable(),
        writable: flags.writable(),
    };
    // 3b) 注册表槽位占用（ENFILE 自愈重试：幽灵对象补扫——M19-① 根因
    // 修复。轮内 open 的任务终结面 reap 竞态残留幽灵槽（32 槽贴线泄漏，
    // round-239 快照 used=32/caps_alive=2 实锤），补扫回收后重试一次；
    // 自愈失败才真正 ENFILE）。
    let mut slot_idx = None;
    for attempt in 0..2 {
        let mut files = FILES.lock();
        match files
            .iter_mut()
            .enumerate()
            .find_map(|(i, f)| f.is_none().then_some(i))
        {
            Some(i) => {
                files[i] = Some(file);
                slot_idx = Some(i);
                break;
            }
            None if attempt == 0 => {
                // 现场指纹（seq 区分多轮；reap 前采样）
                static SNAP_SEQ: AtomicU64 = AtomicU64::new(0);
                let used = files.iter().filter(|f| f.is_some()).count();
                let caps_alive = (0..vanguard::CAPACITY)
                    .filter(|&s| crate::caps::table().lock().get(s).is_ok())
                    .count();
                let seq = SNAP_SEQ.fetch_add(1, Ordering::AcqRel) + 1;
                ENFILE_SNAP.store(
                    (seq & 0xF) << 56 | (used as u64) << 40 | (caps_alive as u64) << 24,
                    Ordering::Release,
                );
                drop(files);
                reap_orphaned_files();
            }
            None => break,
        }
    }
    let Some(idx) = slot_idx else {
        return ENFILE;
    };
    // 4) 能力铸造 + 句柄安装（失败路径回滚注册表槽）
    let mut rights = 0u32;
    if flags.readable() {
        rights |= Right::READ.bits();
    }
    if flags.writable() {
        rights |= Right::WRITE.bits();
    }
    let gslot = crate::caps::alloc_slot(Capability::new(object, rights));
    let installed = gslot
        .map(|g| task::with_task_handles(caller, |t| t[free_handle] = Some(g)).is_some())
        .unwrap_or(false);
    if !installed {
        if let Some(g) = gslot {
            let _ = crate::caps::table().lock().revoke(g);
        }
        FILES.lock()[idx] = None;
        return ENOMEM;
    }
    OK_BIT | free_handle as u64
}

/// SYS_READ 主体（M13-② 立；M35-BBa 管道分流）：句柄 → 文件/管道对象 →
/// OFD 偏移读或环核读。成功返回 `(1 << 32) | count`（0 = EOF）。
pub fn sys_read(handle: u64, buf_ptr: u64, len: u64) -> u64 {
    if len == 0 {
        READ_RESULT.store(EINVAL, Ordering::Release);
        return EINVAL;
    }
    let Some(buf) = validate_user_slice_mut(buf_ptr, len) else {
        READ_RESULT.store(EFAULT, Ordering::Release);
        return EFAULT;
    };
    let r = if let Some((_slot, cap, pipe)) = resolve_pipe_object(handle) {
        // M35-BBa 管道分流；M36-BB3 阻塞面（EOF/阻塞语义见
        // pipe_read_blocking——成功读出即唤醒写端等待者）。
        if cap.rights() & Right::READ.bits() == 0 {
            Err(EBADF)
        } else {
            pipe_read_blocking(&pipe, buf).inspect(|_| wake_pipe_writers(&pipe))
        }
    } else {
        let Some((_slot, cap, idx)) = resolve_file_object(handle) else {
            READ_RESULT.store(EBADF, Ordering::Release);
            return EBADF;
        };
        if cap.rights() & Right::READ.bits() == 0 {
            READ_RESULT.store(EBADF, Ordering::Release);
            return EBADF;
        }
        {
            let mut files = FILES.lock();
            match files[idx].as_mut() {
                Some(f) if f.readable => match f.fs.read_at(f.vnode, f.pos, buf) {
                    Ok(n) => {
                        f.pos += n as u64;
                        Ok(n)
                    }
                    Err(e) => Err(e.errno()),
                },
                Some(_) | None => Err(EBADF),
            }
        }
    };
    let code = match r {
        Ok(n) => OK_BIT | n as u64,
        Err(e) => e,
    };
    READ_RESULT.store(code, Ordering::Release);
    code
}

/// SYS_WRITE 主体（M13-②）：句柄 → 文件对象 → OFD 偏移写 → 偏移推进。
/// 成功返回 `(1 << 32) | count`。
pub fn sys_write(handle: u64, buf_ptr: u64, len: u64) -> u64 {
    if len == 0 {
        WRITE_RESULT.store(EINVAL, Ordering::Release);
        return EINVAL;
    }
    let Some(buf) = validate_user_slice(buf_ptr, len) else {
        WRITE_RESULT.store(EFAULT, Ordering::Release);
        return EFAULT;
    };
    let r = if let Some((_slot, cap, pipe)) = resolve_pipe_object(handle) {
        // M35-BBa 管道分流；M36-BB3 阻塞面（EPIPE/阻塞语义见
        // pipe_write_blocking——成功写入即唤醒读端等待者）。
        if cap.rights() & Right::WRITE.bits() == 0 {
            Err(EBADF)
        } else {
            pipe_write_blocking(&pipe, buf).inspect(|_| wake_pipe_readers(&pipe))
        }
    } else {
        let Some((_slot, cap, idx)) = resolve_file_object(handle) else {
            WRITE_RESULT.store(EBADF, Ordering::Release);
            return EBADF;
        };
        if cap.rights() & Right::WRITE.bits() == 0 {
            WRITE_RESULT.store(EBADF, Ordering::Release);
            return EBADF;
        }
        {
            let mut files = FILES.lock();
            match files[idx].as_mut() {
                Some(f) if f.writable => match f.fs.write_at(f.vnode, f.pos, buf) {
                    Ok(n) => {
                        f.pos += n as u64;
                        Ok(n)
                    }
                    Err(e) => Err(e.errno()),
                },
                Some(_) | None => Err(EBADF),
            }
        }
    };
    let code = match r {
        Ok(n) => OK_BIT | n as u64,
        Err(e) => e,
    };
    WRITE_RESULT.store(code, Ordering::Release);
    code
}

/// SYS_CLOSE 主体（M13-②；**M15-② 深化；M35-BBa 管道分支；M42-UNIX3
/// socket 分支**）：句柄回收（任务表 + 全局槽 + 对象面收敛）。五分支：
/// 1. 文件对象：撤销全局槽后按 [`caps_refcount`] 判定——仍有存活引用
///    （dup 副本/跨任务授予/fork 继承）则对象保留（关闭一副本不影响
///    其余副本，POSIX dup 语义），归零才释放注册表槽；
/// 2. 通道对象（[`crate::ipc::is_channel_object`]）：**通道句柄关闭
///    落点**（v0 bind 存续语义补全）——句柄 + 全局槽回收，通道对象
///    （环对 + 注册表槽）存续不回收（bind 存续纪律不变）；
/// 3. socket 对象（[`crate::unixsock::is_socket_object`]，M42-UNIX3）：
///    端点/监听者句柄关闭落点——句柄 + 全局槽回收，对象存续不回收
///    （v0 注册表存续纪律；EOF/回收面随阶段三挂账）；
/// 4. 管道端对象（M35-BBa）：撤销全局槽后按 [`caps_refcount`] 判定——
///    端引用归零才释放 PIPES 注册表槽（EOF/EPIPE 判定键随引用计数
///    动态收敛，无需显式端闭标记）；
/// 5. 其余对象（主身份句柄等）：原样保留回插，EBADF（绝不消费他面
///    ——段位/注册表双重守门）。
///
/// 成功路径同时清除该句柄 CLOEXEC 旗标（同号复用不继承陈值）。
pub fn sys_close(handle: u64) -> u64 {
    let caller = task::current_task_id();
    let h = handle as usize;
    let code = if h == 0 || h >= task::HANDLE_MAX {
        EBADF
    } else {
        let taken = task::with_task_handles(caller, |t| t[h].take());
        match taken {
            Some(Some(g)) => {
                let object = crate::caps::table().lock().get(g).map(|c| c.object());
                match object {
                    Ok(o) if is_file_object(o) => {
                        let _ = crate::caps::table().lock().revoke(g);
                        if caps_refcount(o) == 0 {
                            let mut files = FILES.lock();
                            if let Some(i) = files
                                .iter()
                                .position(|f| f.as_ref().is_some_and(|f| f.object == o))
                            {
                                files[i] = None;
                            }
                        }
                        task::clear_hflag(caller, h);
                        0
                    }
                    Ok(o) if crate::ipc::is_channel_object(o) => {
                        // M15-② 通道句柄关闭落点：句柄/能力回收，对象存续
                        let _ = crate::caps::table().lock().revoke(g);
                        task::clear_hflag(caller, h);
                        0
                    }
                    Ok(o) if crate::unixsock::is_socket_object(o) => {
                        // M42-UNIX3 socket 句柄关闭落点（端点/监听者同一
                        // 守门面）：句柄/能力回收，对象存续（v0 注册表
                        // 存续纪律——通道分支同款）。M42-COMP4：终结旗标
                        // 随行置位（mark_closed_by_object——对象行存续 +
                        // 流终结双域分离：对端 recv 排空后 0 = EOF 显形）
                        let _ = crate::caps::table().lock().revoke(g);
                        task::clear_hflag(caller, h);
                        crate::unixsock::mark_closed_by_object(o);
                        0
                    }
                    Ok(o) if crate::shm::is_pool_object(o) => {
                        // M42-WAYCOMP11 池句柄关闭落点（wl_shm.destroy 语义
                        // 面——句柄/能力回收 + 引用归零池回收）：撤销后引用
                        // 计数收敛（管道臂同款纪律——fd 传递存续池引用 > 0
                        // 延迟回收 fail-visible；引用归零即帧归还 + 注册表
                        // 摘除，shm::release_if_unreferenced 同心出口）。
                        let _ = crate::caps::table().lock().revoke(g);
                        task::clear_hflag(caller, h);
                        crate::shm::release_if_unreferenced(o);
                        0
                    }
                    Ok(o) if is_pipe_object(o) => {
                        // M35-BBa 管道端句柄关闭落点：撤销后引用归零才清
                        // PIPES 槽（EOF/EPIPE 键动态收敛——fork 继承副本
                        // 存活期间端不闭，POSIX 语义）。M36-BB3：末引用
                        // 终结即对端等待者死亡唤醒（写端亡 → EOF 逃逸唤
                        // 醒读等待者 / 读端亡 → EPIPE 逃逸唤醒写等待者；
                        // syscall 上下文无 SCHED 锁持有——wake_tasks 直通
                        // 面；revoke 链终结路径同域唤醒见
                        // task::wake_pipes_locked 锁内版）。
                        let _ = crate::caps::table().lock().revoke(g);
                        if caps_refcount(o) == 0 {
                            let dead = PIPES.lock().iter().find_map(|p| {
                                p.as_ref()
                                    .filter(|p| p.object == o)
                                    .map(|p| (p.object, p.pipe.clone()))
                            });
                            let mut pipes = PIPES.lock();
                            if let Some(i) = pipes
                                .iter()
                                .position(|p| p.as_ref().is_some_and(|p| p.object == o))
                            {
                                pipes[i] = None;
                            }
                            drop(pipes);
                            if let Some((_, pipe)) = dead {
                                let died_write = pipe.w_object.load(Ordering::Acquire) == o;
                                if died_write {
                                    wake_pipe_readers(&pipe);
                                } else {
                                    wake_pipe_writers(&pipe);
                                }
                            }
                        }
                        task::clear_hflag(caller, h);
                        0
                    }
                    _ => {
                        // 非文件/通道对象：回插原句柄（不消费他面），EBADF
                        task::with_task_handles(caller, |t| t[h] = Some(g));
                        EBADF
                    }
                }
            }
            _ => EBADF,
        }
    };
    CLOSE_RESULT.store(code, Ordering::Release);
    code
}

// ---- M35-BBa 管道执行面（SYS_PIPE2 + fork fd 继承消费方） ----
// ---- M36-BB3 阻塞式管道 I/O（Linux 对齐）：默认阻塞 + O_NONBLOCK 旗标 ----

/// 管道定容（64 KiB——M35 裁决注 ⑤）。
const PIPE_CAP: usize = 65536;
/// O_CLOEXEC（Linux 号域 0x80000——pipe2 旗标随链 hflags FD_CLOEXEC 面）。
const O_CLOEXEC: u64 = 0o200_0000;
/// O_NONBLOCK（Linux x86_64 号域 0o4000——pipe2 旗标；M36-BB3 收录）。
/// 置位 = 本管道双端非阻塞语义（空环读 / 满环写 → `EAGAIN` 立返）；
/// 缺省 = Linux 同款阻塞语义（等待队列面——见 [`pipe_read_blocking`]）。
const O_NONBLOCK: u64 = 0o4000;
/// 管道对象 id 铸造计数（单调，段位 [`PIPE_OBJECT_BASE`]）。
static NEXT_PIPE_OBJECT: AtomicU64 = AtomicU64::new(PIPE_OBJECT_BASE);

// ---- M39-MU 权限域覆盖表（v0 领域门禁——单一事实源） ----

/// 权限域登记条目：路径（规范化字符串）+ 属主 uid + mode 九位域。
/// 盘上属主域随 crystal 节点格式批次续作（M39-计划 口径注③如实登记）
/// ——本表为 v0 kernel 侧单一事实源，登记面 = 内核原生 API（t93 领域
/// 换装消费 + 未来 chown/chmod 车道承接位）。
struct PermEntry {
    /// 规范化路径（PERMS 表键）。
    path: alloc::string::String,
    /// 属主用户 ID。
    owner: u32,
    /// 权限九位域（owner/group/other × rwx；v0 组属主未登记——group
    /// 位域按 other 位域处理，偏差如实登记随行）。
    mode: u16,
}

/// 权限域覆盖表容量（定容 fail-visible——满容 EAGAIN 域拒绝登记）。
const PERM_CAP: usize = 16;
/// 权限域覆盖表（登记制——未登记路径不受门禁，v0 领域口径）。
static PERMS: SpinLock<Vec<Option<PermEntry>>> = SpinLock::new(alloc::vec::Vec::new());

/// 权限域登记（M39-MU）：路径 + 属主 + mode 九位域；重复路径覆盖写
/// （登记面幂等——chmod/chown 车道同款语义），满容 fail-visible。
pub fn perm_install(path: &str, owner: u32, mode: u16) -> Result<(), u64> {
    let normalized = PathBuf::normalize(path).map_err(|e| e.errno())?;
    let mut perms = PERMS.lock();
    for slot in perms.iter_mut().flatten() {
        if slot.path == normalized.as_str() {
            slot.owner = owner;
            slot.mode = mode & 0o777;
            return Ok(());
        }
    }
    if perms.len() < PERM_CAP {
        perms.push(Some(PermEntry {
            path: alloc::string::String::from(normalized.as_str()),
            owner,
            mode: mode & 0o777,
        }));
        return Ok(());
    }
    Err(ENOMEM)
}

/// 权限域摘除（M39-MU）：路径命中摘槽；缺席幂等成功。
pub fn perm_remove(path: &str) -> Result<(), u64> {
    let normalized = PathBuf::normalize(path).map_err(|e| e.errno())?;
    let mut perms = PERMS.lock();
    for slot in perms.iter_mut() {
        if slot.as_ref().is_some_and(|e| e.path == normalized.as_str()) {
            *slot = None;
            return Ok(());
        }
    }
    Ok(())
}

/// 权限域查询（门禁消费面）：返回 (owner, mode)。
fn perm_lookup(normalized: &str) -> Option<(u32, u16)> {
    let perms = PERMS.lock();
    perms
        .iter()
        .flatten()
        .find_map(|e| (e.path == normalized).then_some((e.owner, e.mode)))
}

/// 权限域门禁字节面（faccessat 消费；M40-CRYSTAL 双车道）：① PERMS
/// 登记命中 → 登记制判定（M39-MU 语义零扰动，gid 恒 0）；② 未登记 →
/// 盘上属主回源判定（disk_perm_lookup——解析节点 metadata 真面）。
/// 两车道均未命中 → None（调用方维持既有口径）。
pub fn access_gate_bytes(path_bytes: &[u8], want: u16) -> Option<u64> {
    let path = normalize_user_path(path_bytes).ok()?;
    if let Some((owner, pmode)) = perm_lookup(path.as_str()) {
        return Some(if perm_check(owner, 0, pmode, want) {
            0
        } else {
            EACCES
        });
    }
    let (owner, gid, pmode) = disk_perm_lookup(path.as_str())?;
    Some(if perm_check(owner, gid, pmode, want) {
        0
    } else {
        EACCES
    })
}

/// 权限判定（M39-MU 门禁核心；M40-CRYSTAL 组属主落域）：root(uid 0)
/// 旁路；owner/group/other 三位域对 want 位域（POSIX rwx 位值：4/2/1）
/// 全量满足方放行。gid 入参 = 节点组属主（PERMS 登记域恒 0——v0 登记
/// 面无 gid 槽，盘上回源域带真 gid）。
fn perm_check(owner: u32, gid: u32, mode: u16, want: u16) -> bool {
    let caller = task::current_task_id();
    let Some(creds) = task::task_creds(caller) else {
        return false; // 防御域：凭据缺失一律拒绝（fail-visible）
    };
    if creds.uid == 0 {
        return true; // root 旁路
    }
    let bits: u16 = if creds.uid == owner {
        (mode >> 6) & 0o7
    } else if creds.gid == gid || creds.has_group(gid) {
        // M41-笔③：组位域判定扩补充组命中（creds.gid 主组或补充组
        // 任一命中 → group 位域——POSIX in_group_p 同款语义）
        (mode >> 3) & 0o7
    } else {
        mode & 0o7
    };
    want & bits == want
}

/// 盘上属主回源判定（M40-CRYSTAL 门禁回源制第二车道）：路径解析节点
/// → fs.metadata 盘上属主域（uid/gid/mode）→ perm_check 三元判定。
/// 解析失败 / 越域 → None（调用方维持既有口径——语义零扰动）。
fn disk_perm_lookup(path: &str) -> Option<(u32, u32, u16)> {
    let pb = PathBuf::normalize(path).ok()?;
    let ns = NAMESPACE.lock();
    let resolved = ns.as_ref()?.resolve(&pb).ok()?;
    let meta = resolved.fs.metadata(resolved.vnode).ok()?;
    Some((u32::from(meta.uid), u32::from(meta.gid), meta.mode))
}

/// 门禁位域映射（POSIX access 位值）：读 4 / 写 2。
const PERM_WANT_READ: u16 = 4;
const PERM_WANT_WRITE: u16 = 2;
/// 权限拒绝（M39-MU 门禁域）。
const EACCES: u64 = 13;

/// 管道注册表：槽位按对象 id 反查（FILES/CHANNELS 同构）。
static PIPES: SpinLock<Vec<Option<PipeEntry>>> = SpinLock::new(alloc::vec::Vec::new());
/// 管道面容量（与 MAX_FILES 同档）。
const MAX_PIPES: usize = 32;

/// 管道环核：定容环形字节缓冲 + 端对象 id（EOF/EPIPE 判定键 = 对端能力
/// 存活引用——与 FILE 域 [`caps_refcount`] 收敛面同源：fork 继承/dup 的
/// 新槽铸入即对端存活，全撤即端闭）。
///
/// M36-BB3 阻塞面增量：
/// - `nonblock`：铸造时旗标定格（pipe2 O_NONBLOCK——双端一体，Linux
///   同款）；`false`（缺省）= 阻塞语义，空环读 / 满环写在 syscall 层
///   等待队列面阻塞（[`pipe_read_blocking`]/[`pipe_write_blocking`]）；
/// - `avail`：环内可读字节数的原子哨兵（锁窗内更新、锁外自由读）——
///   阻塞探针（SCHED 锁窗口内运行）**不得取环锁**（SCHED → VFS 会与
///   写路径 VFS → SCHED 唤醒嵌套成环），环状态经本哨兵无锁读出；
///   对端存续仍走 [`caps_refcount`] 权威（SCHED → CAPS 单向，与
///   FILES → CAPS 既有链同向无环）。
struct Pipe {
    /// 定容环形字节缓冲。
    ring: SpinLock<PipeRing>,
    /// 读端对象 id（写路径 EPIPE 判定键）。
    r_object: AtomicU64,
    /// 写端对象 id（读路径 EOF 判定键）。
    w_object: AtomicU64,
    /// O_NONBLOCK 定格（铸造时定，双端一体）。
    nonblock: bool,
    /// 环内可读字节数哨兵（环锁内写、探针锁外读——丢失唤醒免疫链的
    /// 无锁读端）。
    avail: AtomicUsize,
}

struct PipeRing {
    data: Vec<u8>,
    head: usize,
    len: usize,
}

/// 管道注册表条目（object → 环核共享句柄）。
struct PipeEntry {
    object: u64,
    pipe: Arc<Pipe>,
}

impl Pipe {
    fn new(r_object: u64, w_object: u64, nonblock: bool) -> Self {
        Self {
            ring: SpinLock::new(PipeRing {
                data: alloc::vec![0u8; PIPE_CAP],
                head: 0,
                len: 0,
            }),
            r_object: AtomicU64::new(r_object),
            w_object: AtomicU64::new(w_object),
            nonblock,
            avail: AtomicUsize::new(0),
        }
    }

    /// 读：空环 + 写端引用归零 → EOF（`Ok(0)`）；空环 + 写端存活 →
    /// `EAGAIN`（O_NONBLOCK 管道语义；缺省阻塞管道该分支由
    /// [`pipe_read_blocking`] 等待队列面承接后重试）；否则出环
    /// `n = min(len, 存量)` 并推进 [`Pipe::avail`] 哨兵。
    fn read(&self, buf: &mut [u8]) -> Result<usize, u64> {
        if buf.is_empty() {
            return Err(EINVAL);
        }
        let mut ring = self.ring.lock();
        if ring.len == 0 {
            return if caps_refcount(self.w_object.load(Ordering::Acquire)) == 0 {
                Ok(0)
            } else {
                Err(EAGAIN)
            };
        }
        let n = buf.len().min(ring.len);
        for (i, slot) in buf.iter_mut().take(n).enumerate() {
            *slot = ring.data[(ring.head + i) % PIPE_CAP];
        }
        ring.head = (ring.head + n) % PIPE_CAP;
        ring.len -= n;
        self.avail.store(ring.len, Ordering::Release);
        Ok(n)
    }

    /// 写：读端引用归零 → `EPIPE`（SIGPIPE 递送面挂账）；满环 →
    /// `EAGAIN`（O_NONBLOCK 管道语义；缺省阻塞管道由
    /// [`pipe_write_blocking`] 承接）；否则入环部分写 `n = min(len, free)`
    /// （Linux 非阻塞写同形）并推进 [`Pipe::avail`] 哨兵。
    fn write(&self, buf: &[u8]) -> Result<usize, u64> {
        if buf.is_empty() {
            return Err(EINVAL);
        }
        let mut ring = self.ring.lock();
        if caps_refcount(self.r_object.load(Ordering::Acquire)) == 0 {
            return Err(EPIPE);
        }
        let free = PIPE_CAP - ring.len;
        if free == 0 {
            return Err(EAGAIN);
        }
        let n = buf.len().min(free);
        for (i, &b) in buf.iter().take(n).enumerate() {
            let at = (ring.head + ring.len + i) % PIPE_CAP;
            ring.data[at] = b;
        }
        ring.len += n;
        self.avail.store(ring.len, Ordering::Release);
        Ok(n)
    }
}

// ---- M36-BB3 阻塞式管道 I/O 等待队列面（Linux 对齐） ----

/// 管道读阻塞尝试计数（诊断/活体证据面——t87 断言域；语义同 ipc
/// `RECV_BLOCKS`：进入阻塞点即落证，探针命中回滚亦计入尝试面）。
static PIPE_R_BLOCKS: AtomicU64 = AtomicU64::new(0);
/// 管道写阻塞尝试计数。
static PIPE_W_BLOCKS: AtomicU64 = AtomicU64::new(0);
/// 管道读真实唤醒计数（block 返 true = 已阻塞且被唤醒；探针命中
/// 返 false 不计）。
static PIPE_R_WAKES: AtomicU64 = AtomicU64::new(0);
/// 管道写真实唤醒计数。
static PIPE_W_WAKES: AtomicU64 = AtomicU64::new(0);

/// 管道阻塞面诊断快照（M36-BB3）：`(读尝试, 写尝试, 读唤醒, 写唤醒)`
/// ——尝试面 = 进入阻塞点即计（探针命中回滚亦计，ipc `RECV_BLOCKS`
/// 同款口径）；唤醒面 = 真实阻塞后唤醒才计。消费方 = t87 阻塞活体
/// 四相位断言域（M36-BB3b——分域增量锚 + 唤醒证据，见 ROADMAP M36 行）。
pub fn pipe_block_stats() -> (u64, u64, u64, u64) {
    (
        PIPE_R_BLOCKS.load(Ordering::Acquire),
        PIPE_W_BLOCKS.load(Ordering::Acquire),
        PIPE_R_WAKES.load(Ordering::Acquire),
        PIPE_W_WAKES.load(Ordering::Acquire),
    )
}

/// 管道阻塞读（M36-BB3；t87 首跑根治探针极性——BB3a 误挂就绪语义于
/// still_pending 契约位，空环读自旋空转）：`O_NONBLOCK` 管道单发直返；
/// 缺省阻塞管道空环 + 写端存活时登记 `WaitWhat::PipeRead` 等待并协作
/// 式让出，唤醒 / 探针命中后重试（真判定在 [`Pipe::read`] 环锁内重做
/// ——虚假唤醒由重试循环自然收敛，ipc 阻塞接收同款范式）。
///
/// 丢失唤醒免疫（三链完备）：
/// 1. 写方成功写 → 唤醒链（[`pipe_write_blocking`] 成功路径 wake）；
/// 2. 写端终结（close/revoke 末引用）→ 对端唤醒链（[`sys_close`] 管道
///    分支 + [`task::revoke_all_handles`] 锁内死亡唤醒 [`task::wake_pipes_locked`]）；
/// 3. 登记与探针同 SCHED 锁窗口（[`task::block_current_unless`]）——
///    探针读 `avail` 哨兵 + `caps_refcount` 权威，锁序 SCHED → CAPS
///    单向（与 FILES → CAPS 既有链同向，无环）。
fn pipe_read_blocking(pipe: &Pipe, buf: &mut [u8]) -> Result<usize, u64> {
    loop {
        match pipe.read(buf) {
            // EAGAIN 只在「环空 + 写端存活」出环——阻塞条件成立域
            Err(EAGAIN) if !pipe.nonblock => {
                PIPE_R_BLOCKS.fetch_add(1, Ordering::AcqRel);
                let object = pipe.r_object.load(Ordering::Acquire);
                if task::block_current_unless(
                    task::WaitWhat::PipeRead { object },
                    true,
                    // 探针 = still_pending 契约（swap still_pending / ipc
                    // pending 哨兵同款——返 true = 条件未就绪继续阻塞）：
                    // 环空 + 写端存活 = 仍需等待；环非空（数据）或写端亡
                    // （EOF 逃逸）任一成立即就绪（false → 锁窗回滚重试消费）。
                    || {
                        pipe.avail.load(Ordering::Acquire) == 0
                            && caps_refcount(pipe.w_object.load(Ordering::Acquire)) != 0
                    },
                ) {
                    PIPE_R_WAKES.fetch_add(1, Ordering::AcqRel);
                }
            }
            r => return r,
        }
    }
}

/// 管道阻塞写（M36-BB3）：满环 + 读端存活时登记 `WaitWhat::PipeWrite`
/// 等待；唤醒 / 探针命中后重试（EPIPE 优先于满环判定——读端终结的
/// 阻塞写方经等待队列逃逸而非永久滞留）。丢失唤醒免疫三链与
/// [`pipe_read_blocking`] 对称（读方成功读唤醒 / 读端终结唤醒 / 锁窗探针）。
fn pipe_write_blocking(pipe: &Pipe, buf: &[u8]) -> Result<usize, u64> {
    loop {
        match pipe.write(buf) {
            // EAGAIN 只在「满环 + 读端存活」出环
            Err(EAGAIN) if !pipe.nonblock => {
                PIPE_W_BLOCKS.fetch_add(1, Ordering::AcqRel);
                let object = pipe.w_object.load(Ordering::Acquire);
                if task::block_current_unless(
                    task::WaitWhat::PipeWrite { object },
                    true,
                    // 探针 = still_pending 契约（读路径同款）：满环 + 读端
                    // 存活 = 仍需等待；环有空间或读端亡（EPIPE 逃逸）任一
                    // 成立即就绪（false → 锁窗回滚重试消费）。
                    || {
                        pipe.avail.load(Ordering::Acquire) >= PIPE_CAP
                            && caps_refcount(pipe.r_object.load(Ordering::Acquire)) != 0
                    },
                ) {
                    PIPE_W_WAKES.fetch_add(1, Ordering::AcqRel);
                }
            }
            r => return r,
        }
    }
}

/// 管道读端等待者唤醒（M36-BB3 数据到达面）：写方成功写后调用——
/// 读端对象匹配的全部 `PipeRead` 等待者入队就绪（多等待者竞争由
/// 重探循环自然收敛——先到先得，其余重归阻塞）。
fn wake_pipe_readers(pipe: &Pipe) {
    let object = pipe.r_object.load(Ordering::Acquire);
    task::wake_tasks(|w| matches!(w, task::WaitWhat::PipeRead { object: o } if *o == object));
}

/// 管道写端等待者唤醒（M36-BB3 空间释放面）：读方成功读后调用。
fn wake_pipe_writers(pipe: &Pipe) {
    let object = pipe.w_object.load(Ordering::Acquire);
    task::wake_tasks(|w| matches!(w, task::WaitWhat::PipeWrite { object: o } if *o == object));
}

/// 管道对象段位判定（高 32 位段——与 [`is_file_object`] 同构）。
fn is_pipe_object(object: u64) -> bool {
    (object >> 32) == (PIPE_OBJECT_BASE >> 32)
}

/// 管道句柄解析：句柄 → 全局能力槽 → 段位门禁 → PIPES 反查（返回环核
/// Arc 共享——锁即取即释，环核锁在 [`Pipe::read`]/`write` 内层单向嵌套）。
/// M35-BBb：句柄 0 解禁（与 [`resolve_file_object`] 同面——stdio
/// 重定向接线域可装句柄 0，t85 B 段 stdin 管道读消费面）。
fn resolve_pipe_object(handle: u64) -> Option<(usize, Capability, Arc<Pipe>)> {
    let caller = task::current_task_id();
    let h = handle as usize;
    if h >= task::HANDLE_MAX {
        return None;
    }
    let slot = task::with_task_handles(caller, |t| t[h]).and_then(|s| s)?;
    let cap = crate::caps::table().lock().get(slot).ok()?;
    if !is_pipe_object(cap.object()) {
        return None;
    }
    let object = cap.object();
    let pipe = {
        let pipes = PIPES.lock();
        pipes.iter().find_map(|e| {
            e.as_ref()
                .filter(|e| e.object == object)
                .map(|e| e.pipe.clone())
        })?
    };
    Some((slot, cap, pipe))
}

/// 管道孤儿回收（[`task::revoke_all_handles`] 收敛链挂接——FILE 域
/// [`reap_orphaned_files`] 同构：能力引用归零条目清槽，Arc 计数随
/// drop 收敛）。
///
/// 返回值（M36-BB3）：本次回收终结的管道端对 `[(读端对象, 写端对象)]`
/// ——调用方（SCHED 锁窗口内，[`task::wake_pipes_locked`]）据此做对端
/// 等待者锁内死亡唤醒（EOF/EPIPE 逃逸面）。本函数自身不唤醒：调用域
/// 持 SCHED，锁内不可重入 wake。
pub fn reap_orphaned_pipes() -> Vec<(u64, u64)> {
    let mut dead = Vec::new();
    let mut pipes = PIPES.lock();
    for e in pipes.iter_mut() {
        if let Some(entry) = e.as_ref() {
            if caps_refcount(entry.object) == 0 {
                dead.push((
                    entry.pipe.r_object.load(Ordering::Acquire),
                    entry.pipe.w_object.load(Ordering::Acquire),
                ));
                *e = None;
            }
        }
    }
    dead
}

/// SYS_PIPE2 主体（M35-BBa；Linux 号域 293）：管道铸造（64 KiB 定容环 ×1
/// + 读/写端对象 ×2 + 能力槽 ×2〔r=READ / w=WRITE〕+ 句柄安装×2）。
///
/// - `flags`：收 `0` | [`O_CLOEXEC`]（随链 hflags [`FD_CLOEXEC`]——
///   EXEC 成功路径 [`close_cloexec_handles`] 消费）| [`O_NONBLOCK`]
///   （M36-BB3 收录——双端一体非阻塞语义定格；缺省 = Linux 同款阻塞
///   管道，等待队列面见 [`pipe_read_blocking`]）；其余位 → `EINVAL`
///   （fail-visible 登记）；
/// - `pipefd` 用户回写：`int[2]`（8 字节）= `[读端句柄, 写端句柄]`
///   （EFAULT 域守门）；
/// - 句柄表满 → `EMFILE`（先验免泄漏）；管道表满 → `ENFILE`。
///
/// 成功返回 `(1 << 32) | 0`。
pub fn sys_pipe2(pipefd_ptr: u64, flags: u64) -> u64 {
    if flags & !(O_CLOEXEC | O_NONBLOCK) != 0 {
        return EINVAL; // 未收录旗标 fail-visible（O_NONBLOCK 已随 M36-BB3 收录）
    }
    let Some(pfd) = validate_user_slice_mut(pipefd_ptr, 8) else {
        return EFAULT;
    };
    let caller = task::current_task_id();
    // 句柄空位预检 ×2（先验免泄漏）。
    let (free_r, free_w) = {
        let found = task::with_task_handles(caller, |t| {
            let mut it = t
                .iter()
                .enumerate()
                .skip(1)
                .filter(|(_, s)| s.is_none())
                .map(|(h, _)| h);
            (it.next(), it.next())
        })
        .unwrap_or((None, None));
        match found {
            (Some(a), Some(b)) => (a, b),
            _ => return EMFILE,
        }
    };
    // 注册表槽位（满 → ENFILE）。
    let mut pipes = PIPES.lock();
    if pipes.iter().filter(|e| e.is_some()).count() + 2 > MAX_PIPES {
        return ENFILE;
    }
    let r_object = NEXT_PIPE_OBJECT.fetch_add(1, Ordering::Relaxed);
    let w_object = NEXT_PIPE_OBJECT.fetch_add(1, Ordering::Relaxed);
    let arc = Arc::new(Pipe::new(r_object, w_object, flags & O_NONBLOCK != 0));
    pipes.push(Some(PipeEntry {
        object: r_object,
        pipe: arc.clone(),
    }));
    pipes.push(Some(PipeEntry {
        object: w_object,
        pipe: arc.clone(),
    }));
    drop(pipes);
    // 能力铸造（r=READ / w=WRITE）+ 句柄安装。
    let g_r = crate::caps::alloc_slot(Capability::new(r_object, Right::READ.bits()));
    let g_w = crate::caps::alloc_slot(Capability::new(w_object, Right::WRITE.bits()));
    let (Some(g_r), Some(g_w)) = (g_r, g_w) else {
        // 回滚（能力面满——先铸端已装则撤销；注册表条目引用归零随 reap 收敛）
        if let Some(g) = g_r {
            let _ = crate::caps::table().lock().revoke(g);
        }
        if let Some(g) = g_w {
            let _ = crate::caps::table().lock().revoke(g);
        }
        return ENOMEM;
    };
    task::with_task_handles(caller, |t| {
        t[free_r] = Some(g_r);
        t[free_w] = Some(g_w);
    });
    if flags & O_CLOEXEC != 0 {
        task::with_task_hflags(caller, |f| {
            f[free_r] |= bedrock::abi::FD_CLOEXEC as u8;
            f[free_w] |= bedrock::abi::FD_CLOEXEC as u8;
        });
    }
    // pipefd[2] 用户回写（int 域 4 字节 ×2——LP64 int = i32）。
    pfd[0..4].copy_from_slice(&(free_r as u32).to_le_bytes());
    pfd[4..8].copy_from_slice(&(free_w as u32).to_le_bytes());
    OK_BIT
}

/// SYS_STAT 主体（M13-②）：元数据快照（不影响偏移）。
/// 成功返回 `(1 << 32) | (size << 16) | kind_code`。
pub fn sys_stat(handle: u64) -> u64 {
    let Some((_slot, _cap, idx)) = resolve_file_object(handle) else {
        STAT_RESULT.store(EBADF, Ordering::Release);
        return EBADF;
    };
    let code = {
        let files = FILES.lock();
        match files[idx].as_ref() {
            Some(f) => match f.fs.metadata(f.vnode) {
                Ok(meta) => {
                    if meta.size >> 31 != 0 {
                        EOVERFLOW
                    } else {
                        OK_BIT | (meta.size << 16) | kind_code(meta.kind)
                    }
                }
                Err(e) => e.errno(),
            },
            None => EBADF,
        }
    };
    STAT_RESULT.store(code, Ordering::Release);
    code
}

/// SYS_SEEK 主体（M13-②）：三基准重定位（SET/CUR/END），负结果拒绝。
/// 成功返回 `(1 << 32) | new_offset`。
pub fn sys_seek(handle: u64, whence: u64, offset: u64) -> u64 {
    if whence > 2 {
        SEEK_RESULT.store(EINVAL, Ordering::Release);
        return EINVAL;
    }
    let Some((_slot, _cap, idx)) = resolve_file_object(handle) else {
        SEEK_RESULT.store(EBADF, Ordering::Release);
        return EBADF;
    };
    let off = offset as i64;
    let code = {
        let mut files = FILES.lock();
        match files[idx].as_mut() {
            None => EBADF,
            Some(f) => {
                let base: i128 = match whence {
                    0 => 0,
                    1 => f.pos as i128,
                    _ => match f.fs.metadata(f.vnode) {
                        Ok(meta) => meta.size as i128,
                        Err(e) => {
                            let c = e.errno();
                            SEEK_RESULT.store(c, Ordering::Release);
                            return c;
                        }
                    },
                };
                let target = base + off as i128;
                if target < 0 {
                    EINVAL
                } else {
                    f.pos = target as u64;
                    OK_BIT | f.pos
                }
            }
        }
    };
    SEEK_RESULT.store(code, Ordering::Release);
    code
}

// ---- M15-① 目录面（SYS_MKDIR/REMOVE/READDIR + MOUNT/UMOUNT 落点） ----

/// 路径参数共用切片（MKDIR/REMOVE/MOUNT/UMOUNT）：用户路径 → 规范化。
/// 非 UTF-8 / 非法词法 → errno；len == 0 由调用方先行 EINVAL（validate
/// 面零长视作不可达 → EFAULT，目录面改判 EINVAL 更贴 POSIX）。
fn normalize_user_path(path_bytes: &[u8]) -> Result<PathBuf, u64> {
    let Ok(path_str) = core::str::from_utf8(path_bytes) else {
        return Err(FsError::InvalidPath.errno());
    };
    PathBuf::normalize(path_str).map_err(|e| e.errno())
}

/// 父落点解析（MKDIR/REMOVE 共用）：规范化路径 → 深度检查（根自身
/// 不可建/摘 → EINVAL）→ `parent()/name()` 切片 → 命名空间解析父 →
/// (落点 fs, 父 vnode, 叶子名)。锁序：NAMESPACE → FileSystem 内部锁
/// （既有单向嵌套；fs 返回后命名空间锁已释放，叶子操作不持锁）。
fn resolve_parent(
    path: &PathBuf,
) -> Result<(Arc<dyn FileSystem>, VnodeId, alloc::string::String), u64> {
    if path.depth() == 0 {
        return Err(EINVAL); // 根自身：mkdir/remove 均无意义
    }
    let parent = path.parent().ok_or(EINVAL)?; // depth ≥ 1 恒有父（防御面）
    let leaf = alloc::string::String::from(path.name());
    let resolved = {
        let ns = NAMESPACE.lock();
        let Some(ns) = ns.as_ref() else {
            return Err(EBADF); // 未初始化：防御路径（自检序保证不达）
        };
        match ns.resolve(&parent) {
            Ok(r) => r,
            Err(e) => return Err(e.errno()),
        }
    };
    Ok((resolved.fs, resolved.vnode, leaf))
}

/// SYS_MKDIR 主体（M15-①）：父走查 + 叶子建目录（POSIX mkdir 同款：
/// 中间组件必须已存在）。成功返回 0；EEXIST/ENOENT/ENOTDIR/EINVAL/
/// EFAULT 域见 abi 文档。RamFs::create 对非目录父返回 NotADirectory
/// （→ ENOTDIR）。
pub fn sys_mkdir(path_ptr: u64, len: u64) -> u64 {
    let code = if len == 0 {
        EINVAL
    } else {
        match validate_user_slice(path_ptr, len) {
            None => EFAULT,
            Some(pb) => match normalize_user_path(pb).and_then(|p| resolve_parent(&p)) {
                Err(e) => e,
                Ok((fs, dir, leaf)) => match fs.create(dir, &leaf, NodeKind::Dir) {
                    Ok(_) => 0,
                    Err(e) => e.errno(),
                },
            },
        }
    };
    MKDIR_RESULT.store(code, Ordering::Release);
    code
}

/// SYS_REMOVE 主体（M15-①）：父走查 + 叶子摘除（POSIX remove：文件与
/// 空目录同面可摘；目录非空 → ENOTEMPTY，RamFs::unlink 承载）。成功
/// 返回 0。v0 不做打开句柄占用检查（如实记档——节点摘除即不可达，
/// 已打开对象经 Arc 存续至关闭）。
pub fn sys_remove(path_ptr: u64, len: u64) -> u64 {
    let code = if len == 0 {
        EINVAL
    } else {
        match validate_user_slice(path_ptr, len) {
            None => EFAULT,
            Some(pb) => sys_remove_bytes(pb),
        }
    };
    REMOVE_RESULT.store(code, Ordering::Release);
    code
}

/// REMOVE 字节面内核入口（M34-B1）：路径字节串由调用方持有（Linux 面
/// unlinkat 相对路径 cwd join 域）；errno 直返（0 = 成功——**不走
/// min(ENOSYS) 截断**：FsError 域含 ENOTEMPTY(39)/EOPNOTSUPP(95) 等
/// 超出 ENOSYS 的合法 errno，截断即语义损毁）；取证面归 [`sys_remove`]
/// 外壳。
pub fn sys_remove_bytes(path_bytes: &[u8]) -> u64 {
    let path = match normalize_user_path(path_bytes) {
        Ok(p) => p,
        Err(e) => return e,
    };
    // M39-MU 权限域门禁：登记路径摘除需写位（owner/root 域；POSIX
    // 父目录位域语义 v0 简化为路径本身，偏差如实登记随行）。
    // M40-CRYSTAL 双车道：未登记路径 → 盘上属主回源判定。
    if let Some((owner, pmode)) = perm_lookup(path.as_str()) {
        if !perm_check(owner, 0, pmode, PERM_WANT_WRITE) {
            return EACCES;
        }
    } else if let Ok(dn) = PathBuf::normalize(path.as_str()) {
        if let Some((owner, gid, pmode)) = disk_perm_lookup(dn.as_str()) {
            if !perm_check(owner, gid, pmode, PERM_WANT_WRITE) {
                return EACCES;
            }
        }
    }
    match resolve_parent(&path) {
        Ok((fs, dir, leaf)) => match fs.unlink(dir, &leaf) {
            Ok(()) => 0,
            Err(e) => e.errno(),
        },
        Err(e) => e,
    }
}

/// SYS_CHMOD 主体（M40-CRYSTAL chmod(90) 车道）：路径 → 权限门禁
/// （root/owner 域——POSIX chmod 语义，root 旁路）→ fs.set_attr
/// （mode 九位域落盘/内存落域）+ PERMS 登记同步（已登记路径覆盖写
/// ——M39-MU「重复路径覆盖写」承接位；未登记路径零登记扰动）。
/// mode 入参为九位域（>0o777 扩展位域 set_attr 域掩拒绝 EINVAL）。
pub fn sys_chmod_bytes(path_bytes: &[u8], mode: u16) -> u64 {
    let path = match normalize_user_path(path_bytes) {
        Ok(p) => p,
        Err(e) => return e,
    };
    // 权限门禁：root 旁路 / owner 位域判定（POSIX chmod——仅文件属主
    // 与 root 可改 mode；组/他者 → EPERM 域拒绝）。
    let (owner, gid, _pmode) = match node_owner(path.as_str()) {
        Some(t) => t,
        None => return ENOENT,
    };
    let caller = task::current_task_id();
    let creds = task::task_creds(caller);
    let is_root = creds.is_some_and(|c| c.uid == 0);
    let is_owner = creds.is_some_and(|c| c.uid == owner);
    if !is_root && !is_owner {
        return EPERM;
    }
    let _ = gid;
    // 节点 set_attr：mode 落域（uid/gid 保持原值——chmod 不改属主）。
    let pb = match PathBuf::normalize(path.as_str()) {
        Ok(p) => p,
        Err(e) => return e.errno(),
    };
    let resolved = {
        let ns = NAMESPACE.lock();
        let Some(ns) = ns.as_ref() else {
            return EBADF;
        };
        match ns.resolve(&pb) {
            Ok(r) => r,
            Err(e) => return e.errno(),
        }
    };
    let meta = match resolved.fs.metadata(resolved.vnode) {
        Ok(m) => m,
        Err(e) => return e.errno(),
    };
    match resolved
        .fs
        .set_attr(resolved.vnode, meta.uid, meta.gid, mode & 0o777)
    {
        Ok(()) => {
            // PERMS 登记同步（已登记路径覆盖写——车道承接位语义）。
            if perm_lookup(path.as_str()).is_some() {
                let _ = perm_install(path.as_str(), meta.uid as u32, mode);
            }
            0
        }
        Err(e) => e.errno(),
    }
}

/// SYS_CHOWN 主体（M40-CRYSTAL chown(92) 车道）：路径 → 权限门禁
/// （root 旁路——POSIX chown 仅 root/CAP_CHOWN 域）→ fs.set_attr
/// （uid/gid 落域 + mode 保持原值）+ PERMS 登记同步。u16 装载面：
/// >0xFFFF 域 fail-visible EINVAL（偏差如实登记）。
pub fn sys_chown_bytes(path_bytes: &[u8], uid: u32, gid: u32) -> u64 {
    let path = match normalize_user_path(path_bytes) {
        Ok(p) => p,
        Err(e) => return e,
    };
    if uid > 0xFFFF || gid > 0xFFFF {
        return EINVAL; // u16 装载面 fail-visible（M40-CRYSTAL 偏差登记）
    }
    let caller = task::current_task_id();
    let is_root = task::task_creds(caller).is_some_and(|c| c.uid == 0);
    if !is_root {
        return EPERM; // POSIX chown 根域收口
    }
    let Some((owner, _gid, _pmode)) = node_owner(path.as_str()) else {
        return ENOENT;
    };
    let _ = owner;
    let pb = match PathBuf::normalize(path.as_str()) {
        Ok(p) => p,
        Err(e) => return e.errno(),
    };
    let resolved = {
        let ns = NAMESPACE.lock();
        let Some(ns) = ns.as_ref() else {
            return EBADF;
        };
        match ns.resolve(&pb) {
            Ok(r) => r,
            Err(e) => return e.errno(),
        }
    };
    let meta = match resolved.fs.metadata(resolved.vnode) {
        Ok(m) => m,
        Err(e) => return e.errno(),
    };
    match resolved
        .fs
        .set_attr(resolved.vnode, uid as u16, gid as u16, meta.mode)
    {
        Ok(()) => {
            if perm_lookup(path.as_str()).is_some() {
                let _ = perm_install(path.as_str(), uid, meta.mode);
            }
            0
        }
        Err(e) => e.errno(),
    }
}

/// 节点属主三元读取（chown/chmod 门禁消费面）：路径解析 → metadata
/// 属主域（uid/gid/mode）；未登记 PERMS 的路径直接盘上真面——登记
/// 路径 PERMS 优先（M39-MU 语义）。
fn node_owner(path: &str) -> Option<(u32, u32, u16)> {
    if let Some((owner, pmode)) = perm_lookup(path) {
        return Some((owner, 0, pmode));
    }
    disk_perm_lookup(path)
}

/// 节点属主真面字节面（M40-CRYSTAL stat 车道透出）：路径 → metadata
/// 属主三元。打包形态 = `(1<<32) | (mode<<16) | uid | gid<<48`——
/// mode 九位域（0..0o777）置 <<16、uid 16 位、gid 高 16 位；失败域
/// 返回 errno（< 2^32 与既有车道打包判定同构）。
pub fn sys_stat_owner_bytes(path_bytes: &[u8]) -> u64 {
    let Ok(s) = core::str::from_utf8(path_bytes) else {
        return FsError::InvalidPath.errno();
    };
    let Ok(pb) = PathBuf::normalize(s) else {
        return FsError::InvalidPath.errno();
    };
    let resolved = {
        let ns = NAMESPACE.lock();
        let Some(ns) = ns.as_ref() else {
            return EBADF;
        };
        match ns.resolve(&pb) {
            Ok(r) => r,
            Err(e) => return e.errno(),
        }
    };
    let Ok(meta) = resolved.fs.metadata(resolved.vnode) else {
        return FsError::NotFound.errno();
    };
    (1u64 << 32)
        | ((u64::from(meta.mode) & 0xFFFF) << 16)
        | (u64::from(meta.uid) & 0xFFFF)
        | ((u64::from(meta.gid) & 0xFFFF) << 48)
}

/// SYS_READDIR 主体（M15-①）：**分页化**目录枚举（替代 M13-① 一次性
/// 全量骨架的 syscall 面形态）。
///
/// 句柄须为目录（metadata kind 判定，非目录 → ENOTDIR；无需 READ
/// 权限位以外的门禁——目录打开即枚举，v0 与 read 的 READ 位校验对齐：
/// 未以读方式打开 → EBADF）。OFD 私有偏移兼任**目录项游标**：自游标
/// 起调用 [`meridian::vfs::pack_dir_page`] 尽量多打包（半项不落盘），
/// 消费后游标推进。SEEK 可重定位游标（目录 read 恒 EISDIR，偏移域
/// 专用）。成功返回 `(1 << 32) | n_entries`（0 = 枚举尽/EOF）。
pub fn sys_readdir(handle: u64, buf_ptr: u64, buf_len: u64) -> u64 {
    let code = if buf_len < 3 {
        EINVAL // 不足容纳最小项（[kind][len][1 字节名]）
    } else {
        match validate_user_slice_mut(buf_ptr, buf_len) {
            None => EFAULT,
            Some(buf) => readdir_checked(handle, buf),
        }
    };
    READDIR_RESULT.store(code, Ordering::Release);
    code
}

/// READDIR 校验后内聚链（句柄门禁 + 目录判定 + 分页打包 + 游标推进）。
fn readdir_checked(handle: u64, buf: &mut [u8]) -> u64 {
    let Some((_slot, cap, idx)) = resolve_file_object(handle) else {
        return EBADF;
    };
    if cap.rights() & Right::READ.bits() == 0 {
        return EBADF; // 目录枚举对齐 read：须以读方式打开
    }
    let mut files = FILES.lock();
    match files[idx].as_mut() {
        None => EBADF,
        Some(f) => match f.fs.metadata(f.vnode) {
            Err(e) => e.errno(),
            Ok(meta) if !meta.kind.is_dir() => ENOTDIR,
            Ok(_) => match f.fs.readdir_from(f.vnode, f.pos) {
                Err(e) => e.errno(),
                Ok(items) => {
                    // fs 侧已按稳定 cookie 序过滤余项；打包自 0 起
                    //（半项不落盘纪律不变）。游标推进 = 最后交付项 cookie。
                    let entries: Vec<meridian::vfs::DirEntry> =
                        items.iter().map(|c| c.entry.clone()).collect();
                    let (_packed, consumed) = meridian::vfs::pack_dir_page(&entries, 0, buf);
                    if consumed > 0 {
                        f.pos = items[consumed - 1].cookie;
                    }
                    OK_BIT | consumed as u64
                }
            },
        },
    }
}

/// SYS_MOUNT 主体（M15-①）：挂载点路径上挂载**内核侧新建**空 RamFs
/// （v0 仅内存文件系统，fs_type = 0；ABI 面结构校验已拒非零）。挂载
/// 点必须已存在且为目录（[`Namespace::mount`] 承载校验：缺失 → ENOENT、
/// 非目录 → ENOTDIR、同路径重复 → EEXIST）。成功返回 0（最长前缀
/// 解析即时生效，子 fs 遮蔽挂载点原内容）。
pub fn sys_mount(path_ptr: u64, len: u64, fs_type: u64) -> u64 {
    let code = if fs_type > 1 || len == 0 {
        EINVAL
    } else {
        match validate_user_slice(path_ptr, len) {
            None => EFAULT,
            Some(pb) => {
                let mounted = normalize_user_path(pb).and_then(|path| {
                    let fs: Result<Arc<dyn FileSystem>, u64> = match fs_type {
                        0 => Ok(Arc::new(RamFs::new())),
                        _ => {
                            if !crate::block::ready() {
                                Err(EINVAL)
                            } else {
                                meridian::vfs::Lfs::format_or_open(crate::block::DataBlock::arced())
                                    .map(|l| Arc::new(l) as Arc<dyn FileSystem>)
                                    .map_err(|e| e.errno())
                            }
                        }
                    };
                    fs.and_then(|fs| {
                        let ns = NAMESPACE.lock();
                        match ns.as_ref() {
                            None => Err(EBADF), // 防御路径（自检序保证不达）
                            Some(ns) => ns.mount(&path, fs).map_err(|e| e.errno()),
                        }
                    })
                });
                match mounted {
                    Ok(()) => 0,
                    Err(e) => e,
                }
            }
        }
    };
    MOUNT_RESULT.store(code, Ordering::Release);
    code
}

/// SYS_UMOUNT 主体（M15-①）：卸载路径处挂载（[`Namespace::unmount`]
/// 承载：未挂载 → ENOENT；根挂载不在表中同落此域）。v0 不做占用
/// 检查（已打开对象经 Arc 存续至关闭，如实记档）。成功返回 0。
pub fn sys_umount(path_ptr: u64, len: u64) -> u64 {
    let code = if len == 0 {
        EINVAL
    } else {
        match validate_user_slice(path_ptr, len) {
            None => EFAULT,
            Some(pb) => {
                match normalize_user_path(pb).and_then(|path| {
                    let ns = NAMESPACE.lock();
                    match ns.as_ref() {
                        None => Err(EBADF),
                        Some(ns) => ns
                            .unmount_if_idle(&path, |fs| {
                                let files = FILES.lock();
                                files
                                    .iter()
                                    .any(|f| f.as_ref().is_some_and(|f| Arc::ptr_eq(&f.fs, fs)))
                            })
                            .map_err(|e| e.errno()),
                    }
                }) {
                    Ok(()) => 0,
                    Err(e) => e,
                }
            }
        }
    };
    UMOUNT_RESULT.store(code, Ordering::Release);
    code
}

// ---- M15-② 句柄面深化（SYS_DUP/FCNTL + CLOEXEC） ----

/// DUP/F_DUPFD 共用链：源句柄解析（文件对象门禁）→ ≥ floor 首空闲位
/// 预检（满 → EMFILE；floor ≥ HANDLE_MAX → EINVAL，对齐 POSIX 语义）→
/// 新能力槽铸造（同对象同权限）+ 句柄安装。新句柄与源句柄共享同一
/// [`FileObject`]（**共享偏移**——开放文件描述一份，句柄多个视角）。
/// 旗标随新句柄置 0（TCB 零化 + 关闭面清理保证无陈值继承）。
fn dup_impl(handle: u64, floor: u64) -> u64 {
    let caller = task::current_task_id();
    let Some((_slot, cap, _idx)) = resolve_file_object(handle) else {
        return EBADF;
    };
    let floor = floor.max(1) as usize;
    if floor >= task::HANDLE_MAX {
        return EINVAL;
    }
    let free = task::with_task_handles(caller, |t| {
        t.iter()
            .enumerate()
            .skip(floor)
            .find_map(|(h, s)| s.is_none().then_some(h))
    });
    let Some(Some(free_handle)) = free else {
        return EMFILE;
    };
    let gslot = crate::caps::alloc_slot(Capability::new(cap.object(), cap.rights()));
    let installed = gslot
        .map(|g| task::with_task_handles(caller, |t| t[free_handle] = Some(g)).is_some())
        .unwrap_or(false);
    if !installed {
        return ENOMEM;
    }
    OK_BIT | free_handle as u64
}

/// DUP2 共用链（M18-③ F_DUP2FD）：源句柄解析 → 目标槽位界检
/// （≥ HANDLE_MAX → EINVAL，对齐本内核 F_DUPFD 的 EINVAL 语义；
/// POSIX 原生 dup2 为 EBADF，偏差如实记档）→ 目标 == 源 → 无操作
/// 直返 → 目标已开则先关（同款 close 链：能力撤销 + 槽位清零 +
/// OFD 引用计数递减——EBUSY 卸载占用面自然联动）→ 精确槽位安装。
fn dup2_impl(handle: u64, target: u64) -> u64 {
    let caller = task::current_task_id();
    let Some((_slot, cap, _idx)) = resolve_file_object(handle) else {
        return EBADF;
    };
    if target >= task::HANDLE_MAX as u64 {
        return EINVAL;
    }
    if target == handle {
        return OK_BIT | handle; // POSIX dup2 同槽位无操作
    }
    let target = target as usize;
    // 目标已开 → 先关（close 链同款：revoke + 清槽 + OFD 释放）。
    let occupied = task::with_task_handles(caller, |t| t[target].is_some()).unwrap_or(false);
    if occupied {
        let code = sys_close(target as u64);
        if code & OK_BIT == 0 && code != 0 {
            return code; // 关闭失败（非 EBADF 类）原样上抛
        }
    }
    let gslot = crate::caps::alloc_slot(Capability::new(cap.object(), cap.rights()));
    let installed = gslot
        .map(|g| task::with_task_handles(caller, |t| t[target] = Some(g)).is_some())
        .unwrap_or(false);
    if !installed {
        return ENOMEM;
    }
    OK_BIT | target as u64
}

/// SYS_DUP 主体（M15-②）：复制文件句柄（首个空闲位；POSIX dup 同款）。
/// 成功返回 `(1 << 32) | new_handle`。
pub fn sys_dup(handle: u64) -> u64 {
    let r = dup_impl(handle, 1);
    DUP_RESULT.store(r, Ordering::Release);
    r
}

/// SYS_FCNTL 主体（M15-②）：句柄描述符控制（F_DUPFD/F_GETFD/F_SETFD/
/// F_DUP2FD；命令结构校验在 abi parse 层已限定 0..=3，此处防御性兜底
/// EINVAL）。v0 仅 [`bedrock::abi::FD_CLOEXEC`] 一旗：置位句柄在
/// SYS_EXEC 成功路径由 [`crate::task::close_cloexec_handles`] 消费关闭。
/// 成功编码：DUPFD/DUP2FD → `(1 << 32) | new_handle`、
/// GETFD → `(1 << 32) | flags`、SETFD → 0。
pub fn sys_fcntl(handle: u64, cmd: u64, arg: u64) -> u64 {
    let caller = task::current_task_id();
    let code = match cmd {
        bedrock::abi::F_DUPFD => dup_impl(handle, arg),
        bedrock::abi::F_DUP2FD => dup2_impl(handle, arg),
        bedrock::abi::F_GETFD => {
            if resolve_file_object(handle).is_none() {
                EBADF
            } else {
                match task::with_task_hflags(caller, |f| f[handle as usize]) {
                    Some(fl) => OK_BIT | u64::from(fl),
                    None => EBADF,
                }
            }
        }
        bedrock::abi::F_SETFD => {
            if arg > u64::from(u8::MAX) {
                EINVAL // 旗标域单字节（v0 仅 bit0 有义）
            } else if resolve_file_object(handle).is_none() {
                EBADF
            } else {
                match task::with_task_hflags(caller, |f| f[handle as usize] = arg as u8) {
                    Some(()) => 0,
                    None => EBADF,
                }
            }
        }
        _ => EINVAL,
    };
    FCNTL_RESULT.store(code, Ordering::Release);
    code
}

/// stdio 重定向活动判定（M35-BBb lin 派发消费面）：调用方句柄域
/// 已装管道或文件对象 = 重定向在环（true）——lin_read/lin_write 的
/// fd 0/1/2 分流闸：重定向在环走 vfs 真对象，未装保持控制台/tty
/// 直通（既有语义零破）。主身份等其他对象不触法（解析 None = 未重
/// 定向）。句柄 0/1/2 与文件/管道双 resolver 同源，单点事实源。
pub fn stdio_redirect_active(handle: u64) -> bool {
    resolve_pipe_object(handle).is_some() || resolve_file_object(handle).is_some()
}

/// fd 开旗标查询（M34-B2）：Linux F_GETFL 语义承载（kernel::linux 域
/// 翻译后消费——**不经 [`sys_fcntl`] 命令域**：bedrock F_DUP2FD(3) 与
/// Linux F_GETFL(3) 同值异义，直传即误派 dup2）。fd<3 控制台三件套 =
/// O_RDWR；vfs 文件面按 OFD readable/writable 反推 O_RDONLY/O_WRONLY/
/// O_RDWR（64 位 O_LARGEFILE=0——Linux x86_64 同构；v0 无 O_APPEND
/// 执行面如实记档）。成功 `(1 << 32) | flags`；无效句柄 EBADF。
pub fn fd_open_flags(handle: u64) -> u64 {
    if handle < 3 {
        return OK_BIT | 0o2;
    }
    let Some((_slot, _cap, idx)) = resolve_file_object(handle) else {
        return EBADF;
    };
    let files = FILES.lock();
    match files[idx].as_ref() {
        Some(f) => {
            let fl = match (f.readable, f.writable) {
                (true, true) => 0o2,
                (true, false) => 0o0,
                _ => 0o1,
            };
            OK_BIT | fl
        }
        None => EBADF,
    }
}
